const ReporteDecorator = require("./ReporteDecorator");

class MarcaAgua extends ReporteDecorator {
  constructor(reporte, texto) {
    super(reporte);
    this.texto = texto;
  }

  generar() {
    return super
      .generar()
      .split("\n")
      .map((linea) => (linea.length > 0 ? `[${this.texto}] ${linea}` : linea))
      .join("\n");
  }

  getDescripcion() {
    return super.getDescripcion() + ` + Marca de agua '${this.texto}'`;
  }
}

module.exports = MarcaAgua;
