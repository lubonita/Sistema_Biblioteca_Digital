const ReportePrestamos = require("./ReportePrestamos");

class ReportePrestamosBase extends ReportePrestamos {
  constructor(usuario, prestamos) {
    super();
    this.usuario = usuario;
    this.prestamos = prestamos;
  }

  generar() {
    const lineas = [];
    lineas.push("REPORTE DE PRÉSTAMOS");
    lineas.push(`Usuario: ${this.usuario}`);
    lineas.push("Préstamos:");
    this.prestamos.forEach((p) => {
      lineas.push(`  - ${p.libro} (vence: ${p.vencimiento})`);
    });
    lineas.push(`Total de préstamos: ${this.prestamos.length}`);
    return lineas.join("\n") + "\n";
  }

  getDescripcion() {
    return `Préstamos de ${this.usuario}`;
  }
}

module.exports = ReportePrestamosBase;
