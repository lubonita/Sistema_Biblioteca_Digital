const ReporteDecorator = require("./ReporteDecorator");

class NotasAlMargen extends ReporteDecorator {
  constructor(reporte) {
    super(reporte);
    this.observaciones = [];
  }

  agregarObservacion(observacion) {
    this.observaciones.push(observacion);
    return this;
  }

  generar() {
    let contenido = super.generar();
    contenido += "\n--- OBSERVACIONES ---\n";
    this.observaciones.forEach((obs) => {
      contenido += `+ ${obs}\n`;
    });
    return contenido;
  }

  getDescripcion() {
    return super.getDescripcion() + ` + ${this.observaciones.length} observaciones`;
  }
}

module.exports = NotasAlMargen;
