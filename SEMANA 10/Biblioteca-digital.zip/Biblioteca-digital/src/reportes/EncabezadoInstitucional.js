const ReporteDecorator = require("./ReporteDecorator");

const ENCABEZADO =
  "========================================\n" +
  "  BIBLIOTECA DIGITAL UTS\n" +
  "  Sistema de Gestión de Préstamos\n" +
  "========================================\n\n";

class EncabezadoInstitucional extends ReporteDecorator {
  generar() {
    return ENCABEZADO + super.generar();
  }

  getDescripcion() {
    return "Encabezado institucional + " + super.getDescripcion();
  }
}

module.exports = EncabezadoInstitucional;
