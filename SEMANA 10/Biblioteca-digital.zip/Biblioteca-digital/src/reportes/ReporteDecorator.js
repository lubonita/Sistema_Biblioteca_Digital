const ReportePrestamos = require("./ReportePrestamos");

class ReporteDecorator extends ReportePrestamos {
  constructor(reporte) {
    super();
    if (new.target === ReporteDecorator) {
      throw new Error("ReporteDecorator es una clase base y no puede instanciarse directamente.");
    }
    this.reporte = reporte;
  }

  generar() {
    return this.reporte.generar(); // delega en el componente decorado
  }

  getDescripcion() {
    return this.reporte.getDescripcion(); // delega en el componente decorado
  }
}

module.exports = ReporteDecorator;
