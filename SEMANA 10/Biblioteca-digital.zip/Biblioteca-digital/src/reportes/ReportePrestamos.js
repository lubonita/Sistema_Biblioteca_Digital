class ReportePrestamos {
  generar() {
    throw new Error("generar() debe ser implementado por la subclase.");
  }

  getDescripcion() {
    throw new Error("getDescripcion() debe ser implementado por la subclase.");
  }
}

module.exports = ReportePrestamos;
