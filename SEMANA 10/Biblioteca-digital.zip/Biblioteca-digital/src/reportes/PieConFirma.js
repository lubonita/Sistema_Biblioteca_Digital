const ReporteDecorator = require("./ReporteDecorator");

class PieConFirma extends ReporteDecorator {
  constructor(reporte, firmante) {
    super(reporte);
    this.firmante = firmante;
  }

  generar() {
    const fecha = new Date().toISOString().slice(0, 10);
    return (
      super.generar() +
      "\n\n______________________________\n" +
      `Firma: ${this.firmante}\n` +
      `Fecha: ${fecha}\n`
    );
  }

  getDescripcion() {
    return super.getDescripcion() + ` + Firma de ${this.firmante}`;
  }
}

module.exports = PieConFirma;
