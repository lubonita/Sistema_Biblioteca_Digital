const ReportePrestamos = require("./reportes/ReportePrestamos");
const ReportePrestamosBase = require("./reportes/ReportePrestamosBase");
const ReporteDecorator = require("./reportes/ReporteDecorator");
const EncabezadoInstitucional = require("./reportes/EncabezadoInstitucional");
const PieConFirma = require("./reportes/PieConFirma");
const MarcaAgua = require("./reportes/MarcaAgua");
const NotasAlMargen = require("./reportes/NotasAlMargen");

const prestamos = [
  { libro: "Cien años de soledad", vencimiento: "2026-10-20" },
  { libro: "Rayuela", vencimiento: "2026-10-25" },
  { libro: "Dune", vencimiento: "2026-11-02" },
];

console.log("========================================");
console.log(" PRUEBA 1: Reporte simple (solo el contenido base)");
console.log("========================================");
const simple = new ReportePrestamosBase("Valentina Millán", prestamos);
console.log(simple.generar());

console.log("========================================");
console.log(" PRUEBA 2: Reporte oficial (encabezado + pie con firma)");
console.log("========================================");
const oficial = new PieConFirma(
  new EncabezadoInstitucional(new ReportePrestamosBase("Valentina Millán", prestamos)),
  "Dirección de Biblioteca"
);
console.log(oficial.generar());

console.log("========================================");
console.log(" PRUEBA 3: Reporte completo (encabezado + firma + marca de agua + observaciones)");
console.log("========================================");
const completo = new NotasAlMargen(
  new MarcaAgua(
    new PieConFirma(
      new EncabezadoInstitucional(new ReportePrestamosBase("Valentina Millán", prestamos)),
      "Dirección de Biblioteca"
    ),
    "COPIA"
  )
)
  .agregarObservacion("Usuario con historial puntual")
  .agregarObservacion("Recomendado para ampliar cupo de préstamos");
console.log(completo.generar());
console.log("Descripción:", completo.getDescripcion());

console.log("\n========================================");
console.log(" PRUEBA 4: Confirmar que el ORDEN de decoración afecta el resultado");
console.log("========================================");
// A: marca de agua ANTES del encabezado (el encabezado queda sin marca)
const ordenA = new EncabezadoInstitucional(
  new MarcaAgua(new ReportePrestamosBase("Ana", [prestamos[0]]), "COPIA")
);
// B: marca de agua DESPUÉS del encabezado (el encabezado también lleva marca)
const ordenB = new MarcaAgua(
  new EncabezadoInstitucional(new ReportePrestamosBase("Ana", [prestamos[0]])),
  "COPIA"
);
console.log("--- Orden A: Encabezado(MarcaAgua(Base)) ---");
console.log(ordenA.generar());
console.log("--- Orden B: MarcaAgua(Encabezado(Base)) ---");
console.log(ordenB.generar());
console.log("¿Producen el mismo reporte?", ordenA.generar() === ordenB.generar());

console.log("\n========================================");
console.log(" PRUEBA 5: Confirmar que cada reporte decorado sigue cumpliendo la interfaz");
console.log("========================================");
console.log("¿simple es ReportePrestamos?", simple instanceof ReportePrestamos);
console.log("¿oficial es ReportePrestamos?", oficial instanceof ReportePrestamos);
console.log("¿completo es ReportePrestamos?", completo instanceof ReportePrestamos);
console.log("¿completo es ReportePrestamosBase? (identidad cambia al decorar)", completo instanceof ReportePrestamosBase);

console.log("\n========================================");
console.log(" PRUEBA 6: Intentar usar el Decorator abstracto directamente (debe fallar)");
console.log("========================================");
try {
  new ReporteDecorator(simple);
} catch (error) {
  console.log("Error capturado como se esperaba:", error.message);
}

console.log("\n========================================");
console.log(" PRUEBA 7: Intentar usar el Component directamente (debe fallar)");
console.log("========================================");
try {
  new ReportePrestamos().generar();
} catch (error) {
  console.log("Error capturado como se esperaba:", error.message);
}
