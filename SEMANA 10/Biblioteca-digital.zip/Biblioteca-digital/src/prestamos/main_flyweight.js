"use strict";

const LibroCompartido = require("./prestamos/LibroCompartido");
const FabricaLibrosCompartidos = require("./prestamos/FabricaLibrosCompartidos");
const PrestamoActivo = require("./prestamos/PrestamoActivo");

const datosCienAnios = {
  isbn: "978-0307474728",
  titulo: "Cien años de soledad",
  autor: "Gabriel García Márquez",
  editorial: "Vintage Español",
};
const datosRayuela = {
  isbn: "978-8437604572",
  titulo: "Rayuela",
  autor: "Julio Cortázar",
  editorial: "Cátedra",
};
const datosDune = {
  isbn: "978-0441172719",
  titulo: "Dune",
  autor: "Frank Herbert",
  editorial: "Ace",
};

const fabrica = new FabricaLibrosCompartidos();

console.log("========================================");
console.log(" PRUEBA 1: Pedir dos veces el mismo libro a la fábrica");
console.log("========================================");
const libroA = fabrica.obtener(datosCienAnios);
const libroB = fabrica.obtener(datosCienAnios);
console.log("¿libroA y libroB son el MISMO objeto?", libroA === libroB);
console.log("Objetos LibroCompartido creados hasta ahora:", fabrica.totalCreados);

console.log("\n========================================");
console.log(" PRUEBA 2: Pedir un libro distinto");
console.log("========================================");
const libroC = fabrica.obtener(datosRayuela);
console.log("¿libroA y libroC son el mismo objeto?", libroA === libroC);
console.log("Objetos LibroCompartido creados hasta ahora:", fabrica.totalCreados);

console.log("\n========================================");
console.log(" PRUEBA 3: Dos préstamos del mismo libro: comparten el libro, no el estado propio");
console.log("========================================");
const prestamo1 = new PrestamoActivo("Valentina Millán", libroA, "BIB-001", "2026-10-20");
const prestamo2 = new PrestamoActivo("Luz Estela Zafra", libroB, "BIB-002", "2026-10-27");
console.log(prestamo1.resumen());
console.log(prestamo2.resumen());
console.log("¿Comparten el mismo objeto de libro?", prestamo1.libro === prestamo2.libro);
console.log("¿Tienen el mismo vencimiento?", prestamo1.vencimiento === prestamo2.vencimiento);

console.log("\n========================================");
console.log(" PRUEBA 4: 100.000 préstamos sobre 3 libros");
console.log("========================================");
const fabricaMasiva = new FabricaLibrosCompartidos();
const catalogo = [datosCienAnios, datosRayuela, datosDune];
const prestamos = [];
const TOTAL_PRESTAMOS = 100000;
for (let i = 0; i < TOTAL_PRESTAMOS; i++) {
  const libro = fabricaMasiva.obtener(catalogo[i % catalogo.length]);
  prestamos.push(new PrestamoActivo(`usuario-${i}`, libro, `EJ-${i}`, "2026-11-30"));
}

console.log("Préstamos creados:", prestamos.length);
console.log("Objetos LibroCompartido con Flyweight:", fabricaMasiva.getTotalCompartidos());
console.log("Objetos de libro SIN Flyweight (una copia por préstamo):", TOTAL_PRESTAMOS);
const ahorro = (1 - fabricaMasiva.getTotalCompartidos() / TOTAL_PRESTAMOS) * 100;
console.log("Ahorro de objetos de libro:", ahorro.toFixed(3) + "%");

console.log("\n========================================");
console.log(" PRUEBA 5: El libro compartido es inmutable (no se puede modificar)");
console.log("========================================");
try {
  libroA.titulo = "Título alterado";
} catch (error) {
  console.log("Error capturado como se esperaba:", error.message);
}
console.log("Título del libro compartido sigue siendo:", libroA.titulo);

console.log("\n========================================");
console.log(" PRUEBA 6: Confirmar que el estado extrínseco sí se puede cambiar por préstamo");
console.log("========================================");
prestamo1.vencimiento = "2026-12-01";
console.log("Vencimiento del préstamo 1:", prestamo1.vencimiento);
console.log("Vencimiento del préstamo 2 (no cambió):", prestamo2.vencimiento);
