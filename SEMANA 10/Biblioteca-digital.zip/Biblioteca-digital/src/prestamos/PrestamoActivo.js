

class PrestamoActivo {
  constructor(usuario, libro, codigoEjemplar, vencimiento) {
    this.usuario = usuario;
    this.libro = libro; // referencia al Flyweight compartido
    this.codigoEjemplar = codigoEjemplar;
    this.vencimiento = vencimiento;
  }

  resumen() {
    return `[${this.codigoEjemplar}] ${this.libro.describirPrestamo(this.usuario, this.vencimiento)}`;
  }
}

module.exports = PrestamoActivo;
