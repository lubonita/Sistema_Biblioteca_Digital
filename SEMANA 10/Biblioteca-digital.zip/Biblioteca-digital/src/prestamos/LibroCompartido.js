class LibroCompartido {
  constructor(isbn, titulo, autor, editorial) {
    this.isbn = isbn;
    this.titulo = titulo;
    this.autor = autor;
    this.editorial = editorial;
    Object.freeze(this); // inmutable: nadie puede cambiar el estado compartido
  }

  // El estado extrínseco entra como parámetro, no se almacena.
  describirPrestamo(usuario, vencimiento) {
    return `"${this.titulo}" de ${this.autor} (${this.editorial}) - ${usuario}, vence ${vencimiento}`;
  }
}

module.exports = LibroCompartido;
