const LibroCompartido = require("./LibroCompartido");

class FabricaLibrosCompartidos {
  constructor() {
    this.cache = new Map();
    this.totalCreados = 0;
  }

  obtener({ isbn, titulo, autor, editorial }) {
    if (!this.cache.has(isbn)) {
      this.cache.set(isbn, new LibroCompartido(isbn, titulo, autor, editorial));
      this.totalCreados++;
    }
    return this.cache.get(isbn);
  }

  getTotalCompartidos() {
    return this.cache.size;
  }
}

module.exports = FabricaLibrosCompartidos;
