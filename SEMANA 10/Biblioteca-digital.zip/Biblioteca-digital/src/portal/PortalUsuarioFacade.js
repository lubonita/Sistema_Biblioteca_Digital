const SesionManager = require("../auth/SesionManager");

const SuscripcionBase = require("../suscripciones/SuscripcionBase");
const DescuentoPagoAnual = require("../suscripciones/DescuentoPagoAnual");
const DescuentoEstudiante = require("../suscripciones/DescuentoEstudiante");
const RecargoDispositivosExtra = require("../suscripciones/RecargoDispositivosExtra");

const StripeAPI = require("../pagos/StripeAPI");
const StripeAdapter = require("../pagos/StripeAdapter");

const ReportePrestamosBase = require("../reportes/ReportePrestamosBase");
const EncabezadoInstitucional = require("../reportes/EncabezadoInstitucional");
const PieConFirma = require("../reportes/PieConFirma");

const CanalEnvioEmail = require("../notificaciones/CanalEnvioEmail");
const CanalEnvioSMS = require("../notificaciones/CanalEnvioSMS");
const CanalEnvioPush = require("../notificaciones/CanalEnvioPush");
const AvisoPrestamoVencido = require("../notificaciones/AvisoPrestamoVencido");

class PortalUsuarioFacade {
  // El catálogo (raíz del Composite) se inyecta desde fuera.
  constructor(catalogo = null) {
    this.sesion = SesionManager.getInstance();
    this.pasarela = new StripeAdapter(new StripeAPI());
    this.catalogo = catalogo;
    this.canales = {
      email: new CanalEnvioEmail(),
      sms: new CanalEnvioSMS(),
      push: new CanalEnvioPush(),
    };
  }

  // Operación 1: coordina el Singleton de sesión
  iniciarSesion(usuario, password) {
    return this.sesion.login(usuario, password);
  }

  cerrarSesion() {
    this.sesion.logout();
  }

  // Operación 2: coordina el Composite del catálogo
  consultarCalificacionCatalogo() {
    if (!this.catalogo) {
      return { exito: false, mensaje: "No hay catálogo configurado." };
    }
    return {
      exito: true,
      promedio: this.catalogo.getCalificacionPromedio(),
      totalLibros: this.catalogo.getTotalLibros(),
    };
  }

  // Operación 3: coordina Singleton (sesión) + Decorator (costo) + Adapter (pago)
  suscribirse({ costoBase, pagoAnual = false, estudiante = false, dispositivosExtra = 0 }) {
    if (!this.sesion.estaAutenticado()) {
      return { exito: false, mensaje: "Debe iniciar sesión para suscribirse." };
    }

    let calculo = new SuscripcionBase(costoBase);
    if (pagoAnual) calculo = new DescuentoPagoAnual(calculo);
    if (estudiante) calculo = new DescuentoEstudiante(calculo);
    if (dispositivosExtra > 0) calculo = new RecargoDispositivosExtra(calculo, dispositivosExtra);

    const total = calculo.calcular();
    const pago = this.pasarela.procesarPago(total, "Suscripción biblioteca digital");

    return {
      exito: pago.exitoso,
      total,
      detalle: calculo.detalle(),
      idTransaccion: pago.idTransaccion,
    };
  }

  // Operación 4: coordina Singleton (usuario) + Decorator (reporte)
  generarReporteOficial(prestamos, firmante) {
    if (!this.sesion.estaAutenticado()) {
      return { exito: false, mensaje: "Debe iniciar sesión para generar el reporte." };
    }
    const usuario = this.sesion.getUsuarioActual();
    const reporte = new PieConFirma(
      new EncabezadoInstitucional(new ReportePrestamosBase(usuario.nombre, prestamos)),
      firmante
    );
    return { exito: true, contenido: reporte.generar() };
  }

  // Operación 5: coordina Bridge (aviso x canal)
  notificarPrestamoVencido(datosUsuario, canal) {
    const canalEnvio = this.canales[canal];
    if (!canalEnvio) {
      throw new Error(`Canal no soportado: "${canal}". Use email, sms o push.`);
    }
    return new AvisoPrestamoVencido(canalEnvio).notificar(datosUsuario);
  }
}

module.exports = PortalUsuarioFacade;
