/**
 * main_facade.js
 * ---------------------------------------------------
 * Pruebas por consola del patrón Facade: el "portal del usuario"
 * usa una sola clase (PortalUsuarioFacade) para operar sobre varios
 * subsistemas, sin conocerlos por dentro.
 * ---------------------------------------------------
 */

const PortalUsuarioFacade = require("./portal/PortalUsuarioFacade");

// Preparación de datos de prueba: el catálogo (Composite) se arma
// aparte y se le entrega al Facade.
const Categoria = require("./catalogo/Categoria");
const LibroCatalogado = require("./catalogo/LibroCatalogado");

const novela = new Categoria("Novela");
novela.agregar(new LibroCatalogado("Cien años de soledad", 4.8));
novela.agregar(new LibroCatalogado("Rayuela", 4.5));
const cienciaFiccion = new Categoria("Ciencia Ficción");
cienciaFiccion.agregar(new LibroCatalogado("Dune", 4.7));
const literatura = new Categoria("Literatura");
literatura.agregar(novela);
literatura.agregar(cienciaFiccion);

const portal = new PortalUsuarioFacade(literatura);

console.log("========================================");
console.log(" PRUEBA 1: Intentar suscribirse SIN haber iniciado sesión");
console.log("========================================");
console.log(portal.suscribirse({ costoBase: 29900 }));

console.log("\n========================================");
console.log(" PRUEBA 2: Iniciar sesión a través del Facade");
console.log("========================================");
portal.iniciarSesion("vmillan", "1234");

console.log("\n========================================");
console.log(" PRUEBA 3: Consultar la calificación del catálogo (Composite)");
console.log("========================================");
const catalogoInfo = portal.consultarCalificacionCatalogo();
console.log("Promedio del catálogo:", catalogoInfo.promedio.toFixed(2));
console.log("Total de libros:", catalogoInfo.totalLibros);

console.log("\n========================================");
console.log(" PRUEBA 4: Suscribirse (Decorator + Adapter + Singleton en una sola llamada)");
console.log("========================================");
const suscripcion = portal.suscribirse({
  costoBase: 29900,
  pagoAnual: true,
  estudiante: true,
  dispositivosExtra: 2,
});
console.log("Resultado:", suscripcion.exito ? "suscripción exitosa" : "falló");
console.log(suscripcion.detalle); 
console.log("Total cobrado:", suscripcion.total.toFixed(2));
console.log("Transacción:", suscripcion.idTransaccion);

console.log("\n========================================");
console.log(" PRUEBA 5: Generar un reporte oficial de préstamos (Decorator de reportes)");
console.log("========================================");
const reporte = portal.generarReporteOficial(
  [
    { libro: "Cien años de soledad", vencimiento: "2026-10-20" },
    { libro: "Dune", vencimiento: "2026-11-02" },
  ],
  "Dirección de Biblioteca"
);
console.log(reporte.contenido);

console.log("========================================");
console.log(" PRUEBA 6: Notificar un préstamo vencido por distintos canales (Bridge)");
console.log("========================================");
const datosUsuario = {
  contacto: "julio@correo.com",
  libro: "Rayuela",
  fechaVencimiento: "2026-09-20",
};
portal.notificarPrestamoVencido(datosUsuario, "email");
portal.notificarPrestamoVencido(datosUsuario, "sms");
portal.notificarPrestamoVencido(datosUsuario, "push");

console.log("\n========================================");
console.log(" PRUEBA 7: Pedir un canal que no existe (debe fallar con mensaje claro)");
console.log("========================================");
try {
  portal.notificarPrestamoVencido(datosUsuario, "whatsapp");
} catch (error) {
  console.log("Error capturado como se esperaba:", error.message);
}

console.log("\n========================================");
console.log(" PRUEBA 8: El Facade NO impide usar los subsistemas directamente");
console.log("========================================");
const SuscripcionBase = require("./suscripciones/SuscripcionBase");
console.log("Cálculo directo sin pasar por el Facade:", new SuscripcionBase(29900).calcular());

console.log("\n========================================");
console.log(" PRUEBA 9: Cerrar sesión y confirmar que las operaciones protegidas se bloquean");
console.log("========================================");
portal.cerrarSesion();
console.log(portal.generarReporteOficial([], "Dirección de Biblioteca"));
