const EmisorCertificado = require("./EmisorCertificado");

class CertificadoPazYSalvo extends EmisorCertificado {
  // Cuenta cuántas veces se ha creado el servicio real (para las pruebas)
  static instancias = 0;

  constructor() {
    super();
    CertificadoPazYSalvo.instancias++;
    this.emisiones = 0;
    console.log("[CertificadoPazYSalvo] Inicializando servicio real (creación costosa)...");
  }

  emitir(idUsuario) {
    this.emisiones++;
    console.log(
      `[CertificadoPazYSalvo] Verificando préstamos y multas de ${idUsuario} (operación costosa)...`
    );
    return {
      idUsuario,
      numero: `PYS-${String(this.emisiones).padStart(4, "0")}`,
      fecha: new Date().toISOString().slice(0, 10),
      mensaje: "Paz y salvo emitido",
    };
  }
}

module.exports = CertificadoPazYSalvo;
