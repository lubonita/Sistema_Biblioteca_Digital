const SesionManager = require("./auth/SesionManager");
const EmisorCertificado = require("./certificados/EmisorCertificado");
const CertificadoPazYSalvo = require("./certificados/CertificadoPazYSalvo");
const CertificadoProxyVirtual = require("./certificados/CertificadoProxyVirtual");
const CertificadoProxyCache = require("./certificados/CertificadoProxyCache");
const CertificadoProxyProteccion = require("./certificados/CertificadoProxyProteccion");

console.log("========================================");
console.log(" PRUEBA 1: Armar la cadena de proxies (el objeto real NO se crea todavía)");
console.log("========================================");
const virtual = new CertificadoProxyVirtual(() => new CertificadoPazYSalvo());
const cache = new CertificadoProxyCache(virtual);
const emisor = new CertificadoProxyProteccion(cache); // lo que usa el cliente
console.log("¿Se creó el servicio real?", virtual.estaCreado());
console.log("Instancias reales creadas:", CertificadoPazYSalvo.instancias);

const sesion = SesionManager.getInstance();

console.log("\n========================================");
console.log(" PRUEBA 2: Pedir un certificado SIN sesión iniciada (debe ser denegado)");
console.log("========================================");
try {
  emisor.emitir("estudiante-1001");
} catch (error) {
  console.log("Error capturado como se esperaba:", error.message);
}
console.log("Instancias reales creadas:", CertificadoPazYSalvo.instancias);

console.log("\n========================================");
console.log(" PRUEBA 3: Pedir un certificado con rol 'lector' (debe ser denegado)");
console.log("========================================");
sesion.login("lector1", "lector1");
try {
  emisor.emitir("estudiante-1001");
} catch (error) {
  console.log("Error capturado como se esperaba:", error.message);
}
console.log("Intentos denegados hasta ahora:", emisor.intentosDenegados);
console.log("Instancias reales creadas:", CertificadoPazYSalvo.instancias);

console.log("\n========================================");
console.log(" PRUEBA 4: Pedir un certificado con rol 'administrador' (se crea el real y se emite)");
console.log("========================================");
sesion.logout();
sesion.login("vmillan", "1234");
const certificado1 = emisor.emitir("estudiante-1001");
console.log("Certificado:", certificado1);
console.log("¿Se creó el servicio real?", virtual.estaCreado());
console.log("Instancias reales creadas:", CertificadoPazYSalvo.instancias);

console.log("\n========================================");
console.log(" PRUEBA 5: Pedir el MISMO certificado otra vez (sale del caché, sin repetir el trabajo)");
console.log("========================================");
const certificado2 = emisor.emitir("estudiante-1001");
console.log("¿Es el mismo certificado?", certificado1 === certificado2);
console.log("Aciertos de caché:", cache.aciertos);
console.log("Emisiones reales hechas:", virtual.real.emisiones);

console.log("\n========================================");
console.log(" PRUEBA 6: Pedir el certificado de OTRO estudiante (emisión nueva, mismo servicio real)");
console.log("========================================");
const certificado3 = emisor.emitir("estudiante-2002");
console.log("Certificado:", certificado3);
console.log("Emisiones reales hechas:", virtual.real.emisiones);
console.log("Instancias reales creadas (sigue siendo 1):", CertificadoPazYSalvo.instancias);

console.log("\n========================================");
console.log(" PRUEBA 7: Un 'bibliotecario' también está autorizado");
console.log("========================================");
sesion.logout();
sesion.login("lzafra", "abcd");
console.log("Certificado:", emisor.emitir("estudiante-3003"));

console.log("\n========================================");
console.log(" PRUEBA 8: Proxies y objeto real cumplen la MISMA interfaz");
console.log("========================================");
console.log("¿emisor (proxy) es EmisorCertificado?", emisor instanceof EmisorCertificado);
console.log("¿cache es EmisorCertificado?", cache instanceof EmisorCertificado);
console.log("¿virtual es EmisorCertificado?", virtual instanceof EmisorCertificado);
console.log("¿el objeto real es EmisorCertificado?", virtual.real instanceof EmisorCertificado);

console.log("\n========================================");
console.log(" PRUEBA 9: Intentar usar el Subject directamente (debe fallar)");
console.log("========================================");
try {
  new EmisorCertificado().emitir("estudiante-1001");
} catch (error) {
  console.log("Error capturado como se esperaba:", error.message);
}
