const EmisorCertificado = require("./EmisorCertificado");

class CertificadoProxyVirtual extends EmisorCertificado {
  constructor(crearEmisorReal) {
    super();
    this.crearEmisorReal = crearEmisorReal; // función, aún NO ejecutada
    this.real = null;
  }

  estaCreado() {
    return this.real !== null;
  }

  emitir(idUsuario) {
    if (!this.real) {
      console.log("[ProxyVirtual] Primera solicitud: creando el servicio real ahora.");
      this.real = this.crearEmisorReal();
    }
    return this.real.emitir(idUsuario);
  }
}

module.exports = CertificadoProxyVirtual;
