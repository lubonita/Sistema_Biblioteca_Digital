const EmisorCertificado = require("./EmisorCertificado");

class CertificadoProxyCache extends EmisorCertificado {
  constructor(emisor) {
    super();
    this.emisor = emisor;
    this.cache = new Map();
    this.aciertos = 0; // veces que se respondió desde el caché
  }

  emitir(idUsuario) {
    if (this.cache.has(idUsuario)) {
      this.aciertos++;
      console.log(`[ProxyCache] Certificado de ${idUsuario} devuelto desde caché.`);
      return this.cache.get(idUsuario);
    }
    const resultado = this.emisor.emitir(idUsuario);
    this.cache.set(idUsuario, resultado);
    return resultado;
  }
}

module.exports = CertificadoProxyCache;
