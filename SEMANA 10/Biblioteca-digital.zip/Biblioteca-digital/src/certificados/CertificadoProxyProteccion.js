const EmisorCertificado = require("./EmisorCertificado");
const SesionManager = require("../auth/SesionManager");

class CertificadoProxyProteccion extends EmisorCertificado {
  constructor(emisor, rolesPermitidos = ["administrador", "bibliotecario"]) {
    super();
    this.emisor = emisor;
    this.rolesPermitidos = rolesPermitidos;
    this.intentosDenegados = 0;
  }

  emitir(idUsuario) {
    const sesion = SesionManager.getInstance();

    if (!sesion.estaAutenticado()) {
      this.intentosDenegados++;
      throw new Error("Acceso denegado: debe iniciar sesión.");
    }

    const usuario = sesion.getUsuarioActual();
    if (!this.rolesPermitidos.includes(usuario.rol)) {
      this.intentosDenegados++;
      throw new Error(`Acceso denegado: el rol "${usuario.rol}" no puede emitir certificados.`);
    }

    console.log(`[ProxyProteccion] Acceso permitido a ${usuario.nombre} (${usuario.rol}).`);
    return this.emisor.emitir(idUsuario);
  }
}

module.exports = CertificadoProxyProteccion;
