class EmisorCertificado {
  emitir(idUsuario) {
    throw new Error("emitir() debe ser implementado por la subclase.");
  }
}

module.exports = EmisorCertificado;
