class FichaLibro {
  constructor() {
    // Datos obligatorios (mínimos para que la ficha tenga sentido)
    this.titulo = null;
    this.autor = null;

    // Datos opcionales
    this.portadaUrl = null;
    this.sinopsis = null;
    this.isbn = null;
    this.categorias = [];
    this.anioPublicacion = null;
    this.idioma = null;
    this.editorial = null;
    this.disponible = true;
  }

  getResumen() {
    const partes = [`"${this.titulo}" de ${this.autor}`];
    if (this.anioPublicacion) partes.push(`(${this.anioPublicacion})`);
    if (this.categorias.length > 0) partes.push(`[${this.categorias.join(", ")}]`);
    return partes.join(" ");
  }
}

module.exports = FichaLibro;
