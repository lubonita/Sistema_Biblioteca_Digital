class CatalogadorDirector {
  // Ficha mínima: solo lo indispensable para registrar el libro
  construirFichaBasica(builder, { titulo, autor }) {
    return builder
      .reset()
      .setTitulo(titulo)
      .setAutor(autor)
      .build();
  }

  // Ficha completa: todos los metadatos disponibles
  construirFichaCompleta(builder, datos) {
    return builder
      .reset()
      .setTitulo(datos.titulo)
      .setAutor(datos.autor)
      .setPortada(datos.portadaUrl)
      .setSinopsis(datos.sinopsis)
      .setISBN(datos.isbn)
      .setCategorias(datos.categorias || [])
      .setAnioPublicacion(datos.anioPublicacion)
      .setIdioma(datos.idioma)
      .setEditorial(datos.editorial)
      .setDisponible(datos.disponible !== undefined ? datos.disponible : true)
      .build();
  }
}

module.exports = CatalogadorDirector;
