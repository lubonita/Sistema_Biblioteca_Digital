const FichaLibro = require("./FichaLibro");

class FichaLibroBuilder {
  constructor() {
    this.reset();
  }

  // Reinicia el builder con una ficha en blanco
  reset() {
    this.ficha = new FichaLibro();
    return this;
  }

  setTitulo(titulo) {
    this.ficha.titulo = titulo;
    return this;
  }

  setAutor(autor) {
    this.ficha.autor = autor;
    return this;
  }

  setPortada(url) {
    this.ficha.portadaUrl = url;
    return this;
  }

  setSinopsis(texto) {
    this.ficha.sinopsis = texto;
    return this;
  }

  setISBN(isbn) {
    this.ficha.isbn = isbn;
    return this;
  }

  setCategorias(categorias) {
    this.ficha.categorias = categorias;
    return this;
  }

  setAnioPublicacion(anio) {
    this.ficha.anioPublicacion = anio;
    return this;
  }

  setIdioma(idioma) {
    this.ficha.idioma = idioma;
    return this;
  }

  setEditorial(editorial) {
    this.ficha.editorial = editorial;
    return this;
  }

  setDisponible(disponible) {
    this.ficha.disponible = disponible;
    return this;
  }

  // Extrae el resultado final y deja el builder listo para una ficha nueva
  build() {
    if (!this.ficha.titulo || !this.ficha.autor) {
      throw new Error("No se puede construir una FichaLibro sin título y autor.");
    }
    const resultado = this.ficha;
    this.reset();
    return resultado;
  }
}

module.exports = FichaLibroBuilder;
