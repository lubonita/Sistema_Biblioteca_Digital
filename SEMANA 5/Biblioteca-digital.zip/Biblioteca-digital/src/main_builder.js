/**
 * main_builder.js
 * ---------------------------------------------------
 * Pruebas por consola del patrón Builder aplicado a la
 * construcción de fichas de metadatos de libros digitales.
 * ---------------------------------------------------
 */

const FichaLibroBuilder = require("./libros/FichaLibro/FichaLibroBuilder");
const CatalogadorDirector = require("./libros/FichaLibro/CatalogadorDirector");

console.log("========================================");
console.log(" PRUEBA 1: Construir una ficha paso a paso, encadenando métodos");
console.log("========================================");
const builder = new FichaLibroBuilder();
const fichaManual = builder
  .setTitulo("Cien años de soledad")
  .setAutor("Gabriel García Márquez")
  .setAnioPublicacion(1967)
  .setCategorias(["Realismo mágico", "Literatura latinoamericana"])
  .build();
console.log("Ficha construida:", fichaManual.getResumen());
console.log("Sinopsis:", fichaManual.sinopsis); // null: nunca se llamó setSinopsis()

console.log("\n========================================");
console.log(" PRUEBA 2: Construir una ficha usando solo los campos obligatorios");
console.log("========================================");
const fichaMinima = new FichaLibroBuilder()
  .setTitulo("El túnel")
  .setAutor("Ernesto Sabato")
  .build();
console.log("Ficha mínima:", fichaMinima.getResumen());

console.log("\n========================================");
console.log(" PRUEBA 3: Intentar construir sin título ni autor (debe fallar)");
console.log("========================================");
try {
  new FichaLibroBuilder().setAnioPublicacion(2020).build();
} catch (error) {
  console.log("Error capturado como se esperaba:", error.message);
}

console.log("\n========================================");
console.log(" PRUEBA 4: Usar el Director para una ficha básica");
console.log("========================================");
const director = new CatalogadorDirector();
const builderParaDirector = new FichaLibroBuilder();
const fichaBasica = director.construirFichaBasica(builderParaDirector, {
  titulo: "Rayuela",
  autor: "Julio Cortázar",
});
console.log("Ficha básica (vía Director):", fichaBasica.getResumen());

console.log("\n========================================");
console.log(" PRUEBA 5: Usar el Director para una ficha completa");
console.log("========================================");
const fichaCompleta = director.construirFichaCompleta(builderParaDirector, {
  titulo: "1984",
  autor: "George Orwell",
  portadaUrl: "https://ejemplo.com/portadas/1984.jpg",
  sinopsis: "Una distopía sobre vigilancia y control totalitario.",
  isbn: "978-0451524935",
  categorias: ["Distopía", "Ciencia ficción"],
  anioPublicacion: 1949,
  idioma: "Español",
  editorial: "Secker & Warburg",
});
console.log("Ficha completa (vía Director):", fichaCompleta.getResumen());
console.log("ISBN:", fichaCompleta.isbn);
console.log("Portada:", fichaCompleta.portadaUrl);

console.log("\n========================================");
console.log(" PRUEBA 6: Confirmar que el mismo builder puede reutilizarse tras build()");
console.log("========================================");
console.log("¿fichaBasica y fichaCompleta son ficha distintas?", fichaBasica !== fichaCompleta);
console.log("Título de fichaBasica:", fichaBasica.titulo);
console.log("Título de fichaCompleta:", fichaCompleta.titulo);
