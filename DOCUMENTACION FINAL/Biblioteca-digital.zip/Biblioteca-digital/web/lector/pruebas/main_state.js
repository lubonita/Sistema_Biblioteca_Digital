"use strict";
// Pruebas del patrón State (FRONT). Las clases son las mismas que usa el
// navegador en web/lector/; aquí se ejecutan con Node para verlas por consola.
// Ejecutar desde la raíz del proyecto:  node web/lector/pruebas/main_state.js

const VisorLibro = require("../js/visor/VisorLibro");
const EstadoVisor = require("../js/visor/EstadoVisor");
const Observador = require("../js/observer/Observador");

const visor = new VisorLibro();
const rayuela = { titulo: "Rayuela" };
const probar = (texto, accion) => {
  try {
    accion();
  } catch (error) {
    console.log(`Error capturado (${texto}):`, error.message);
  }
};

console.log("========================================");
console.log(" PRUEBA 1: Estado inicial del visor");
console.log("========================================");
console.log("Estado:", visor.getEstado(), "| Botones habilitados:", visor.accionesPermitidas());

console.log("\n========================================");
console.log(" PRUEBA 2: Abrir un libro y terminar la carga");
console.log("========================================");
visor.abrir(rayuela);
console.log("Botones habilitados:", visor.accionesPermitidas());
visor.terminarCarga(3);
console.log(visor.getInfo());

console.log("\n========================================");
console.log(" PRUEBA 3: Pasar páginas hasta terminar el libro");
console.log("========================================");
visor.avanzar();
visor.avanzar();
console.log(`Página ${visor.pagina} de ${visor.totalPaginas}`);
visor.avanzar(); // desde la última página
console.log("Estado:", visor.getEstado(), "| Botones:", visor.accionesPermitidas());

console.log("\n========================================");
console.log(" PRUEBA 4: Pausar y reanudar");
console.log("========================================");
visor.reiniciar();
visor.pausar();
probar("avanzar en pausa", () => visor.avanzar());
visor.reanudar();
visor.avanzar();
console.log(`Página ${visor.pagina}, estado ${visor.getEstado()}`);

console.log("\n========================================");
console.log(" PRUEBA 5: Error de carga (sin licencia) y reintento");
console.log("========================================");
visor.cerrar();
visor.abrir({ titulo: "Dune" });
visor.fallarCarga("El préstamo no está aprobado: no hay licencia para leer.");
console.log("Estado:", visor.getEstado(), "| Error:", visor.error);
visor.reintentar();
visor.terminarCarga(5);
console.log("Estado:", visor.getEstado(), "| Página:", visor.pagina, "de", visor.totalPaginas);

console.log("\n========================================");
console.log(" PRUEBA 6: Transiciones inválidas fallan de forma explícita");
console.log("========================================");
probar("abrir con uno ya abierto", () => visor.abrir(rayuela));
probar("retroceder en la página 1", () => visor.retroceder());
probar("reanudar sin estar en pausa", () => visor.reanudar());
visor.cerrar();
probar("avanzar con el visor cerrado", () => visor.avanzar());
probar("terminar la carga sin estar cargando", () => visor.terminarCarga(10));
console.log("El estado no cambió con los errores:", visor.getEstado());

console.log("\n========================================");
console.log(" PRUEBA 7: Integración con Observer - la interfaz se entera de cada cambio");
console.log("========================================");
class BarraEstadoFalsa extends Observador {
  actualizar(evento, info) {
    if (evento === "ESTADO_VISOR") console.log(`[Interfaz] Estado: ${info.actual} | botones: ${info.acciones.join(", ")}`);
    if (evento === "PAGINA_VISOR") console.log(`[Interfaz] Página ${info.pagina}/${info.totalPaginas}`);
  }
}
visor.suscribir(new BarraEstadoFalsa());
visor.abrir(rayuela);
visor.terminarCarga(2);
visor.avanzar();
visor.pausar();

console.log("\n========================================");
console.log(" PRUEBA 8: Otros casos de error");
console.log("========================================");
probar("clase base", () => new EstadoVisor());
visor.cerrar();
probar("abrir sin libro", () => visor.abrir(null));
visor.abrir(rayuela);
probar("libro sin páginas", () => visor.terminarCarga(0));
