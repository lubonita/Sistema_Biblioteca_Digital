"use strict";
// Pruebas del patrón Strategy (FRONT). Las clases son las mismas que usa el
// navegador en web/lector/; aquí se ejecutan con Node para verlas por consola.
// Ejecutar desde la raíz del proyecto:  node web/lector/pruebas/main_strategy.js

const EstrategiaOrden = require("../js/estrategias/EstrategiaOrden");
const OrdenPorTitulo = require("../js/estrategias/OrdenPorTitulo");
const OrdenPorAutor = require("../js/estrategias/OrdenPorAutor");
const OrdenPorDisponibilidad = require("../js/estrategias/OrdenPorDisponibilidad");
const OrdenPorExtension = require("../js/estrategias/OrdenPorExtension");
const OrdenadorCatalogo = require("../js/estrategias/OrdenadorCatalogo");

// Mismo catálogo que entrega el back al portal (web/api/lector.js)
const catalogo = [
  { titulo: "Rayuela", autor: "Julio Cortázar", formato: "EPUB", paginas: 6, licencias: 3 },
  { titulo: "Dune", autor: "Frank Herbert", formato: "PDF", paginas: 8, licencias: 2 },
  { titulo: "Fundación", autor: "Isaac Asimov", formato: "MOBI", paginas: 5, licencias: 1 },
  { titulo: "Ficciones", autor: "Jorge Luis Borges", formato: "PDF", paginas: 4, licencias: 2 },
  { titulo: "Cien años de soledad", autor: "Gabriel García Márquez", formato: "EPUB", paginas: 10, licencias: 0 },
];
const mostrar = (lista, dato) => lista.forEach((l, i) => console.log(`  ${i + 1}. ${l.titulo} — ${dato(l)}`));
const probar = (texto, accion) => {
  try {
    accion();
  } catch (error) {
    console.log(`Error capturado (${texto}):`, error.message);
  }
};

const ordenador = new OrdenadorCatalogo(new OrdenPorTitulo());

console.log("========================================");
console.log(" PRUEBA 1: Estrategia inicial (título A-Z)");
console.log("========================================");
console.log("Estrategia actual:", ordenador.getEstrategia());
mostrar(ordenador.ordenar(catalogo), (l) => l.autor);

console.log("\n========================================");
console.log(" PRUEBA 2: Cambiar a orden por autor (mismo contexto)");
console.log("========================================");
ordenador.setEstrategia(new OrdenPorAutor());
mostrar(ordenador.ordenar(catalogo), (l) => l.autor);

console.log("\n========================================");
console.log(" PRUEBA 3: Más licencias libres primero");
console.log("========================================");
ordenador.setEstrategia(new OrdenPorDisponibilidad());
mostrar(ordenador.ordenar(catalogo), (l) => `${l.licencias} licencia(s)`);

console.log("\n========================================");
console.log(" PRUEBA 4: Lectura más corta primero");
console.log("========================================");
ordenador.setEstrategia(new OrdenPorExtension());
mostrar(ordenador.ordenar(catalogo), (l) => `${l.paginas} páginas`);

console.log("\n========================================");
console.log(" PRUEBA 5: Mismo contexto, distinto resultado");
console.log("========================================");
const estrategias = [new OrdenPorTitulo(), new OrdenPorAutor(), new OrdenPorDisponibilidad(), new OrdenPorExtension()];
estrategias.forEach((e) => {
  ordenador.setEstrategia(e);
  console.log(`  ${e.nombre.padEnd(22)} → primero: ${ordenador.ordenar(catalogo)[0].titulo}`);
});
console.log("El catálogo original no se modificó:", catalogo.map((l) => l.titulo).join(", "));

console.log("\n========================================");
console.log(" PRUEBA 6: Nueva estrategia sin modificar el contexto");
console.log("========================================");
class OrdenPorFormato extends EstrategiaOrden {
  get nombre() { return "Formato"; }
  ordenar(libros) {
    return [...libros].sort((a, b) => a.formato.localeCompare(b.formato) || a.titulo.localeCompare(b.titulo, "es"));
  }
}
ordenador.setEstrategia(new OrdenPorFormato());
mostrar(ordenador.ordenar(catalogo), (l) => l.formato);

console.log("\n========================================");
console.log(" PRUEBA 7: Casos de error");
console.log("========================================");
probar("estrategia que no es EstrategiaOrden", () => ordenador.setEstrategia({ ordenar: (l) => l }));
probar("instanciar la clase abstracta", () => new EstrategiaOrden());
probar("ordenar algo que no es lista", () => ordenador.ordenar("Rayuela"));
console.log("La estrategia sigue siendo:", ordenador.getEstrategia());
