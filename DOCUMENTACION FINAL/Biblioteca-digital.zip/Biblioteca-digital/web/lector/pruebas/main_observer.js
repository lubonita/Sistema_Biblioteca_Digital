"use strict";
// Pruebas del patrón Observer (FRONT). Las clases son las mismas que usa el
// navegador en web/lector/; aquí se ejecutan con Node para verlas por consola.
// Ejecutar desde la raíz del proyecto:  node web/lector/pruebas/main_observer.js

const Observador = require("../js/observer/Observador");
const Sujeto = require("../js/observer/Sujeto");
const MisSolicitudesSujeto = require("../js/observer/MisSolicitudesSujeto");
const ContadorCampana = require("../js/observer/ContadorCampana");
const ListaMisSolicitudes = require("../js/observer/ListaMisSolicitudes");
const AvisoEmergente = require("../js/observer/AvisoEmergente");
const HistorialActividad = require("../js/observer/HistorialActividad");

// En el navegador son elementos de la página; aquí, objetos simples
const campana = { textContent: "" };
const contenedorLista = { innerHTML: "" };
const contenedorHistorial = { textContent: "" };

const misSolicitudes = new MisSolicitudesSujeto();
const contador = new ContadorCampana(campana);
const lista = new ListaMisSolicitudes(contenedorLista);
const aviso = new AvisoEmergente((texto, tipo) => console.log(`[AvisoEmergente] (${tipo}) ${texto}`));
const historial = new HistorialActividad(contenedorHistorial);

console.log("========================================");
console.log(" PRUEBA 1: Suscribir cuatro observadores al mismo sujeto");
console.log("========================================");
[contador, lista, aviso, historial].forEach((o) => misSolicitudes.suscribir(o));
console.log("Observadores suscritos:", misSolicitudes.cantidadObservadores());

console.log("\n========================================");
console.log(" PRUEBA 2: Primera carga desde el servidor (solo se dibuja la lista)");
console.log("========================================");
misSolicitudes.actualizarDesdeServidor([
  { id: "SOL-001", libro: "Rayuela", estado: "PENDIENTE" },
  { id: "SOL-002", libro: "Dune", estado: "PENDIENTE" },
]);
console.log("Solicitudes dibujadas en la lista:", lista.dibujadas);
console.log("Contador de la campana:", JSON.stringify(campana.textContent));

console.log("\n========================================");
console.log(" PRUEBA 3: El bibliotecario aprueba SOL-001 -> todos se actualizan solos");
console.log("========================================");
misSolicitudes.actualizarDesdeServidor([
  { id: "SOL-001", libro: "Rayuela", estado: "APROBADA" },
  { id: "SOL-002", libro: "Dune", estado: "PENDIENTE" },
]);
console.log("Campana:", campana.textContent, "| ¿La lista tiene botón Leer?", contenedorLista.innerHTML.includes("Leer"));
console.log("Historial:", contenedorHistorial.textContent.split("\n")[0].slice(10));

console.log("\n========================================");
console.log(" PRUEBA 4: Sin cambios no se notifica nada nuevo");
console.log("========================================");
misSolicitudes.actualizarDesdeServidor([
  { id: "SOL-001", libro: "Rayuela", estado: "APROBADA" },
  { id: "SOL-002", libro: "Dune", estado: "PENDIENTE" },
]);
console.log("Campana sigue en:", campana.textContent);

console.log("\n========================================");
console.log(" PRUEBA 5: Rechazo con motivo y solicitud nueva");
console.log("========================================");
misSolicitudes.actualizarDesdeServidor([
  { id: "SOL-001", libro: "Rayuela", estado: "APROBADA" },
  { id: "SOL-002", libro: "Dune", estado: "RECHAZADA", motivo: "Licencia reservada" },
  { id: "SOL-003", libro: "Fundación", estado: "PENDIENTE" },
]);
console.log("Campana:", campana.textContent);
contador.marcarLeidos();
console.log("Tras marcar como leídos:", JSON.stringify(campana.textContent));

console.log("\n========================================");
console.log(" PRUEBA 6: Agregar un observador nuevo sin modificar el sujeto");
console.log("========================================");
class ContadorAprobados extends Observador {
  constructor() { super(); this.total = 0; }
  actualizar(evento, s) {
    if (evento === "SOLICITUD_CAMBIO" && s.estado === "APROBADA") {
      this.total++;
      console.log(`[ContadorAprobados] Préstamos aprobados: ${this.total}`);
    }
  }
}
const aprobados = new ContadorAprobados();
misSolicitudes.suscribir(aprobados);
misSolicitudes.actualizarDesdeServidor([
  { id: "SOL-001", libro: "Rayuela", estado: "APROBADA" },
  { id: "SOL-002", libro: "Dune", estado: "RECHAZADA", motivo: "Licencia reservada" },
  { id: "SOL-003", libro: "Fundación", estado: "APROBADA" },
]);

console.log("\n========================================");
console.log(" PRUEBA 7: Desuscribir un observador");
console.log("========================================");
misSolicitudes.desuscribir(aviso);
console.log("Observadores suscritos:", misSolicitudes.cantidadObservadores());
misSolicitudes.actualizarDesdeServidor([
  { id: "SOL-001", libro: "Rayuela", estado: "APROBADA" },
  { id: "SOL-002", libro: "Dune", estado: "RECHAZADA", motivo: "Licencia reservada" },
  { id: "SOL-003", libro: "Fundación", estado: "PENDIENTE" },
]);
console.log("(El aviso emergente ya no se mostró; la campana sí cambió a", campana.textContent + ")");

console.log("\n========================================");
console.log(" PRUEBA 8: Casos de error");
console.log("========================================");
try {
  new Sujeto();
} catch (error) {
  console.log("Error capturado (clase base):", error.message);
}
try {
  misSolicitudes.suscribir({ actualizar() {} });
} catch (error) {
  console.log("Error capturado (no es Observador):", error.message);
}
try {
  misSolicitudes.actualizarDesdeServidor("SOL-001 APROBADA");
} catch (error) {
  console.log("Error capturado (datos inválidos):", error.message);
}
try {
  new AvisoEmergente("mostrar");
} catch (error) {
  console.log("Error capturado (aviso sin función):", error.message);
}
