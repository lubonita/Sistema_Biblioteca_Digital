(function (raiz) {
  "use strict";
  const EstadoVisor = raiz.EstadoVisor || require("./EstadoVisor");

  class EstadoTerminado extends EstadoVisor {
    get nombre() { return "TERMINADO"; }
    accionesPermitidas() { return ["reiniciar", "cerrar"]; }

    reiniciar(visor) {
      visor.pagina = 1;
      visor.cambiarEstado(new (EstadoVisor.clase("EstadoLeyendo"))());
    }

    cerrar(visor) {
      visor.cambiarEstado(new (EstadoVisor.clase("EstadoCerrado"))());
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = EstadoTerminado;
  else raiz.EstadoTerminado = EstadoTerminado;
})(typeof window !== "undefined" ? window : globalThis);
