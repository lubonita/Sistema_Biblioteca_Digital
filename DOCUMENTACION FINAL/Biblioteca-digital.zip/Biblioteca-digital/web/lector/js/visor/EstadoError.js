(function (raiz) {
  "use strict";
  const EstadoVisor = raiz.EstadoVisor || require("./EstadoVisor");

  class EstadoError extends EstadoVisor {
    get nombre() { return "ERROR"; }
    accionesPermitidas() { return ["reintentar", "cerrar"]; }

    reintentar(visor) {
      visor.error = null;
      visor.cambiarEstado(new (EstadoVisor.clase("EstadoCargando"))());
    }

    cerrar(visor) {
      visor.cambiarEstado(new (EstadoVisor.clase("EstadoCerrado"))());
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = EstadoError;
  else raiz.EstadoError = EstadoError;
})(typeof window !== "undefined" ? window : globalThis);
