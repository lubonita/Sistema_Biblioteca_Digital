(function (raiz) {
  "use strict";

  class EstadoVisor {
    constructor() {
      if (new.target === EstadoVisor) {
        throw new Error("EstadoVisor es una clase base y no puede instanciarse directamente.");
      }
    }

    get nombre() {
      throw new Error("Cada estado debe tener un nombre.");
    }

    // Acciones que los botones de la interfaz pueden usar en este estado
    accionesPermitidas() {
      return [];
    }

    #invalida(accion) {
      throw new Error(`No se puede "${accion}" cuando el visor está ${this.nombre}.`);
    }

    abrir(visor, libro) { this.#invalida("abrir"); }
    terminarCarga(visor, totalPaginas) { this.#invalida("terminar la carga"); }
    fallarCarga(visor, motivo) { this.#invalida("fallar la carga"); }
    avanzar(visor) { this.#invalida("avanzar"); }
    retroceder(visor) { this.#invalida("retroceder"); }
    pausar(visor) { this.#invalida("pausar"); }
    reanudar(visor) { this.#invalida("reanudar"); }
    reiniciar(visor) { this.#invalida("reiniciar"); }
    reintentar(visor) { this.#invalida("reintentar"); }
    cerrar(visor) { this.#invalida("cerrar"); }

    // Obtiene la clase de otro estado (en el navegador está en window; en Node se carga)
    static clase(nombre) {
      return raiz[nombre] || require("./" + nombre);
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = EstadoVisor;
  else raiz.EstadoVisor = EstadoVisor;
})(typeof window !== "undefined" ? window : globalThis);
