(function (raiz) {
  "use strict";
  const EstadoVisor = raiz.EstadoVisor || require("./EstadoVisor");

  class EstadoCerrado extends EstadoVisor {
    get nombre() { return "CERRADO"; }
    accionesPermitidas() { return ["abrir"]; }

    abrir(visor, libro) {
      if (!libro || !libro.titulo) throw new Error("Para abrir el visor se necesita un libro con título.");
      visor.libro = libro;
      visor.error = null;
      visor.cambiarEstado(new (EstadoVisor.clase("EstadoCargando"))());
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = EstadoCerrado;
  else raiz.EstadoCerrado = EstadoCerrado;
})(typeof window !== "undefined" ? window : globalThis);
