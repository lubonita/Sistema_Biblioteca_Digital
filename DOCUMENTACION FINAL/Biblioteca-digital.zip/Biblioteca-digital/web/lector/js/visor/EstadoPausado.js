(function (raiz) {
  "use strict";
  const EstadoVisor = raiz.EstadoVisor || require("./EstadoVisor");

  class EstadoPausado extends EstadoVisor {
    get nombre() { return "PAUSADO"; }
    accionesPermitidas() { return ["reanudar", "cerrar"]; }

    reanudar(visor) {
      visor.cambiarEstado(new (EstadoVisor.clase("EstadoLeyendo"))());
    }

    cerrar(visor) {
      visor.cambiarEstado(new (EstadoVisor.clase("EstadoCerrado"))());
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = EstadoPausado;
  else raiz.EstadoPausado = EstadoPausado;
})(typeof window !== "undefined" ? window : globalThis);
