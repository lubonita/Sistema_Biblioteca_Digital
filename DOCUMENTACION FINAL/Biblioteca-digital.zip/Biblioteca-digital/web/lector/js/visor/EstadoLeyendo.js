(function (raiz) {
  "use strict";
  const EstadoVisor = raiz.EstadoVisor || require("./EstadoVisor");

  class EstadoLeyendo extends EstadoVisor {
    get nombre() { return "LEYENDO"; }
    accionesPermitidas() { return ["retroceder", "avanzar", "pausar", "cerrar"]; }

    avanzar(visor) {
      if (visor.pagina >= visor.totalPaginas) {
        visor.cambiarEstado(new (EstadoVisor.clase("EstadoTerminado"))());
        return;
      }
      visor.irAPagina(visor.pagina + 1);
    }

    retroceder(visor) {
      if (visor.pagina <= 1) throw new Error("Ya estás en la primera página.");
      visor.irAPagina(visor.pagina - 1);
    }

    pausar(visor) {
      visor.cambiarEstado(new (EstadoVisor.clase("EstadoPausado"))());
    }

    cerrar(visor) {
      visor.cambiarEstado(new (EstadoVisor.clase("EstadoCerrado"))());
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = EstadoLeyendo;
  else raiz.EstadoLeyendo = EstadoLeyendo;
})(typeof window !== "undefined" ? window : globalThis);
