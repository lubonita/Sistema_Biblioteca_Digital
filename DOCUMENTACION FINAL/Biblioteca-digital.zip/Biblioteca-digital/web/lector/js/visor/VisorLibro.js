(function (raiz) {
  "use strict";
  const Sujeto = raiz.Sujeto || require("../observer/Sujeto");
  const EstadoCerrado = raiz.EstadoCerrado || require("./EstadoCerrado");

  class VisorLibro extends Sujeto {
    #estado = new EstadoCerrado();

    constructor() {
      super();
      this.libro = null;
      this.pagina = 0;
      this.totalPaginas = 0;
      this.error = null;
    }

    // Acciones: todas se delegan al estado actual
    abrir(libro) { this.#estado.abrir(this, libro); }
    terminarCarga(totalPaginas) { this.#estado.terminarCarga(this, totalPaginas); }
    fallarCarga(motivo) { this.#estado.fallarCarga(this, motivo); }
    avanzar() { this.#estado.avanzar(this); }
    retroceder() { this.#estado.retroceder(this); }
    pausar() { this.#estado.pausar(this); }
    reanudar() { this.#estado.reanudar(this); }
    reiniciar() { this.#estado.reiniciar(this); }
    reintentar() { this.#estado.reintentar(this); }
    cerrar() { this.#estado.cerrar(this); }

    // Lo usan los estados para hacer la transición
    cambiarEstado(nuevoEstado) {
      const anterior = this.#estado.nombre;
      this.#estado = nuevoEstado;
      if (nuevoEstado.nombre === "CERRADO") {
        this.pagina = 0;
        this.totalPaginas = 0;
      }
      console.log(`[VisorLibro] ${anterior} → ${nuevoEstado.nombre}`);
      this.notificar("ESTADO_VISOR", { anterior, actual: nuevoEstado.nombre, ...this.getInfo() });
    }

    irAPagina(numero) {
      this.pagina = numero;
      this.notificar("PAGINA_VISOR", this.getInfo());
    }

    getEstado() {
      return this.#estado.nombre;
    }

    accionesPermitidas() {
      return this.#estado.accionesPermitidas();
    }

    getInfo() {
      return {
        estado: this.#estado.nombre,
        libro: this.libro ? this.libro.titulo : null,
        pagina: this.pagina,
        totalPaginas: this.totalPaginas,
        error: this.error,
        acciones: this.#estado.accionesPermitidas(),
      };
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = VisorLibro;
  else raiz.VisorLibro = VisorLibro;
})(typeof window !== "undefined" ? window : globalThis);
