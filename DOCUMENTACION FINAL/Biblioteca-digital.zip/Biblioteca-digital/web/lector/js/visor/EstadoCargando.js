(function (raiz) {
  "use strict";
  const EstadoVisor = raiz.EstadoVisor || require("./EstadoVisor");

  class EstadoCargando extends EstadoVisor {
    get nombre() { return "CARGANDO"; }
    accionesPermitidas() { return ["cerrar"]; }

    terminarCarga(visor, totalPaginas) {
      if (!Number.isInteger(totalPaginas) || totalPaginas < 1) throw new Error("El libro debe tener al menos una página.");
      visor.totalPaginas = totalPaginas;
      visor.pagina = 1;
      visor.cambiarEstado(new (EstadoVisor.clase("EstadoLeyendo"))());
    }

    fallarCarga(visor, motivo) {
      visor.error = motivo || "Error desconocido";
      visor.cambiarEstado(new (EstadoVisor.clase("EstadoError"))());
    }

    cerrar(visor) {
      visor.cambiarEstado(new (EstadoVisor.clase("EstadoCerrado"))());
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = EstadoCargando;
  else raiz.EstadoCargando = EstadoCargando;
})(typeof window !== "undefined" ? window : globalThis);
