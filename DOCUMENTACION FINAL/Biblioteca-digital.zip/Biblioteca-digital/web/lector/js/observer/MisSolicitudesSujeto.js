(function (raiz) {
  "use strict";
  const Sujeto = raiz.Sujeto || require("./Sujeto");

  class MisSolicitudesSujeto extends Sujeto {
    #estados = new Map(); // id -> estado conocido
    #solicitudes = [];
    #primeraCarga = true;

    actualizarDesdeServidor(lista) {
      if (!Array.isArray(lista)) throw new Error("Se esperaba la lista de solicitudes del servidor.");
      for (const s of lista) {
        const anterior = this.#estados.get(s.id);
        if (anterior === undefined && !this.#primeraCarga) {
          this.notificar("SOLICITUD_NUEVA", { ...s });
        } else if (anterior !== undefined && anterior !== s.estado) {
          this.notificar("SOLICITUD_CAMBIO", { ...s, anterior });
        }
        this.#estados.set(s.id, s.estado);
      }
      this.#solicitudes = lista.map((s) => ({ ...s }));
      this.#primeraCarga = false;
      this.notificar("LISTA_ACTUALIZADA", this.getSolicitudes());
    }

    getSolicitudes() {
      return this.#solicitudes.map((s) => ({ ...s }));
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = MisSolicitudesSujeto;
  else raiz.MisSolicitudesSujeto = MisSolicitudesSujeto;
})(typeof window !== "undefined" ? window : globalThis);
