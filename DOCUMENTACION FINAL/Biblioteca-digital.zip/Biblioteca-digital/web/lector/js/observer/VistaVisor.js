(function (raiz) {
  "use strict";
  const Observador = raiz.Observador || require("./Observador");

  class VistaVisor extends Observador {
    constructor(elementos) {
      super();
      this.el = elementos; // { estado, titulo, pagina, texto, error, botones: { accion: <button> } }
    }

    actualizar(evento, info) {
      if (evento !== "ESTADO_VISOR" && evento !== "PAGINA_VISOR") return;
      const el = this.el;
      if (!el) return;
      el.estado.textContent = info.estado;
      el.estado.dataset.estado = info.estado;
      el.titulo.textContent = info.libro || "Ningún libro abierto";
      el.pagina.textContent = info.totalPaginas ? `Página ${info.pagina} de ${info.totalPaginas}` : "";
      el.error.textContent = info.error || "";
      el.texto.textContent = VistaVisor.textoPagina(info);
      // Solo se habilitan los botones que el estado actual permite
      Object.entries(el.botones).forEach(([accion, boton]) => {
        boton.disabled = !info.acciones.includes(accion);
      });
    }

    static textoPagina(info) {
      const mensajes = {
        CERRADO: "Elige un préstamo aprobado en \"Mis préstamos\" y pulsa Leer.",
        CARGANDO: "Verificando la licencia y descargando el libro…",
        PAUSADO: "Lectura en pausa. Pulsa Reanudar para continuar.",
        TERMINADO: "Llegaste al final del libro. Puedes volver a empezar o cerrar.",
        ERROR: "No se pudo abrir el libro.",
      };
      if (info.estado !== "LEYENDO") return mensajes[info.estado] || "";
      return `Contenido de demostración de "${info.libro}", página ${info.pagina}.\n\n` +
        "En el sistema real aquí se mostraría el texto del libro digital en su formato (PDF, EPUB o MOBI). " +
        "Este visor existe para mostrar cómo cambia el comportamiento según el estado.";
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = VistaVisor;
  else raiz.VistaVisor = VistaVisor;
})(typeof window !== "undefined" ? window : globalThis);
