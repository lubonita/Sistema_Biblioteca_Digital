(function (raiz) {
  "use strict";
  const Observador = raiz.Observador || require("./Observador");
  const esc = (t) => String(t ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  class ListaMisSolicitudes extends Observador {
    constructor(elemento) {
      super();
      this.elemento = elemento; // en el navegador, el contenedor de la lista
      this.dibujadas = 0;
    }

    actualizar(evento, solicitudes) {
      if (evento !== "LISTA_ACTUALIZADA") return;
      this.dibujadas = solicitudes.length;
      if (!this.elemento) return;
      this.elemento.innerHTML = solicitudes.length
        ? solicitudes.map((s) => `
            <div class="solicitud" data-id="${esc(s.id)}">
              <div class="info"><b>${esc(s.libro)}</b><span>${esc(s.id)}${s.motivo ? " · " + esc(s.motivo) : ""}</span></div>
              <span class="pill ${esc(s.estado)}">${esc(s.estado)}</span>
              ${s.estado === "APROBADA" ? `<button class="btn-primary" onclick="abrirLibro('${esc(s.id)}')">Leer</button>` : ""}
              ${s.estado === "PENDIENTE" || s.estado === "EN_REVISION" ? `<button class="btn-sec" onclick="abrirLibro('${esc(s.id)}')">Intentar leer</button>` : ""}
            </div>`).join("")
        : '<div class="vacio">Aún no has pedido préstamos.</div>';
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = ListaMisSolicitudes;
  else raiz.ListaMisSolicitudes = ListaMisSolicitudes;
})(typeof window !== "undefined" ? window : globalThis);
