(function (raiz) {
  "use strict";
  const Observador = raiz.Observador || require("./Observador");

  const MENSAJES = {
    APROBADA: (s) => `¡Tu préstamo de "${s.libro}" fue aprobado! Ya puedes leerlo.`,
    RECHAZADA: (s) => `Tu solicitud de "${s.libro}" fue rechazada${s.motivo ? ": " + s.motivo : "."}`,
    EN_REVISION: (s) => `Tu solicitud de "${s.libro}" está en revisión.`,
    PENDIENTE: (s) => `Tu solicitud de "${s.libro}" volvió a quedar pendiente.`,
  };

  class AvisoEmergente extends Observador {
    constructor(mostrar) {
      super();
      if (typeof mostrar !== "function") throw new Error("AvisoEmergente necesita una función para mostrar mensajes.");
      this.mostrar = mostrar; // en el navegador, la función que pinta el aviso
    }

    actualizar(evento, s) {
      if (evento !== "SOLICITUD_CAMBIO") return;
      const crear = MENSAJES[s.estado];
      if (crear) this.mostrar(crear(s), s.estado);
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = AvisoEmergente;
  else raiz.AvisoEmergente = AvisoEmergente;
})(typeof window !== "undefined" ? window : globalThis);
