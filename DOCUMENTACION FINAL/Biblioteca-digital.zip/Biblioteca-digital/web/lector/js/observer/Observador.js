
(function (raiz) {
  "use strict";

  class Observador {
    constructor() {
      if (new.target === Observador) {
        throw new Error("Observador es una interfaz y no puede instanciarse directamente.");
      }
    }

    actualizar(evento, datos, sujeto) {
      throw new Error("actualizar() debe ser implementado por la subclase.");
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = Observador;
  else raiz.Observador = Observador;
})(typeof window !== "undefined" ? window : globalThis);
