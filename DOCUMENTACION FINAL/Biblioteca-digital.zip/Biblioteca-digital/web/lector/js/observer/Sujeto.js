(function (raiz) {
  "use strict";
  const Observador = raiz.Observador || require("./Observador");

  class Sujeto {
    #observadores = [];

    constructor() {
      if (new.target === Sujeto) {
        throw new Error("Sujeto es una clase base y no puede instanciarse directamente.");
      }
    }

    suscribir(observador) {
      if (!(observador instanceof Observador)) {
        throw new Error("Solo se pueden suscribir objetos Observador.");
      }
      if (!this.#observadores.includes(observador)) this.#observadores.push(observador);
      return () => this.desuscribir(observador); // función para cancelar la suscripción
    }

    desuscribir(observador) {
      this.#observadores = this.#observadores.filter((o) => o !== observador);
    }

    notificar(evento, datos) {
      // Se recorre una copia por si un observador se desuscribe mientras se notifica
      [...this.#observadores].forEach((o) => o.actualizar(evento, datos, this));
    }

    cantidadObservadores() {
      return this.#observadores.length;
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = Sujeto;
  else raiz.Sujeto = Sujeto;
})(typeof window !== "undefined" ? window : globalThis);
