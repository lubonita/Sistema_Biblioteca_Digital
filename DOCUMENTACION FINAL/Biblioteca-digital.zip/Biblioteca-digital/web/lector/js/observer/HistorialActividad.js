(function (raiz) {
  "use strict";
  const Observador = raiz.Observador || require("./Observador");

  class HistorialActividad extends Observador {
    constructor(elemento, maximo = 12) {
      super();
      this.elemento = elemento;
      this.maximo = maximo;
      this.lineas = [];
    }

    actualizar(evento, d) {
      let texto = null;
      if (evento === "SOLICITUD_NUEVA") texto = `${d.id}: solicitud registrada (${d.estado})`;
      else if (evento === "SOLICITUD_CAMBIO") texto = `${d.id}: ${d.anterior} → ${d.estado}`;
      else if (evento === "ESTADO_VISOR") texto = `Visor: ${d.anterior} → ${d.actual}${d.libro ? ` ("${d.libro}")` : ""}`;
      if (!texto) return;
      const d0 = new Date();
      const hora = [d0.getHours(), d0.getMinutes(), d0.getSeconds()].map((n) => String(n).padStart(2, "0")).join(":");
      this.lineas.unshift(`${hora}  ${texto}`);
      this.lineas = this.lineas.slice(0, this.maximo);
      if (this.elemento) this.elemento.textContent = this.lineas.join("\n");
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = HistorialActividad;
  else raiz.HistorialActividad = HistorialActividad;
})(typeof window !== "undefined" ? window : globalThis);
