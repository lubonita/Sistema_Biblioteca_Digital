
(function (raiz) {
  "use strict";
  const Observador = raiz.Observador || require("./Observador");

  class ContadorCampana extends Observador {
    constructor(elemento) {
      super();
      this.elemento = elemento; // en el navegador, el <span> de la campana
      this.sinLeer = 0;
    }

    actualizar(evento) {
      if (evento !== "SOLICITUD_CAMBIO") return;
      this.sinLeer++;
      this.#pintar();
      console.log(`[ContadorCampana] ${this.sinLeer} aviso(s) sin leer`);
    }

    marcarLeidos() {
      this.sinLeer = 0;
      this.#pintar();
    }

    #pintar() {
      if (this.elemento) this.elemento.textContent = this.sinLeer ? String(this.sinLeer) : "";
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = ContadorCampana;
  else raiz.ContadorCampana = ContadorCampana;
})(typeof window !== "undefined" ? window : globalThis);
