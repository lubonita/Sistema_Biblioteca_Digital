(function (raiz) {
  "use strict";
  const EstrategiaOrden = raiz.EstrategiaOrden || require("./EstrategiaOrden");

  class OrdenPorTitulo extends EstrategiaOrden {
    get nombre() { return "Título (A-Z)"; }

    ordenar(libros) {
      return [...libros].sort((a, b) => a.titulo.localeCompare(b.titulo, "es"));
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = OrdenPorTitulo;
  else raiz.OrdenPorTitulo = OrdenPorTitulo;
})(typeof window !== "undefined" ? window : globalThis);
