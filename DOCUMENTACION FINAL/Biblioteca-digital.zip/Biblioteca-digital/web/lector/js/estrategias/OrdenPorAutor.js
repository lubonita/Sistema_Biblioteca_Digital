(function (raiz) {
  "use strict";
  const EstrategiaOrden = raiz.EstrategiaOrden || require("./EstrategiaOrden");

  class OrdenPorAutor extends EstrategiaOrden {
    get nombre() { return "Autor (A-Z)"; }

    ordenar(libros) {
      return [...libros].sort((a, b) => a.autor.localeCompare(b.autor, "es") || a.titulo.localeCompare(b.titulo, "es"));
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = OrdenPorAutor;
  else raiz.OrdenPorAutor = OrdenPorAutor;
})(typeof window !== "undefined" ? window : globalThis);
