(function (raiz) {
  "use strict";
  const EstrategiaOrden = raiz.EstrategiaOrden || require("./EstrategiaOrden");

  class OrdenPorDisponibilidad extends EstrategiaOrden {
    get nombre() { return "Más licencias libres"; }

    ordenar(libros) {
      return [...libros].sort((a, b) => b.licencias - a.licencias || a.titulo.localeCompare(b.titulo, "es"));
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = OrdenPorDisponibilidad;
  else raiz.OrdenPorDisponibilidad = OrdenPorDisponibilidad;
})(typeof window !== "undefined" ? window : globalThis);
