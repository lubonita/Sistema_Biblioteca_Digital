(function (raiz) {
  "use strict";
  const EstrategiaOrden = raiz.EstrategiaOrden || require("./EstrategiaOrden");

  class OrdenPorExtension extends EstrategiaOrden {
    get nombre() { return "Lectura más corta"; }

    ordenar(libros) {
      return [...libros].sort((a, b) => a.paginas - b.paginas || a.titulo.localeCompare(b.titulo, "es"));
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = OrdenPorExtension;
  else raiz.OrdenPorExtension = OrdenPorExtension;
})(typeof window !== "undefined" ? window : globalThis);
