(function (raiz) {
  "use strict";

  class EstrategiaOrden {
    constructor() {
      if (new.target === EstrategiaOrden) {
        throw new Error("EstrategiaOrden es una clase base y no puede instanciarse directamente.");
      }
    }

    // Texto que se muestra en el selector del portal
    get nombre() {
      throw new Error("Cada estrategia debe tener un nombre.");
    }

    // Recibe la lista de libros y devuelve una lista NUEVA ordenada (no modifica la original)
    ordenar(libros) {
      throw new Error("ordenar() debe ser implementado por la estrategia concreta.");
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = EstrategiaOrden;
  else raiz.EstrategiaOrden = EstrategiaOrden;
})(typeof window !== "undefined" ? window : globalThis);
