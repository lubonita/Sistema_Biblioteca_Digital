(function (raiz) {
  "use strict";
  const EstrategiaOrden = raiz.EstrategiaOrden || require("./EstrategiaOrden");

  class OrdenadorCatalogo {
    #estrategia;

    constructor(estrategiaInicial) {
      this.#validar(estrategiaInicial);
      this.#estrategia = estrategiaInicial;
    }

    #validar(estrategia) {
      if (!(estrategia instanceof EstrategiaOrden)) {
        throw new Error("OrdenadorCatalogo solo acepta objetos que sean EstrategiaOrden.");
      }
    }

    // Cambio de algoritmo en tiempo de ejecución
    setEstrategia(estrategia) {
      this.#validar(estrategia);
      const anterior = this.#estrategia.nombre;
      this.#estrategia = estrategia;
      console.log(`[OrdenadorCatalogo] Estrategia: ${anterior} → ${estrategia.nombre}`);
    }

    getEstrategia() {
      return this.#estrategia.nombre;
    }

    ordenar(libros) {
      if (!Array.isArray(libros)) throw new Error("Para ordenar se necesita una lista de libros.");
      return this.#estrategia.ordenar(libros);
    }
  }

  if (typeof module !== "undefined" && module.exports) module.exports = OrdenadorCatalogo;
  else raiz.OrdenadorCatalogo = OrdenadorCatalogo;
})(typeof window !== "undefined" ? window : globalThis);
