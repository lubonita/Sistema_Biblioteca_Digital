"use strict";

// Adaptador web del patrón Command (src/solicitudes/comandos).
// Usa el ServicioSolicitudes compartido (donde llegan las solicitudes que
// pasaron la cadena) y el PanelBibliotecario real como invocador.

const AprobarSolicitudCommand = require("../../src/solicitudes/comandos/AprobarSolicitudCommand");
const RechazarSolicitudCommand = require("../../src/solicitudes/comandos/RechazarSolicitudCommand");
const RevisarSolicitudCommand = require("../../src/solicitudes/comandos/RevisarSolicitudCommand");
const PanelBibliotecario = require("../../src/solicitudes/comandos/PanelBibliotecario");
const flujo = require("./flujoSolicitudes");

module.exports = function crearEscenarioCommand() {
  const panel = new PanelBibliotecario();

  const fabricar = (tipo, id, parametro) => {
    const servicio = flujo.obtener();
    if (tipo === "aprobar") return new AprobarSolicitudCommand(servicio, id);
    if (tipo === "rechazar") return new RechazarSolicitudCommand(servicio, id, parametro);
    if (tipo === "revisar") return new RevisarSolicitudCommand(servicio, id, parametro || "Sin observación");
    throw new Error(`Comando desconocido: ${tipo}`);
  };

  return {
    acciones: {
      ejecutar({ tipo, id, parametro }) {
        const comando = fabricar(tipo, id, parametro);
        panel.ejecutar(comando);
        return comando.getDescripcion();
      },
      deshacer() {
        panel.deshacerUltimo();
        return true;
      },
      vaciarSolicitudes() {
        flujo.reiniciar();
        console.log("[Panel] Se vaciaron las solicitudes pendientes.");
        return true;
      },
    },
    estado() {
      return {
        solicitudes: flujo.obtener().listar(),
        auditoria: panel.verAuditoria().slice(-8).reverse(),
        puedeDeshacer: panel.puedeDeshacer(),
      };
    },
  };
};
