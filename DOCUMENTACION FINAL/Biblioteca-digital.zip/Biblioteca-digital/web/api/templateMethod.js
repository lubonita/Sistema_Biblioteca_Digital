"use strict";

// Adaptador web del patrón Template Method (src/importacion). Ejecuta los
// importadores reales: el panel elige el importador y el archivo, y el método
// plantilla importar() decide el orden de los pasos.

const Categoria = require("../../src/catalogo/Categoria");
const ImportadorEPUB = require("../../src/importacion/ImportadorEPUB");
const ImportadorPDF = require("../../src/importacion/ImportadorPDF");
const ImportadorMOBI = require("../../src/importacion/ImportadorMOBI");

// Archivos simulados (cada formato guarda sus metadatos de forma distinta)
const ARCHIVOS = {
  "rayuela.epub": '<dc:title>Rayuela</dc:title><dc:creator>Julio Cortázar</dc:creator><meta name="calificacion" content="4.5"/>',
  "dune.pdf": "%PDF-1.7 /Title (Dune) /Author (Frank Herbert) /Rating (4.7) /Pages (8)",
  "fundacion.mobi": "EXTH|100=Isaac Asimov|503=Fundación|rating=4.6",
  "ficciones.pdf": "%PDF-1.7 /Title (Ficciones) /Author (Jorge Luis Borges) /Rating (4.4) /Pages (4)",
  "anonimo.epub": "<dc:title>Libro sin autor</dc:title>",
};
const IMPORTADORES = { ImportadorEPUB, ImportadorPDF, ImportadorMOBI };

module.exports = function crearEscenarioTemplateMethod() {
  const destino = new Categoria("Nuevos ingresos");
  const libros = [];
  let ultimo = null;

  return {
    acciones: {
      importar({ importador, archivo }) {
        const Clase = IMPORTADORES[importador];
        if (!Clase) throw new Error(`Importador desconocido: ${importador}`);
        if (!ARCHIVOS[archivo]) throw new Error(`Archivo desconocido: ${archivo}`);
        const instancia = new Clase(destino);
        try {
          const r = instancia.importar({ nombre: archivo, contenido: ARCHIVOS[archivo] });
          libros.push(r.libro);
          ultimo = { importador, archivo, ok: true, pasos: r.pasos, metadatos: r.metadatos };
          return r;
        } catch (error) {
          ultimo = { importador, archivo, ok: false, pasos: [...instancia.pasos], error: error.message };
          throw error;
        }
      },
    },
    estado() {
      return {
        importadores: Object.keys(IMPORTADORES),
        archivos: Object.keys(ARCHIVOS),
        categoria: destino.nombre,
        libros,
        ultimo,
      };
    },
  };
};
