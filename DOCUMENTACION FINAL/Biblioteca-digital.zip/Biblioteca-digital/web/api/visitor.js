"use strict";

// Adaptador web del patrón Visitor (src/analisis). Aplica los visitantes reales
// sobre el árbol del catálogo (Composite) sin modificar sus clases.

const LibroCatalogado = require("../../src/catalogo/LibroCatalogado");
const Categoria = require("../../src/catalogo/Categoria");
const GeneradorReportesCatalogo = require("../../src/analisis/GeneradorReportesCatalogo");
const ExportadorCSV = require("../../src/analisis/ExportadorCSV");
const ExportadorJSON = require("../../src/analisis/ExportadorJSON");
const CalculadoraEstadisticas = require("../../src/analisis/CalculadoraEstadisticas");
const DetectorBajaCalificacion = require("../../src/analisis/DetectorBajaCalificacion");

module.exports = function crearEscenarioVisitor() {
  const novela = new Categoria("Novela");
  novela.agregar(new LibroCatalogado("Cien años de soledad", 4.8));
  novela.agregar(new LibroCatalogado("Rayuela", 4.5));
  const cf = new Categoria("Ciencia Ficción");
  cf.agregar(new LibroCatalogado("Dune", 4.7));
  cf.agregar(new LibroCatalogado("Fundación", 4.6));
  const literatura = new Categoria("Literatura");
  literatura.agregar(novela);
  literatura.agregar(cf);
  literatura.agregar(new LibroCatalogado("Veinte poemas de amor", 4.3));
  const categorias = { Literatura: literatura, Novela: novela, "Ciencia Ficción": cf };

  let ultimo = null;
  const VISITANTES = {
    csv: () => new ExportadorCSV(),
    json: () => new ExportadorJSON(),
    estadisticas: () => new CalculadoraEstadisticas(),
    baja: (umbral) => new DetectorBajaCalificacion(Number(umbral)),
  };

  return {
    acciones: {
      aplicar({ visitante, umbral = 4.6 }) {
        if (!VISITANTES[visitante]) throw new Error(`Visitante desconocido: ${visitante}`);
        const v = VISITANTES[visitante](umbral);
        const resultado = new GeneradorReportesCatalogo(literatura).aplicar(v);
        ultimo = { visitante: v.constructor.name, resultado };
        return ultimo;
      },
      agregarLibro({ categoria, titulo, calificacion }) {
        const destino = categorias[categoria];
        const nota = Number(calificacion);
        if (!destino) throw new Error("Categoría desconocida.");
        if (!titulo || !titulo.trim()) throw new Error("El libro necesita un título.");
        if (Number.isNaN(nota) || nota < 0 || nota > 5) throw new Error("La calificación debe estar entre 0 y 5.");
        destino.agregar(new LibroCatalogado(titulo.trim(), nota));
        console.log(`[Composite] "${titulo.trim()}" agregado a ${categoria}. Los visitantes lo incluirán sin cambios.`);
        return true;
      },
    },
    estado() {
      return { ultimo, categorias: Object.keys(categorias), totalLibros: literatura.getTotalLibros() };
    },
  };
};
