"use strict";

// Adaptador web del patrón Chain of Responsibility (src/solicitudes/validacion).
// Arma la solicitud con los datos del formulario y la pasa por la cadena real.
// Si queda aprobada, se registra como pendiente en el ServicioSolicitudes
// compartido, para que la pestaña Command la pueda gestionar.

const SolicitudPrestamo = require("../../src/solicitudes/validacion/SolicitudPrestamo");
const GestorSolicitudesPrestamo = require("../../src/solicitudes/validacion/GestorSolicitudesPrestamo");
const ValidadorSesionActiva = require("../../src/solicitudes/validacion/ValidadorSesionActiva");
const ValidadorSuscripcion = require("../../src/solicitudes/validacion/ValidadorSuscripcion");
const ValidadorMultas = require("../../src/solicitudes/validacion/ValidadorMultas");
const ValidadorLimitePrestamos = require("../../src/solicitudes/validacion/ValidadorLimitePrestamos");
const ValidadorFormatoDispositivo = require("../../src/solicitudes/validacion/ValidadorFormatoDispositivo");
const ValidadorLicenciasDisponibles = require("../../src/solicitudes/validacion/ValidadorLicenciasDisponibles");
const SesionManager = require("../../src/auth/SesionManager");
const flujo = require("./flujoSolicitudes");

const ESTANDAR = ["ValidadorSesionActiva", "ValidadorSuscripcion", "ValidadorMultas", "ValidadorLimitePrestamos", "ValidadorFormatoDispositivo"];
const EXTENDIDA = [...ESTANDAR, "ValidadorLicenciasDisponibles"];

module.exports = function crearEscenarioChain() {
  const gestorEstandar = new GestorSolicitudesPrestamo(); // usa crearCadenaEstandar()

  // Cadena extendida: los mismos validadores + un eslabón nuevo al final
  const primero = new ValidadorSesionActiva();
  primero
    .setSiguiente(new ValidadorSuscripcion())
    .setSiguiente(new ValidadorMultas())
    .setSiguiente(new ValidadorLimitePrestamos())
    .setSiguiente(new ValidadorFormatoDispositivo())
    .setSiguiente(new ValidadorLicenciasDisponibles());
  const gestorExtendido = new GestorSolicitudesPrestamo(primero);

  const historial = [];

  return {
    acciones: {
      procesar({ cuenta, plan, suscripcionVence, multasPendientes, prestamosActivos, dispositivo, titulo, formato, licenciasDisponibles, cadena }) {
        const registrado = SesionManager.getInstance().usuariosRegistrados.find((u) => u.usuario === cuenta);
        if (!registrado) throw new Error(`La cuenta "${cuenta}" no existe.`);
        const solicitud = new SolicitudPrestamo({
          usuario: {
            cuenta, nombre: registrado.nombre, plan: plan || null, suscripcionVence: suscripcionVence || null,
            multasPendientes: Number(multasPendientes) || 0, prestamosActivos: Number(prestamosActivos) || 0, dispositivo,
          },
          libro: { titulo: (titulo || "").trim() || "Libro sin título", formato, licenciasDisponibles: Number(licenciasDisponibles) },
        });
        const extendida = cadena === "extendida";
        const resultado = (extendida ? gestorExtendido : gestorEstandar).procesar(solicitud);
        if (resultado.aprobada) flujo.obtener().registrarPendiente(solicitud, resultado); // unión con Command
        const item = { id: solicitud.id, resumen: solicitud.getResumen(), cadena: extendida ? EXTENDIDA : ESTANDAR, ...resultado };
        historial.unshift(item);
        return item;
      },
    },
    estado() {
      const u = SesionManager.getInstance().getUsuarioActual();
      return {
        ultimo: historial[0] || null,
        historial: historial.slice(0, 6).map((h) => ({ id: h.id, resumen: h.resumen, aprobada: h.aprobada, validador: h.validador, motivo: h.motivo })),
        cuentas: SesionManager.getInstance().usuariosRegistrados.map((x) => ({ cuenta: x.usuario, nombre: x.nombre })),
        cuentaSesion: u ? u.usuario : null,
        estandar: ESTANDAR,
      };
    },
  };
};
