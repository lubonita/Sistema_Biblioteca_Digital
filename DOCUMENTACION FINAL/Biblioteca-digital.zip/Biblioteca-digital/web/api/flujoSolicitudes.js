"use strict";

// Estado compartido entre las pestañas Chain y Command del panel:
// el MISMO ServicioSolicitudes (receptor real de src/) recibe las solicitudes
// que pasan la cadena y es el que modifican los comandos.

const ServicioSolicitudes = require("../../src/solicitudes/comandos/ServicioSolicitudes");

let servicio = new ServicioSolicitudes();

module.exports = {
  obtener: () => servicio,
  reiniciar: () => (servicio = new ServicioSolicitudes()),
};
