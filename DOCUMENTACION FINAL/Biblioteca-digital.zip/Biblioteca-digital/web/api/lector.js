"use strict";

// API del Portal del lector (front real en web/lector/).
// El back hace lo que le corresponde: valida la solicitud con la cadena real
// (Chain of Responsibility, cadena extendida con licencias), la deja pendiente
// en el ServicioSolicitudes compartido (el mismo que gestiona Command en el
// panel) y verifica la licencia antes de entregar el libro al visor.

const SolicitudPrestamo = require("../../src/solicitudes/validacion/SolicitudPrestamo");
const GestorSolicitudesPrestamo = require("../../src/solicitudes/validacion/GestorSolicitudesPrestamo");
const ValidadorSesionActiva = require("../../src/solicitudes/validacion/ValidadorSesionActiva");
const ValidadorSuscripcion = require("../../src/solicitudes/validacion/ValidadorSuscripcion");
const ValidadorMultas = require("../../src/solicitudes/validacion/ValidadorMultas");
const ValidadorLimitePrestamos = require("../../src/solicitudes/validacion/ValidadorLimitePrestamos");
const ValidadorFormatoDispositivo = require("../../src/solicitudes/validacion/ValidadorFormatoDispositivo");
const ValidadorLicenciasDisponibles = require("../../src/solicitudes/validacion/ValidadorLicenciasDisponibles");
const flujo = require("./flujoSolicitudes");

// Datos simulados (no hay base de datos)
const CATALOGO = [
  { id: "rayuela", titulo: "Rayuela", autor: "Julio Cortázar", formato: "EPUB", paginas: 6, licencias: 3 },
  { id: "dune", titulo: "Dune", autor: "Frank Herbert", formato: "PDF", paginas: 8, licencias: 2 },
  { id: "fundacion", titulo: "Fundación", autor: "Isaac Asimov", formato: "MOBI", paginas: 5, licencias: 1 },
  { id: "ficciones", titulo: "Ficciones", autor: "Jorge Luis Borges", formato: "PDF", paginas: 4, licencias: 2 },
  { id: "cien", titulo: "Cien años de soledad", autor: "Gabriel García Márquez", formato: "EPUB", paginas: 10, licencias: 0 },
];
const PERFILES = {
  lector1: { nombre: "Usuario Lector", plan: "premium", suscripcionVence: "2026-12-31", multasPendientes: 0, prestamosActivos: 1 },
  lzafra: { nombre: "Luz Estela Zafra", plan: "premium", suscripcionVence: "2026-12-31", multasPendientes: 0, prestamosActivos: 0 },
  vmillan: { nombre: "Valentina Millán", plan: "basico", suscripcionVence: "2026-12-31", multasPendientes: 1, prestamosActivos: 0 },
};

module.exports = function crearPortalLector() {
  const primero = new ValidadorSesionActiva();
  primero
    .setSiguiente(new ValidadorSuscripcion())
    .setSiguiente(new ValidadorMultas())
    .setSiguiente(new ValidadorLimitePrestamos())
    .setSiguiente(new ValidadorFormatoDispositivo())
    .setSiguiente(new ValidadorLicenciasDisponibles());
  const gestor = new GestorSolicitudesPrestamo(primero);
  const libroPorTitulo = (titulo) => CATALOGO.find((l) => l.titulo === titulo);

  const perfil = (cuenta) => {
    const p = PERFILES[cuenta];
    if (!p) throw new Error(`La cuenta "${cuenta}" no existe.`);
    return p;
  };

  return {
    acciones: {
      solicitar({ cuenta, libroId, dispositivo = "Tablet" }) {
        const p = perfil(cuenta);
        const libro = CATALOGO.find((l) => l.id === libroId);
        if (!libro) throw new Error("Libro desconocido.");
        const solicitud = new SolicitudPrestamo({
          usuario: { cuenta, ...p, dispositivo },
          libro: { titulo: libro.titulo, formato: libro.formato, licenciasDisponibles: libro.licencias },
        });
        const r = gestor.procesar(solicitud);
        if (r.aprobada) flujo.obtener().registrarPendiente(solicitud, r);
        return { id: solicitud.id, aprobada: r.aprobada, motivo: r.motivo, validador: r.validador };
      },

      misSolicitudes({ cuenta }) {
        const p = perfil(cuenta);
        return flujo.obtener().listar().filter((s) => s.usuario === p.nombre);
      },

      // Solo entrega el libro si el préstamo está APROBADO (lo decidió Command)
      abrirLibro({ cuenta, id }) {
        const p = perfil(cuenta);
        const s = flujo.obtener().listar().find((x) => x.id === id && x.usuario === p.nombre);
        if (!s) throw new Error(`No tienes una solicitud ${id}.`);
        if (s.estado !== "APROBADA") {
          throw new Error(`El préstamo ${id} está ${s.estado}: aún no tienes licencia para leer "${s.libro}".`);
        }
        const libro = libroPorTitulo(s.libro);
        console.log(`[Lector] Licencia verificada: ${p.nombre} abre "${s.libro}".`);
        return { id, titulo: s.libro, autor: libro.autor, formato: libro.formato, paginas: libro.paginas };
      },
    },
    estado() {
      return {
        catalogo: CATALOGO,
        cuentas: Object.entries(PERFILES).map(([cuenta, p]) => ({ cuenta, nombre: p.nombre, plan: p.plan })),
      };
    },
  };
};
