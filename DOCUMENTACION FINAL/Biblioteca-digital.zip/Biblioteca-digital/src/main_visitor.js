"use strict";

const LibroCatalogado = require("./catalogo/LibroCatalogado");
const Categoria = require("./catalogo/Categoria");
const VisitanteCatalogo = require("./analisis/VisitanteCatalogo");
const ElementoVisitable = require("./analisis/ElementoVisitable");
const ExportadorCSV = require("./analisis/ExportadorCSV");
const ExportadorJSON = require("./analisis/ExportadorJSON");
const CalculadoraEstadisticas = require("./analisis/CalculadoraEstadisticas");
const DetectorBajaCalificacion = require("./analisis/DetectorBajaCalificacion");
const GeneradorReportesCatalogo = require("./analisis/GeneradorReportesCatalogo");

// Catálogo de ejemplo armado con el Composite existente (sin modificarlo)
const novela = new Categoria("Novela");
novela.agregar(new LibroCatalogado("Cien años de soledad", 4.8));
novela.agregar(new LibroCatalogado("Rayuela", 4.5));
const cienciaFiccion = new Categoria("Ciencia Ficción");
cienciaFiccion.agregar(new LibroCatalogado("Dune", 4.7));
cienciaFiccion.agregar(new LibroCatalogado("Fundación", 4.6));
const literatura = new Categoria("Literatura");
literatura.agregar(novela);
literatura.agregar(cienciaFiccion);
literatura.agregar(new LibroCatalogado("Veinte poemas de amor", 4.3));

const generador = new GeneradorReportesCatalogo(literatura);

console.log("========================================");
console.log(" PRUEBA 1: Reporte CSV del catálogo");
console.log("========================================");
console.log(generador.aplicar(new ExportadorCSV()));

console.log("\n========================================");
console.log(" PRUEBA 2: Exportación a JSON (misma estructura, otra operación)");
console.log("========================================");
console.log(generador.aplicar(new ExportadorJSON()));

console.log("\n========================================");
console.log(" PRUEBA 3: Estadísticas del catálogo en un solo recorrido");
console.log("========================================");
const estadisticas = generador.aplicar(new CalculadoraEstadisticas());
console.log(estadisticas);
console.log("Comparación: el Composite promedia categorías, el visitante promedia libros ->",
  literatura.getCalificacionPromedio().toFixed(2), "vs", estadisticas.promedioPorLibro);

console.log("\n========================================");
console.log(" PRUEBA 4: Dos reportes distintos sobre la MISMA colección");
console.log("========================================");
const csv = generador.aplicar(new ExportadorCSV());
const stats = generador.aplicar(new CalculadoraEstadisticas());
console.log(`CSV: ${csv.split("\n").length - 1} filas de libros | Estadísticas: ${stats.totalLibros} libros, promedio ${stats.promedioPorLibro}`);

console.log("\n========================================");
console.log(" PRUEBA 5: Operación nueva sin modificar los elementos (DetectorBajaCalificacion)");
console.log("========================================");
console.log(generador.aplicar(new DetectorBajaCalificacion(4.6)));

console.log("\n========================================");
console.log(" PRUEBA 6: Las clases del Composite no se modificaron");
console.log("========================================");
const libroOriginal = new LibroCatalogado("Ficciones", 4.9);
console.log("¿LibroCatalogado tiene aceptar()?", typeof libroOriginal.aceptar === "function");
console.log("¿Su versión visitable sí lo tiene?", typeof ElementoVisitable.desde(libroOriginal).aceptar === "function");

console.log("\n========================================");
console.log(" PRUEBA 7: Escalabilidad - estadísticas sobre 100.000 libros");
console.log("========================================");
const grande = new Categoria("Catálogo general");
for (let c = 0; c < 100; c++) {
  const categoria = new Categoria(`Categoría ${c + 1}`);
  for (let l = 0; l < 1000; l++) {
    categoria.agregar(new LibroCatalogado(`Libro ${c + 1}-${l + 1}`, 3 + ((c + l) % 21) / 10));
  }
  grande.agregar(categoria);
}
const inicio = Date.now();
const statsGrande = new GeneradorReportesCatalogo(grande).aplicar(new CalculadoraEstadisticas());
console.log(`Libros: ${statsGrande.totalLibros} | Categorías: ${statsGrande.totalCategorias} | Promedio: ${statsGrande.promedioPorLibro}`);
console.log("Distribución:", statsGrande.distribucion);
console.log(`Tiempo (convertir + recorrer): ${Date.now() - inicio} ms`);

console.log("\n========================================");
console.log(" PRUEBA 8: Casos de error");
console.log("========================================");
try {
  new VisitanteCatalogo();
} catch (error) {
  console.log("Error capturado (clase base):", error.message);
}
try {
  generador.aplicar({ visitarLibro() {} });
} catch (error) {
  console.log("Error capturado (no es un visitante):", error.message);
}
try {
  new GeneradorReportesCatalogo("Literatura");
} catch (error) {
  console.log("Error capturado (raíz inválida):", error.message);
}
try {
  ElementoVisitable.desde({ titulo: "Objeto suelto" });
} catch (error) {
  console.log("Error capturado (elemento desconocido):", error.message);
}
try {
  new DetectorBajaCalificacion(8);
} catch (error) {
  console.log("Error capturado (umbral inválido):", error.message);
}
class VisitanteIncompleto extends VisitanteCatalogo {
  visitarCategoria() {}
}
try {
  generador.aplicar(new VisitanteIncompleto());
} catch (error) {
  console.log("Error capturado (visitante incompleto):", error.message);
}
