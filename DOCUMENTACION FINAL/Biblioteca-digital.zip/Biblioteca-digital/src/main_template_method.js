"use strict";
// Pruebas del patrón Template Method (BACK): importación de libros al catálogo.
// Ejecutar desde la raíz del proyecto:  node src/main_template_method.js

const SesionManager = require("./auth/SesionManager");
const Categoria = require("./catalogo/Categoria");
const ImportadorLibro = require("./importacion/ImportadorLibro");
const ImportadorEPUB = require("./importacion/ImportadorEPUB");
const ImportadorPDF = require("./importacion/ImportadorPDF");
const ImportadorMOBI = require("./importacion/ImportadorMOBI");

// Archivos simulados: cada formato guarda sus metadatos de forma distinta
const rayuelaEPUB = {
  nombre: "rayuela.epub",
  contenido: '<dc:title>Rayuela</dc:title><dc:creator>Julio Cortázar</dc:creator><meta name="calificacion" content="4.5"/>',
};
const dunePDF = {
  nombre: "dune.pdf",
  contenido: "%PDF-1.7 /Title (Dune) /Author (Frank Herbert) /Rating (4.7) /Pages (8)",
};
const fundacionMOBI = {
  nombre: "fundacion.mobi",
  contenido: "EXTH|100=Isaac Asimov|503=Fundación|rating=4.6",
};

const sesion = SesionManager.getInstance();
const nuevos = new Categoria("Nuevos ingresos");
const probar = (texto, accion) => {
  try {
    accion();
  } catch (error) {
    console.log(`Error capturado (${texto}):`, error.message);
  }
};

console.log("========================================");
console.log(" PRUEBA 1: Importar un EPUB (la plantilla fija el orden)");
console.log("========================================");
sesion.login("lzafra", "abcd");
const r1 = new ImportadorEPUB(nuevos).importar(rayuelaEPUB);
console.log("Pasos ejecutados:", r1.pasos);

console.log("\n========================================");
console.log(" PRUEBA 2: Importar un PDF (usa el hook despuesDeImportar)");
console.log("========================================");
const r2 = new ImportadorPDF(nuevos).importar(dunePDF);
console.log("Metadatos:", r2.metadatos);

console.log("\n========================================");
console.log(" PRUEBA 3: Importar un MOBI (otra forma de leer metadatos)");
console.log("========================================");
const r3 = new ImportadorMOBI(nuevos).importar(fundacionMOBI);
console.log("Metadatos:", r3.metadatos);

console.log("\n========================================");
console.log(" PRUEBA 4: Mismo esqueleto para los tres formatos");
console.log("========================================");
const mismoOrden = JSON.stringify(r1.pasos) === JSON.stringify(r2.pasos) && JSON.stringify(r2.pasos) === JSON.stringify(r3.pasos);
console.log("¿Los tres siguieron los mismos pasos en el mismo orden?", mismoOrden);
nuevos.mostrar();
console.log("Total de libros en la categoría:", nuevos.getTotalLibros());

console.log("\n========================================");
console.log(" PRUEBA 5: Archivo con formato equivocado");
console.log("========================================");
probar("PDF en el importador EPUB", () => new ImportadorEPUB(nuevos).importar(dunePDF));
console.log("Libros en la categoría (no cambió):", nuevos.getTotalLibros());

console.log("\n========================================");
console.log(" PRUEBA 6: Un lector no puede importar");
console.log("========================================");
sesion.login("lector1", "lector1");
probar("lector importando", () => new ImportadorMOBI(nuevos).importar(fundacionMOBI));
sesion.login("lzafra", "abcd");

console.log("\n========================================");
console.log(" PRUEBA 7: Metadatos incompletos");
console.log("========================================");
const sinAutor = { nombre: "anonimo.epub", contenido: "<dc:title>Libro sin autor</dc:title>" };
probar("EPUB sin autor", () => new ImportadorEPUB(nuevos).importar(sinAutor));
console.log("Libros en la categoría (no cambió):", nuevos.getTotalLibros());

console.log("\n========================================");
console.log(" PRUEBA 8: La plantilla está protegida");
console.log("========================================");
probar("instanciar la clase abstracta", () => new ImportadorLibro(nuevos));
class ImportadorTramposo extends ImportadorEPUB {
  importar() {
    return "me salto los pasos";
  }
}
probar("sobrescribir importar()", () => new ImportadorTramposo(nuevos));
