"use strict";

// Rol en el patrón Template Method: CONCRETE CLASS
// Define los pasos variables para MOBI: los metadatos vienen en la cabecera
// EXTH con códigos numéricos (100 = autor, 503 = título). Sobrescribe el HOOK
// para avisar que el archivo es nativo de Kindle.

const ImportadorLibro = require("./ImportadorLibro");
const CatalogoServiceMOBI = require("../libros/CatalogoServiceMOBI");

class ImportadorMOBI extends ImportadorLibro {
  getExtension() {
    return ".mobi";
  }

  extraerMetadatos(contenido) {
    const campos = {};
    contenido.split("|").forEach((parte) => {
      const [clave, ...valor] = parte.split("=");
      if (valor.length) campos[clave.trim()] = valor.join("=").trim();
    });
    const metadatos = {
      titulo: campos["503"] || "",
      autor: campos["100"] || "",
      calificacion: Number(campos.rating) || 0,
    };
    console.log("  [Paso 4] Metadatos MOBI leídos de la cabecera EXTH (503 = título, 100 = autor).");
    return metadatos;
  }

  getServicioCatalogo() {
    return new CatalogoServiceMOBI();
  }

  // HOOK sobrescrito
  despuesDeImportar(libro, metadatos) {
    console.log("  [Hook] Archivo MOBI: compatible de forma nativa con Kindle.");
  }
}

module.exports = ImportadorMOBI;
