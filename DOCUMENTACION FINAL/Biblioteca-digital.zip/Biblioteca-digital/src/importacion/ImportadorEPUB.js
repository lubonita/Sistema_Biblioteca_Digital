"use strict";

const ImportadorLibro = require("./ImportadorLibro");
const CatalogoServiceEPUB = require("../libros/CatalogoServiceEPUB");

class ImportadorEPUB extends ImportadorLibro {
  getExtension() {
    return ".epub";
  }

  extraerMetadatos(contenido) {
    const etiqueta = (nombre) => {
      const m = contenido.match(new RegExp(`<dc:${nombre}>([^<]*)</dc:${nombre}>`));
      return m ? m[1].trim() : "";
    };
    const calificacion = contenido.match(/<meta name="calificacion" content="([\d.]+)"\s*\/>/);
    const metadatos = {
      titulo: etiqueta("title"),
      autor: etiqueta("creator"),
      calificacion: calificacion ? Number(calificacion[1]) : 0,
    };
    console.log("  [Paso 4] Metadatos EPUB leídos de las etiquetas <dc:title> y <dc:creator>.");
    return metadatos;
  }

  getServicioCatalogo() {
    return new CatalogoServiceEPUB();
  }
}

module.exports = ImportadorEPUB;
