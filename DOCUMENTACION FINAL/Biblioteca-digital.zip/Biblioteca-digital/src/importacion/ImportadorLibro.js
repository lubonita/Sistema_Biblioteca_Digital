"use strict";
const SesionManager = require("../auth/SesionManager");
const Categoria = require("../catalogo/Categoria");
const LibroCatalogado = require("../catalogo/LibroCatalogado");

const ROLES_PERMITIDOS = ["administrador", "bibliotecario"];

class ImportadorLibro {
  constructor(categoriaDestino) {
    if (new.target === ImportadorLibro) {
      throw new Error("ImportadorLibro es una clase base y no puede instanciarse directamente.");
    }
    // JavaScript no tiene "final": se impide que una subclase cambie la plantilla
    if (Object.getPrototypeOf(this).importar !== ImportadorLibro.prototype.importar) {
      throw new Error(`${new.target.name} no puede sobrescribir importar(): es el método plantilla.`);
    }
    if (!(categoriaDestino instanceof Categoria)) {
      throw new Error("El importador necesita una Categoria del catálogo como destino.");
    }
    this.categoriaDestino = categoriaDestino;
    this.pasos = []; // registro del orden en que se ejecutaron los pasos
  }

  // ===================== MÉTODO PLANTILLA (no se sobrescribe) =====================
  importar(archivo) {
    this.pasos = [];
    const formato = this.constructor.name;
    console.log(`[${formato}] Importando "${archivo && archivo.nombre}"...`);

    this.#paso("1. verificarPermiso", () => this.verificarPermiso());
    const contenido = this.#paso("2. leerArchivo", () => this.leerArchivo(archivo));
    this.#paso("3. validarFormato", () => this.validarFormato(archivo));
    const metadatos = this.#paso("4. extraerMetadatos", () => this.extraerMetadatos(contenido));
    this.#paso("5. validarMetadatos", () => this.validarMetadatos(metadatos));
    const libro = this.#paso("6. registrarEnCatalogo", () => this.registrarEnCatalogo(metadatos));
    this.#paso("7. despuesDeImportar (hook)", () => this.despuesDeImportar(libro, metadatos));

    console.log(`[${formato}] Importación completa: ${libro.getInfo()} en "${this.categoriaDestino.nombre}".`);
    return { libro: libro.getInfo(), metadatos, pasos: [...this.pasos] };
  }

  // Ejecuta un paso, lo registra y, si falla, detiene la importación indicando dónde
  #paso(nombre, accion) {
    this.pasos.push(nombre);
    try {
      return accion();
    } catch (error) {
      throw new Error(`Importación detenida en el paso ${nombre}: ${error.message}`);
    }
  }

  // ===================== PASOS COMUNES (iguales para todos los formatos) =====================
  verificarPermiso() {
    const usuario = SesionManager.getInstance().getUsuarioActual();
    if (!usuario) throw new Error("debe iniciar sesión para importar libros.");
    if (!ROLES_PERMITIDOS.includes(usuario.rol)) {
      throw new Error(`el rol "${usuario.rol}" no puede importar libros al catálogo.`);
    }
    console.log(`  [Paso 1] Permiso verificado: ${usuario.nombre} (${usuario.rol}).`);
  }

  leerArchivo(archivo) {
    if (!archivo || !archivo.nombre || !archivo.contenido) {
      throw new Error("el archivo está vacío o no tiene nombre.");
    }
    console.log(`  [Paso 2] Archivo leído: ${archivo.nombre} (${archivo.contenido.length} caracteres).`);
    return archivo.contenido;
  }

  validarFormato(archivo) {
    const extension = this.getExtension();
    if (!archivo.nombre.toLowerCase().endsWith(extension)) {
      throw new Error(`"${archivo.nombre}" no es un archivo ${extension}.`);
    }
    console.log(`  [Paso 3] Formato válido: ${extension}.`);
  }

  validarMetadatos(metadatos) {
    if (!metadatos.titulo) throw new Error("el archivo no trae el título del libro.");
    if (!metadatos.autor) throw new Error("el archivo no trae el autor del libro.");
    if (!(metadatos.calificacion >= 0 && metadatos.calificacion <= 5)) {
      throw new Error("la calificación debe estar entre 0 y 5.");
    }
    console.log(`  [Paso 5] Metadatos completos: "${metadatos.titulo}" de ${metadatos.autor}.`);
  }

  // Usa el Factory Method existente (CatalogoService) y el Composite existente (Categoria)
  registrarEnCatalogo(metadatos) {
    const libro = this.getServicioCatalogo().crearLibro(metadatos.titulo, metadatos.autor);
    this.categoriaDestino.agregar(new LibroCatalogado(metadatos.titulo, metadatos.calificacion));
    console.log(`  [Paso 6] Registrado en el catálogo: ${libro.getInfo()}.`);
    return libro;
  }

  // ===================== HOOK (opcional) =====================
  despuesDeImportar(libro, metadatos) {
    // Por defecto no hace nada; una subclase puede sobrescribirlo.
  }

  // ===================== PASOS ABSTRACTOS (los define cada subclase) =====================
  getExtension() {
    throw new Error("getExtension() debe ser implementado por la subclase.");
  }

  extraerMetadatos(contenido) {
    throw new Error("extraerMetadatos() debe ser implementado por la subclase.");
  }

  getServicioCatalogo() {
    throw new Error("getServicioCatalogo() debe ser implementado por la subclase.");
  }
}

module.exports = ImportadorLibro;
