"use strict";

const ImportadorLibro = require("./ImportadorLibro");
const CatalogoServicePDF = require("../libros/CatalogoServicePDF");

class ImportadorPDF extends ImportadorLibro {
  getExtension() {
    return ".pdf";
  }

  extraerMetadatos(contenido) {
    const campo = (nombre) => {
      const m = contenido.match(new RegExp(`/${nombre}\\s*\\(([^)]*)\\)`));
      return m ? m[1].trim() : "";
    };
    const metadatos = {
      titulo: campo("Title"),
      autor: campo("Author"),
      calificacion: Number(campo("Rating")) || 0,
      paginas: Number(campo("Pages")) || 0,
    };
    console.log("  [Paso 4] Metadatos PDF leídos del diccionario /Title, /Author y /Pages.");
    return metadatos;
  }

  getServicioCatalogo() {
    return new CatalogoServicePDF();
  }

  // HOOK sobrescrito: paso extra opcional solo para PDF
  despuesDeImportar(libro, metadatos) {
    console.log(`  [Hook] PDF de ${metadatos.paginas} páginas: se usa diseño fijo en el visor.`);
  }
}

module.exports = ImportadorPDF;
