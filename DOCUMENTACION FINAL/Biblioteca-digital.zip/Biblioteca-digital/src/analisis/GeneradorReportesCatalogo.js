"use strict";



const Categoria = require("../catalogo/Categoria");
const ElementoVisitable = require("./ElementoVisitable");
const VisitanteCatalogo = require("./VisitanteCatalogo");

class GeneradorReportesCatalogo {
  #raiz;

  constructor(categoriaRaiz) {
    if (!(categoriaRaiz instanceof Categoria)) {
      throw new Error("El generador necesita la Categoria raíz del catálogo.");
    }
    this.#raiz = ElementoVisitable.desde(categoriaRaiz);
  }

  aplicar(visitante) {
    if (!(visitante instanceof VisitanteCatalogo)) {
      throw new Error("Solo se pueden aplicar visitantes que hereden de VisitanteCatalogo.");
    }
    this.#raiz.aceptar(visitante);
    console.log(`[Reportes] ${visitante.constructor.name} aplicado sobre "${this.#raiz.nombre}".`);
    return visitante.getResultado();
  }
}

module.exports = GeneradorReportesCatalogo;
