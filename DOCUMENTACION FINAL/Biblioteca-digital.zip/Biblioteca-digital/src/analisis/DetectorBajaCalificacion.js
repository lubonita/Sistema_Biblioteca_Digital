"use strict";

const VisitanteCatalogo = require("./VisitanteCatalogo");

class DetectorBajaCalificacion extends VisitanteCatalogo {
  #umbral;
  #ruta = [];
  #encontrados = [];

  constructor(umbral = 4.5) {
    super();
    if (typeof umbral !== "number" || umbral < 0 || umbral > 5) {
      throw new Error("El umbral debe ser un número entre 0 y 5.");
    }
    this.#umbral = umbral;
  }

  visitarCategoria(categoria) {
    this.#ruta.push(categoria.nombre);
  }

  salirCategoria() {
    this.#ruta.pop();
  }

  visitarLibro(libro) {
    if (libro.calificacion < this.#umbral) {
      this.#encontrados.push({ titulo: libro.titulo, calificacion: libro.calificacion, categoria: this.#ruta.join(" > ") });
    }
  }

  getResultado() {
    return { umbral: this.#umbral, libros: [...this.#encontrados] };
  }
}

module.exports = DetectorBajaCalificacion;
