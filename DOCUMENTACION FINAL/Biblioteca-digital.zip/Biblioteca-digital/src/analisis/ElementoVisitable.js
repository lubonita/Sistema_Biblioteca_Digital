"use strict";

let clases = null;

class ElementoVisitable {
  constructor() {
    if (new.target === ElementoVisitable) {
      throw new Error("ElementoVisitable es una clase base y no puede instanciarse directamente.");
    }
  }

  aceptar(visitante) {
    throw new Error("aceptar() debe ser implementado por la subclase.");
  }

  // Convierte un elemento del Composite en su equivalente visitable.
  static desde(elemento) {
    // Se cargan la primera vez que se usan (evita dependencias circulares entre archivos)
    clases ??= {
      Categoria: require("../catalogo/Categoria"),
      LibroCatalogado: require("../catalogo/LibroCatalogado"),
      NodoCategoriaVisitable: require("./NodoCategoriaVisitable"),
      NodoLibroVisitable: require("./NodoLibroVisitable"),
    };
    const { Categoria, LibroCatalogado, NodoCategoriaVisitable, NodoLibroVisitable } = clases;
    if (elemento instanceof Categoria) return new NodoCategoriaVisitable(elemento);
    if (elemento instanceof LibroCatalogado) return new NodoLibroVisitable(elemento);
    throw new Error("Solo se pueden visitar elementos del catálogo (Categoria o LibroCatalogado).");
  }
}

module.exports = ElementoVisitable;
