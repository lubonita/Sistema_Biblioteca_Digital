"use strict";

const VisitanteCatalogo = require("./VisitanteCatalogo");

class ExportadorJSON extends VisitanteCatalogo {
  #pila = [];
  #raiz = null;

  visitarCategoria(categoria) {
    const nodo = { categoria: categoria.nombre, libros: [], subcategorias: [] };
    if (this.#pila.length) this.#pila[this.#pila.length - 1].subcategorias.push(nodo);
    else this.#raiz = nodo;
    this.#pila.push(nodo);
  }

  salirCategoria() {
    this.#pila.pop();
  }

  visitarLibro(libro) {
    this.#pila[this.#pila.length - 1].libros.push({ titulo: libro.titulo, calificacion: libro.calificacion });
  }

  getResultado() {
    return JSON.stringify(this.#raiz, null, 2);
  }
}

module.exports = ExportadorJSON;
