"use strict";

const ElementoVisitable = require("./ElementoVisitable");

class NodoLibroVisitable extends ElementoVisitable {
  #libro;

  constructor(libro) {
    super();
    this.#libro = libro;
  }

  get titulo() {
    return this.#libro.titulo;
  }

  get calificacion() {
    return this.#libro.calificacion;
  }

  aceptar(visitante) {
    visitante.visitarLibro(this);
  }
}

module.exports = NodoLibroVisitable;
