"use strict";

const VisitanteCatalogo = require("./VisitanteCatalogo");

class ExportadorCSV extends VisitanteCatalogo {
  #ruta = [];
  #filas = ["categoria;titulo;calificacion"];

  visitarCategoria(categoria) {
    this.#ruta.push(categoria.nombre);
  }

  salirCategoria() {
    this.#ruta.pop();
  }

  visitarLibro(libro) {
    const limpiar = (t) => String(t).replace(/;/g, ",");
    this.#filas.push(`${limpiar(this.#ruta.join(" > "))};${limpiar(libro.titulo)};${libro.calificacion.toFixed(1)}`);
  }

  getResultado() {
    return this.#filas.join("\n");
  }
}

module.exports = ExportadorCSV;
