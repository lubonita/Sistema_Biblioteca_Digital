"use strict";

class VisitanteCatalogo {
  constructor() {
    if (new.target === VisitanteCatalogo) {
      throw new Error("VisitanteCatalogo es una clase base y no puede instanciarse directamente.");
    }
  }

  visitarCategoria(categoria) {
    throw new Error("visitarCategoria() debe ser implementado por la subclase.");
  }

  visitarLibro(libro) {
    throw new Error("visitarLibro() debe ser implementado por la subclase.");
  }

  // Opcional: se llama al terminar de recorrer una categoría.
  salirCategoria(categoria) {}

  getResultado() {
    throw new Error("getResultado() debe ser implementado por la subclase.");
  }
}

module.exports = VisitanteCatalogo;
