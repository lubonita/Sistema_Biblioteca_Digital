"use strict";

const ElementoVisitable = require("./ElementoVisitable");

class NodoCategoriaVisitable extends ElementoVisitable {
  #categoria;

  constructor(categoria) {
    super();
    this.#categoria = categoria;
    this.hijos = categoria.elementos.map((e) => ElementoVisitable.desde(e));
  }

  get nombre() {
    return this.#categoria.nombre;
  }

  aceptar(visitante) {
    visitante.visitarCategoria(this);
    this.hijos.forEach((hijo) => hijo.aceptar(visitante));
    visitante.salirCategoria(this);
  }
}

module.exports = NodoCategoriaVisitable;
