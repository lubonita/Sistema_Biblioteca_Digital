"use strict";

const VisitanteCatalogo = require("./VisitanteCatalogo");

const RANGOS = [
  ["menos de 4.0", (c) => c < 4.0],
  ["4.0 a 4.4", (c) => c >= 4.0 && c < 4.5],
  ["4.5 a 4.7", (c) => c >= 4.5 && c < 4.8],
  ["4.8 a 5.0", (c) => c >= 4.8],
];

class CalculadoraEstadisticas extends VisitanteCatalogo {
  #libros = 0;
  #categorias = 0;
  #suma = 0;
  #mejor = null;
  #peor = null;
  #nivel = 0;
  #profundidad = 0;
  #distribucion = Object.fromEntries(RANGOS.map(([nombre]) => [nombre, 0]));

  visitarCategoria() {
    this.#categorias++;
    this.#nivel++;
    this.#profundidad = Math.max(this.#profundidad, this.#nivel);
  }

  salirCategoria() {
    this.#nivel--;
  }

  visitarLibro(libro) {
    const c = libro.calificacion;
    this.#libros++;
    this.#suma += c;
    if (!this.#mejor || c > this.#mejor.calificacion) this.#mejor = { titulo: libro.titulo, calificacion: c };
    if (!this.#peor || c < this.#peor.calificacion) this.#peor = { titulo: libro.titulo, calificacion: c };
    const rango = RANGOS.find(([, cumple]) => cumple(c));
    this.#distribucion[rango[0]]++;
  }

  getResultado() {
    return {
      totalLibros: this.#libros,
      totalCategorias: this.#categorias,
      promedioPorLibro: this.#libros ? Number((this.#suma / this.#libros).toFixed(2)) : 0,
      mejorLibro: this.#mejor,
      peorLibro: this.#peor,
      profundidad: this.#profundidad,
      distribucion: { ...this.#distribucion },
    };
  }
}

module.exports = CalculadoraEstadisticas;
