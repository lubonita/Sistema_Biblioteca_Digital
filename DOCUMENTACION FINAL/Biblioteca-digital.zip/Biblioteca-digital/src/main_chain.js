"use strict";

const SolicitudPrestamo = require("./solicitudes/validacion/SolicitudPrestamo");
const ValidadorPrestamo = require("./solicitudes/validacion/ValidadorPrestamo");
const ValidadorSesionActiva = require("./solicitudes/validacion/ValidadorSesionActiva");
const ValidadorSuscripcion = require("./solicitudes/validacion/ValidadorSuscripcion");
const ValidadorMultas = require("./solicitudes/validacion/ValidadorMultas");
const ValidadorLimitePrestamos = require("./solicitudes/validacion/ValidadorLimitePrestamos");
const ValidadorFormatoDispositivo = require("./solicitudes/validacion/ValidadorFormatoDispositivo");
const ValidadorLicenciasDisponibles = require("./solicitudes/validacion/ValidadorLicenciasDisponibles");
const GestorSolicitudesPrestamo = require("./solicitudes/validacion/GestorSolicitudesPrestamo");
const SesionManager = require("./auth/SesionManager");

const FECHA = "2026-11-07";
// Perfil base del lector: todo en regla
const lector = {
  cuenta: "lector1", nombre: "Usuario Lector", plan: "premium", suscripcionVence: "2026-12-31",
  multasPendientes: 0, prestamosActivos: 1, dispositivo: "Tablet",
};
const rayuelaEPUB = { titulo: "Rayuela", formato: "EPUB", licenciasDisponibles: 3 };
const solicitud = (cambiosUsuario = {}, libro = rayuelaEPUB) =>
  new SolicitudPrestamo({ usuario: { ...lector, ...cambiosUsuario }, libro, fecha: FECHA });

const sesion = SesionManager.getInstance();
const gestor = new GestorSolicitudesPrestamo();

console.log("========================================");
console.log(" PRUEBA 1: Sin sesión activa - la cadena se detiene en el PRIMER eslabón");
console.log("========================================");
const r1 = gestor.procesar(solicitud());
console.log("Validadores ejecutados:", r1.recorrido);

console.log("\n========================================");
console.log(" PRUEBA 2: Solicitud que cumple todo - recorre los 5 eslabones");
console.log("========================================");
sesion.login("lector1", "lector1");
const r2 = gestor.procesar(solicitud());
console.log("Resultado:", r2.aprobada, "-", r2.motivo);
console.log("Validadores ejecutados:", r2.recorrido);

console.log("\n========================================");
console.log(" PRUEBA 3: Suscripción vencida - se detiene en el eslabón 2");
console.log("========================================");
const r3 = gestor.procesar(solicitud({ suscripcionVence: "2026-10-31" }));
console.log("Validadores ejecutados:", r3.recorrido);

console.log("\n========================================");
console.log(" PRUEBA 4: Multas pendientes - se detiene en el eslabón 3");
console.log("========================================");
const r4 = gestor.procesar(solicitud({ multasPendientes: 2 }));
console.log("Validadores ejecutados:", r4.recorrido);

console.log("\n========================================");
console.log(" PRUEBA 5: Plan básico con 2 préstamos - se detiene en el eslabón 4");
console.log("========================================");
const r5 = gestor.procesar(solicitud({ plan: "basico", prestamosActivos: 2 }));
console.log("Validadores ejecutados:", r5.recorrido);

console.log("\n========================================");
console.log(" PRUEBA 6: EPUB en un Kindle - se detiene en el eslabón 5");
console.log("========================================");
const r6 = gestor.procesar(solicitud({ dispositivo: "Kindle" }));
console.log("Validadores ejecutados:", r6.recorrido);
const r6b = gestor.procesar(solicitud({ dispositivo: "Kindle" }, { titulo: "Rayuela", formato: "MOBI" }));
console.log("Mismo libro en MOBI para el Kindle:", r6b.aprobada);

console.log("\n========================================");
console.log(" PRUEBA 7: Pedir un préstamo a nombre de otro usuario");
console.log("========================================");
sesion.logout();
sesion.login("lzafra", "abcd");
const r7 = gestor.procesar(solicitud());
console.log("Validadores ejecutados:", r7.recorrido);
sesion.logout();
sesion.login("lector1", "lector1");

console.log("\n========================================");
console.log(" PRUEBA 8: Agregar un eslabón nuevo sin modificar los existentes");
console.log("========================================");
const cadenaExtendida = new ValidadorSesionActiva();
cadenaExtendida
  .setSiguiente(new ValidadorSuscripcion())
  .setSiguiente(new ValidadorMultas())
  .setSiguiente(new ValidadorLimitePrestamos())
  .setSiguiente(new ValidadorFormatoDispositivo())
  .setSiguiente(new ValidadorLicenciasDisponibles()); // eslabón nuevo al final
const gestorExtendido = new GestorSolicitudesPrestamo(cadenaExtendida);
const sinLicencias = { titulo: "Dune", formato: "PDF", licenciasDisponibles: 0 };
console.log("Con la cadena estándar:");
gestor.procesar(solicitud({}, sinLicencias));
console.log("Con la cadena extendida:");
const r8 = gestorExtendido.procesar(solicitud({}, sinLicencias));
console.log("Validadores ejecutados:", r8.recorrido);

console.log("\n========================================");
console.log(" PRUEBA 9: Reordenar la cadena (las validaciones baratas primero)");
console.log("========================================");
const cadenaReordenada = new ValidadorMultas();
cadenaReordenada
  .setSiguiente(new ValidadorFormatoDispositivo())
  .setSiguiente(new ValidadorSesionActiva())
  .setSiguiente(new ValidadorSuscripcion())
  .setSiguiente(new ValidadorLimitePrestamos());
const r9 = new GestorSolicitudesPrestamo(cadenaReordenada).procesar(solicitud({ multasPendientes: 1 }));
console.log("Validadores ejecutados:", r9.recorrido);

console.log("\n========================================");
console.log(" PRUEBA 10: Casos de error");
console.log("========================================");
try {
  new ValidadorPrestamo();
} catch (error) {
  console.log("Error capturado (clase base):", error.message);
}
try {
  new ValidadorMultas().setSiguiente("ValidadorSuscripcion");
} catch (error) {
  console.log("Error capturado (eslabón inválido):", error.message);
}
try {
  new SolicitudPrestamo({ usuario: { cuenta: "lector1" }, libro: rayuelaEPUB });
} catch (error) {
  console.log("Error capturado (solicitud incompleta):", error.message);
}
try {
  gestor.procesar({ id: "SOL-falsa", getResumen: () => "objeto suelto" });
} catch (error) {
  console.log("Error capturado (no es SolicitudPrestamo):", error.message);
}
try {
  new GestorSolicitudesPrestamo({});
} catch (error) {
  console.log("Error capturado (gestor sin cadena):", error.message);
}

sesion.logout();
