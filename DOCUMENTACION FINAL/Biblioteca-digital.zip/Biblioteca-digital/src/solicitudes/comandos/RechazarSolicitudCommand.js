"use strict";

const ComandoSolicitud = require("./ComandoSolicitud");

class RechazarSolicitudCommand extends ComandoSolicitud {
  constructor(servicio, idSolicitud, motivo) {
    super(servicio, idSolicitud);
    this.motivo = motivo;
  }

  accion() {
    this.servicio.rechazar(this.idSolicitud, this.motivo);
  }

  getDescripcion() {
    return `Rechazar ${this.idSolicitud} (motivo: ${this.motivo})`;
  }
}

module.exports = RechazarSolicitudCommand;
