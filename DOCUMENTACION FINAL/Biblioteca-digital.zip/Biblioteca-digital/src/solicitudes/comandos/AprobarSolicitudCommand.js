"use strict";

const ComandoSolicitud = require("./ComandoSolicitud");

class AprobarSolicitudCommand extends ComandoSolicitud {
  accion() {
    this.servicio.aprobar(this.idSolicitud);
  }

  getDescripcion() {
    return `Aprobar ${this.idSolicitud}`;
  }
}

module.exports = AprobarSolicitudCommand;
