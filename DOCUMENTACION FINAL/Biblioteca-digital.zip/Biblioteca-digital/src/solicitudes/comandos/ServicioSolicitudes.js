"use strict";

const SolicitudPrestamo = require("../validacion/SolicitudPrestamo");

const ESTADOS = ["PENDIENTE", "EN_REVISION", "APROBADA", "RECHAZADA"];

class ServicioSolicitudes {
  #registros = new Map(); // id -> { solicitud, estado, motivo, observacion }

  // Punto de unión con Chain of Responsibility
  registrarPendiente(solicitud, resultadoValidacion) {
    if (!(solicitud instanceof SolicitudPrestamo)) {
      throw new Error("Solo se pueden registrar objetos SolicitudPrestamo.");
    }
    if (!resultadoValidacion || resultadoValidacion.aprobada !== true) {
      throw new Error(`La solicitud ${solicitud.id} no pasó la validación y no puede registrarse.`);
    }
    this.#registros.set(solicitud.id, { solicitud, estado: "PENDIENTE", motivo: null, observacion: null });
    console.log(`[ServicioSolicitudes] ${solicitud.id} registrada como PENDIENTE.`);
  }

  #buscar(id) {
    const registro = this.#registros.get(id);
    if (!registro) throw new Error(`No existe la solicitud ${id}.`);
    return registro;
  }

  aprobar(id) {
    const r = this.#buscar(id);
    if (!["PENDIENTE", "EN_REVISION"].includes(r.estado)) {
      throw new Error(`No se puede aprobar ${id}: está ${r.estado}.`);
    }
    r.estado = "APROBADA";
    r.motivo = null;
    console.log(`[ServicioSolicitudes] ${id} APROBADA: préstamo de "${r.solicitud.libro.titulo}" habilitado para ${r.solicitud.usuario.nombre}.`);
  }

  rechazar(id, motivo) {
    const r = this.#buscar(id);
    if (!motivo || !String(motivo).trim()) throw new Error("Para rechazar se debe indicar un motivo.");
    if (!["PENDIENTE", "EN_REVISION"].includes(r.estado)) {
      throw new Error(`No se puede rechazar ${id}: está ${r.estado}.`);
    }
    r.estado = "RECHAZADA";
    r.motivo = String(motivo).trim();
    console.log(`[ServicioSolicitudes] ${id} RECHAZADA. Motivo: ${r.motivo}`);
  }

  ponerEnRevision(id, observacion) {
    const r = this.#buscar(id);
    if (r.estado !== "PENDIENTE") throw new Error(`Solo una solicitud PENDIENTE pasa a revisión (${id} está ${r.estado}).`);
    r.estado = "EN_REVISION";
    r.observacion = observacion ? String(observacion).trim() : "Sin observación";
    console.log(`[ServicioSolicitudes] ${id} EN_REVISION. Observación: ${r.observacion}`);
  }

  // Usado por los comandos para deshacer: vuelve al estado que ellos guardaron.
  restaurar(id, { estado, motivo, observacion }) {
    const r = this.#buscar(id);
    if (!ESTADOS.includes(estado)) throw new Error(`Estado inválido: ${estado}`);
    r.estado = estado;
    r.motivo = motivo;
    r.observacion = observacion;
    console.log(`[ServicioSolicitudes] ${id} restaurada a ${estado}.`);
  }

  // Copia de solo lectura del estado de una solicitud
  obtener(id) {
    const r = this.#buscar(id);
    return { id, estado: r.estado, motivo: r.motivo, observacion: r.observacion };
  }

  listar() {
    return [...this.#registros.values()].map((r) => ({
      id: r.solicitud.id,
      usuario: r.solicitud.usuario.nombre,
      libro: r.solicitud.libro.titulo,
      estado: r.estado,
      motivo: r.motivo,
      observacion: r.observacion,
    }));
  }
}

module.exports = ServicioSolicitudes;
