"use strict";

const ServicioSolicitudes = require("./ServicioSolicitudes");

class ComandoSolicitud {
  #estadoAnterior = null;
  #ejecutado = false;

  constructor(servicio, idSolicitud) {
    if (new.target === ComandoSolicitud) {
      throw new Error("ComandoSolicitud es una clase base y no puede instanciarse directamente.");
    }
    if (!(servicio instanceof ServicioSolicitudes)) {
      throw new Error("El comando necesita el ServicioSolicitudes (receptor).");
    }
    this.servicio = servicio;
    this.idSolicitud = idSolicitud;
  }

  ejecutar() {
    if (this.#ejecutado) throw new Error(`El comando "${this.getDescripcion()}" ya fue ejecutado.`);
    this.#estadoAnterior = this.servicio.obtener(this.idSolicitud); // foto mínima para deshacer
    this.accion(); // la operación concreta
    this.#ejecutado = true;
  }

  deshacer() {
    if (!this.#ejecutado) throw new Error(`No se puede deshacer "${this.getDescripcion()}": no se ha ejecutado.`);
    this.servicio.restaurar(this.idSolicitud, this.#estadoAnterior);
    this.#ejecutado = false;
  }

  // Cada comando concreto define qué le pide al receptor.
  accion() {
    throw new Error("accion() debe ser implementado por la subclase.");
  }

  getDescripcion() {
    throw new Error("getDescripcion() debe ser implementado por la subclase.");
  }
}

module.exports = ComandoSolicitud;
