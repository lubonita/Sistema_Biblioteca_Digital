"use strict";

const ComandoSolicitud = require("./ComandoSolicitud");
const SesionManager = require("../../auth/SesionManager");

const ROLES_PERMITIDOS = ["administrador", "bibliotecario"];

class PanelBibliotecario {
  #historial = []; // comandos ejecutados (para deshacer)
  #auditoria = []; // registro permanente de todo lo que se hizo

  #verificarPermiso() {
    const usuario = SesionManager.getInstance().getUsuarioActual();
    if (!usuario) throw new Error("Debe iniciar sesión para gestionar solicitudes.");
    if (!ROLES_PERMITIDOS.includes(usuario.rol)) {
      throw new Error(`El rol "${usuario.rol}" no puede gestionar solicitudes.`);
    }
    return usuario;
  }

  #auditar(usuario, accion, comando) {
    const d = new Date();
    const dos = (n) => String(n).padStart(2, "0");
    const entrada = {
      // Hora local del equipo (no UTC)
      fecha: `${d.getFullYear()}-${dos(d.getMonth() + 1)}-${dos(d.getDate())} ${dos(d.getHours())}:${dos(d.getMinutes())}:${dos(d.getSeconds())}`,
      usuario: usuario.nombre,
      accion,
      descripcion: comando.getDescripcion(),
    };
    this.#auditoria.push(entrada);
    console.log(`[Auditoría] ${entrada.fecha} | ${entrada.usuario} | ${accion} | ${entrada.descripcion}`);
  }

  ejecutar(comando) {
    if (!(comando instanceof ComandoSolicitud)) {
      throw new Error("El panel solo ejecuta objetos ComandoSolicitud.");
    }
    const usuario = this.#verificarPermiso();
    comando.ejecutar();
    this.#historial.push(comando);
    this.#auditar(usuario, "EJECUTAR", comando);
  }

  deshacerUltimo() {
    const usuario = this.#verificarPermiso();
    if (this.#historial.length === 0) throw new Error("No hay acciones para deshacer.");
    const comando = this.#historial[this.#historial.length - 1];
    comando.deshacer(); // si falla, el comando sigue en el historial
    this.#historial.pop();
    this.#auditar(usuario, "DESHACER", comando);
  }

  puedeDeshacer() {
    return this.#historial.length > 0;
  }

  verAuditoria() {
    return this.#auditoria.map((e) => ({ ...e }));
  }
}

module.exports = PanelBibliotecario;
