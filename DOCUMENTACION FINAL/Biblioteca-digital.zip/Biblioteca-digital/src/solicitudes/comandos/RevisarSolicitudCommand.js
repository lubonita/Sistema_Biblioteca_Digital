"use strict";

const ComandoSolicitud = require("./ComandoSolicitud");

class RevisarSolicitudCommand extends ComandoSolicitud {
  constructor(servicio, idSolicitud, observacion) {
    super(servicio, idSolicitud);
    this.observacion = observacion;
  }

  accion() {
    this.servicio.ponerEnRevision(this.idSolicitud, this.observacion);
  }

  getDescripcion() {
    return `Poner en revisión ${this.idSolicitud} (${this.observacion})`;
  }
}

module.exports = RevisarSolicitudCommand;
