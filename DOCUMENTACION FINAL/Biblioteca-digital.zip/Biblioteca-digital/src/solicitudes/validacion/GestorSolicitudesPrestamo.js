"use strict";

const SolicitudPrestamo = require("./SolicitudPrestamo");
const ValidadorPrestamo = require("./ValidadorPrestamo");
const ValidadorSesionActiva = require("./ValidadorSesionActiva");
const ValidadorSuscripcion = require("./ValidadorSuscripcion");
const ValidadorMultas = require("./ValidadorMultas");
const ValidadorLimitePrestamos = require("./ValidadorLimitePrestamos");
const ValidadorFormatoDispositivo = require("./ValidadorFormatoDispositivo");

class GestorSolicitudesPrestamo {
  #primerEslabon;

  constructor(primerEslabon = GestorSolicitudesPrestamo.crearCadenaEstandar()) {
    if (!(primerEslabon instanceof ValidadorPrestamo)) {
      throw new Error("El gestor necesita el primer eslabón de una cadena de validadores.");
    }
    this.#primerEslabon = primerEslabon;
  }

  // Cadena estándar: sesión -> suscripción -> multas -> límite -> formato
  static crearCadenaEstandar() {
    const primero = new ValidadorSesionActiva();
    primero
      .setSiguiente(new ValidadorSuscripcion())
      .setSiguiente(new ValidadorMultas())
      .setSiguiente(new ValidadorLimitePrestamos())
      .setSiguiente(new ValidadorFormatoDispositivo());
    return primero;
  }

  procesar(solicitud) {
    if (!(solicitud instanceof SolicitudPrestamo)) {
      throw new Error("Solo se pueden validar objetos SolicitudPrestamo.");
    }
    console.log(`[GestorSolicitudes] Validando ${solicitud.getResumen()}`);
    const resultado = this.#primerEslabon.manejar(solicitud);
    console.log(
      resultado.aprobada
        ? `[GestorSolicitudes] ${solicitud.id} APROBADA tras ${resultado.recorrido.length} validador(es).`
        : `[GestorSolicitudes] ${solicitud.id} RECHAZADA en ${resultado.validador}: ${resultado.motivo}`
    );
    return resultado;
  }
}

module.exports = GestorSolicitudesPrestamo;
