"use strict";

const SolicitudPrestamo = require("./SolicitudPrestamo");

class ValidadorPrestamo {
  #siguiente = null;

  constructor(nombre) {
    if (new.target === ValidadorPrestamo) {
      throw new Error("ValidadorPrestamo es una clase base y no puede instanciarse directamente.");
    }
    this.nombre = nombre || new.target.name;
  }

  // Devuelve el siguiente para poder encadenar: a.setSiguiente(b).setSiguiente(c)
  setSiguiente(validador) {
    if (!(validador instanceof ValidadorPrestamo)) {
      throw new Error("El siguiente eslabón debe ser un ValidadorPrestamo.");
    }
    this.#siguiente = validador;
    return validador;
  }

  // Cada validador concreto implementa su propia regla.
  validar(solicitud) {
    throw new Error("validar() debe ser implementado por la subclase.");
  }

  // Punto de entrada común: registra el paso y llama a la regla concreta.
  manejar(solicitud) {
    if (!(solicitud instanceof SolicitudPrestamo)) {
      throw new Error("Solo se pueden validar objetos SolicitudPrestamo.");
    }
    solicitud.recorrido.push(this.nombre);
    return this.validar(solicitud);
  }

  pasarAlSiguiente(solicitud) {
    console.log(`  [${this.nombre}] OK`);
    if (this.#siguiente) return this.#siguiente.manejar(solicitud);
    return {
      aprobada: true,
      motivo: "La solicitud cumple todas las validaciones.",
      validador: null,
      recorrido: [...solicitud.recorrido],
    };
  }

  rechazar(solicitud, motivo) {
    console.log(`  [${this.nombre}] RECHAZADA: ${motivo}`);
    return {
      aprobada: false,
      motivo,
      validador: this.nombre,
      recorrido: [...solicitud.recorrido],
    };
  }
}

module.exports = ValidadorPrestamo;
