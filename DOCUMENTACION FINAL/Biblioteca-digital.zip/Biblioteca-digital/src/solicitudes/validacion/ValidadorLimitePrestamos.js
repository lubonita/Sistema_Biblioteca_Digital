"use strict";

const ValidadorPrestamo = require("./ValidadorPrestamo");

class ValidadorLimitePrestamos extends ValidadorPrestamo {
  constructor(limites = { basico: 2, premium: 5 }) {
    super();
    this.limites = limites;
  }

  validar(solicitud) {
    const { plan, prestamosActivos } = solicitud.usuario;
    const limite = this.limites[plan];
    if (limite === undefined) {
      return this.rechazar(solicitud, `El plan "${plan}" no tiene un límite configurado.`);
    }
    if (prestamosActivos >= limite) {
      return this.rechazar(solicitud, `Ya tiene ${prestamosActivos} préstamo(s); el plan ${plan} permite ${limite}.`);
    }
    return this.pasarAlSiguiente(solicitud);
  }
}

module.exports = ValidadorLimitePrestamos;
