"use strict";

const ValidadorPrestamo = require("./ValidadorPrestamo");
const SesionManager = require("../../auth/SesionManager");

class ValidadorSesionActiva extends ValidadorPrestamo {
  validar(solicitud) {
    const usuario = SesionManager.getInstance().getUsuarioActual();
    if (!usuario) {
      return this.rechazar(solicitud, "Debe iniciar sesión para solicitar un préstamo.");
    }
    if (usuario.usuario !== solicitud.usuario.cuenta) {
      return this.rechazar(solicitud, `La sesión activa es de "${usuario.usuario}"; no puede pedir préstamos a nombre de "${solicitud.usuario.cuenta}".`);
    }
    return this.pasarAlSiguiente(solicitud);
  }
}

module.exports = ValidadorSesionActiva;
