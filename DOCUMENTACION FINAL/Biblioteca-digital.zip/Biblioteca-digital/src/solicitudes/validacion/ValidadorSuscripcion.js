"use strict";


const ValidadorPrestamo = require("./ValidadorPrestamo");

class ValidadorSuscripcion extends ValidadorPrestamo {
  validar(solicitud) {
    const { plan, suscripcionVence } = solicitud.usuario;
    if (!plan) {
      return this.rechazar(solicitud, "El usuario no tiene una suscripción activa.");
    }
    if (!suscripcionVence || suscripcionVence < solicitud.fecha) {
      return this.rechazar(solicitud, `La suscripción ${plan} venció el ${suscripcionVence}.`);
    }
    return this.pasarAlSiguiente(solicitud);
  }
}

module.exports = ValidadorSuscripcion;
