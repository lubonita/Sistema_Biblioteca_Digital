"use strict";

const ValidadorPrestamo = require("./ValidadorPrestamo");

const COMPATIBILIDAD = {
  Kindle: ["PDF", "MOBI"],
  Tablet: ["PDF", "EPUB"],
  Celular: ["PDF", "EPUB"],
  PC: ["PDF", "EPUB", "MOBI"],
};

class ValidadorFormatoDispositivo extends ValidadorPrestamo {
  constructor(compatibilidad = COMPATIBILIDAD) {
    super();
    this.compatibilidad = compatibilidad;
  }

  validar(solicitud) {
    const { dispositivo } = solicitud.usuario;
    const { formato } = solicitud.libro;
    const admitidos = this.compatibilidad[dispositivo];
    if (!admitidos) {
      return this.rechazar(solicitud, `El dispositivo "${dispositivo}" no está registrado.`);
    }
    if (!admitidos.includes(formato)) {
      return this.rechazar(solicitud, `El formato ${formato} no se puede leer en ${dispositivo} (admite: ${admitidos.join(", ")}).`);
    }
    return this.pasarAlSiguiente(solicitud);
  }
}

module.exports = ValidadorFormatoDispositivo;
