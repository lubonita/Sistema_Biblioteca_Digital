"use strict";


const ValidadorPrestamo = require("./ValidadorPrestamo");

class ValidadorMultas extends ValidadorPrestamo {
  validar(solicitud) {
    const multas = solicitud.usuario.multasPendientes;
    if (multas > 0) {
      return this.rechazar(solicitud, `Tiene ${multas} multa(s) pendiente(s).`);
    }
    return this.pasarAlSiguiente(solicitud);
  }
}

module.exports = ValidadorMultas;
