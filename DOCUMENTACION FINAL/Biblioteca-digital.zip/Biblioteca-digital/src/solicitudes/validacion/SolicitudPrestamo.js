"use strict";

let consecutivo = 0;

class SolicitudPrestamo {
  constructor({ usuario, libro, fecha }) {
    if (!usuario || !usuario.cuenta || !usuario.nombre) {
      throw new Error("La solicitud necesita un usuario con cuenta y nombre.");
    }
    if (!libro || !libro.titulo || !libro.formato) {
      throw new Error("La solicitud necesita un libro con título y formato.");
    }
    this.id = `SOL-${String(++consecutivo).padStart(3, "0")}`;
    this.usuario = {
      cuenta: usuario.cuenta,
      nombre: usuario.nombre,
      plan: usuario.plan || null, // "basico" | "premium" | null
      suscripcionVence: usuario.suscripcionVence || null, // "AAAA-MM-DD"
      multasPendientes: usuario.multasPendientes || 0,
      prestamosActivos: usuario.prestamosActivos || 0,
      dispositivo: usuario.dispositivo || "PC",
    };
    this.libro = {
      titulo: libro.titulo,
      formato: libro.formato, // "PDF" | "EPUB" | "MOBI"
      licenciasDisponibles: libro.licenciasDisponibles ?? 1,
    };
    this.fecha = fecha || new Date().toISOString().slice(0, 10);
    this.recorrido = []; // validadores que la revisaron, en orden
  }

  getResumen() {
    return `${this.id}: ${this.usuario.nombre} pide "${this.libro.titulo}" (${this.libro.formato}) en ${this.usuario.dispositivo}`;
  }
}

module.exports = SolicitudPrestamo;
