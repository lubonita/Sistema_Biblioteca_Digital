"use strict";

const ValidadorPrestamo = require("./ValidadorPrestamo");

class ValidadorLicenciasDisponibles extends ValidadorPrestamo {
  validar(solicitud) {
    if (solicitud.libro.licenciasDisponibles <= 0) {
      return this.rechazar(solicitud, `"${solicitud.libro.titulo}" no tiene licencias disponibles. Puede reservarlo.`);
    }
    return this.pasarAlSiguiente(solicitud);
  }
}

module.exports = ValidadorLicenciasDisponibles;
