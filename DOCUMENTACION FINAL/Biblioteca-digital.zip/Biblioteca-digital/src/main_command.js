"use strict";

const SolicitudPrestamo = require("./solicitudes/validacion/SolicitudPrestamo");
const GestorSolicitudesPrestamo = require("./solicitudes/validacion/GestorSolicitudesPrestamo");
const ServicioSolicitudes = require("./solicitudes/comandos/ServicioSolicitudes");
const ComandoSolicitud = require("./solicitudes/comandos/ComandoSolicitud");
const AprobarSolicitudCommand = require("./solicitudes/comandos/AprobarSolicitudCommand");
const RechazarSolicitudCommand = require("./solicitudes/comandos/RechazarSolicitudCommand");
const RevisarSolicitudCommand = require("./solicitudes/comandos/RevisarSolicitudCommand");
const PanelBibliotecario = require("./solicitudes/comandos/PanelBibliotecario");
const SesionManager = require("./auth/SesionManager");

const FECHA = "2026-11-07";
const lector = {
  cuenta: "lector1", nombre: "Usuario Lector", plan: "premium", suscripcionVence: "2026-12-31",
  multasPendientes: 0, prestamosActivos: 1, dispositivo: "Tablet",
};
const nueva = (libro, cambios = {}) =>
  new SolicitudPrestamo({ usuario: { ...lector, ...cambios }, libro, fecha: FECHA });

const sesion = SesionManager.getInstance();
const gestor = new GestorSolicitudesPrestamo();
const servicio = new ServicioSolicitudes();
const panel = new PanelBibliotecario();
const estadoDe = (id) => servicio.obtener(id).estado;

console.log("========================================");
console.log(" PRUEBA 1: El lector pide préstamos y la cadena los valida (Chain)");
console.log("========================================");
sesion.login("lector1", "lector1");
const solA = nueva({ titulo: "Rayuela", formato: "EPUB" });
const solB = nueva({ titulo: "Dune", formato: "PDF" });
const solC = nueva({ titulo: "Fundación", formato: "PDF" }, { multasPendientes: 1 });
const resultados = [solA, solB, solC].map((s) => ({ s, r: gestor.procesar(s) }));
resultados.filter((x) => x.r.aprobada).forEach((x) => servicio.registrarPendiente(x.s, x.r));
try {
  servicio.registrarPendiente(solC, resultados[2].r);
} catch (error) {
  console.log("Error capturado (no pasó la cadena):", error.message);
}
console.log("Solicitudes pendientes:", servicio.listar().map((s) => `${s.id} ${s.estado}`));

console.log("\n========================================");
console.log(" PRUEBA 2: La bibliotecaria aprueba una solicitud con un comando");
console.log("========================================");
sesion.logout();
sesion.login("lzafra", "abcd");
panel.ejecutar(new AprobarSolicitudCommand(servicio, solA.id));
console.log(`Estado de ${solA.id}:`, estadoDe(solA.id));

console.log("\n========================================");
console.log(" PRUEBA 3: Rechazar otra solicitud indicando el motivo");
console.log("========================================");
panel.ejecutar(new RechazarSolicitudCommand(servicio, solB.id, "Licencia reservada para otro curso"));
console.log(`Estado de ${solB.id}:`, servicio.obtener(solB.id));

console.log("\n========================================");
console.log(" PRUEBA 4: Deshacer el último comando (el rechazo)");
console.log("========================================");
panel.deshacerUltimo();
console.log(`Estado de ${solB.id}:`, servicio.obtener(solB.id));
console.log(`${solA.id} sigue:`, estadoDe(solA.id));

console.log("\n========================================");
console.log(" PRUEBA 5: Revisión y aprobación, y luego deshacer las dos en orden inverso");
console.log("========================================");
panel.ejecutar(new RevisarSolicitudCommand(servicio, solB.id, "Confirmar disponibilidad de licencias"));
panel.ejecutar(new AprobarSolicitudCommand(servicio, solB.id));
console.log(`Estado de ${solB.id}:`, estadoDe(solB.id));
panel.deshacerUltimo();
console.log(`Tras deshacer 1 vez:`, estadoDe(solB.id));
panel.deshacerUltimo();
console.log(`Tras deshacer 2 veces:`, estadoDe(solB.id));

console.log("\n========================================");
console.log(" PRUEBA 6: Registro de auditoría (fecha, usuario y acción)");
console.log("========================================");
panel.verAuditoria().forEach((e, i) => console.log(`${i + 1}. ${e.fecha} | ${e.usuario} | ${e.accion} | ${e.descripcion}`));

console.log("\n========================================");
console.log(" PRUEBA 7: El panel ejecuta cualquier comando sin conocer al receptor");
console.log("========================================");
const comandos = [
  new RevisarSolicitudCommand(servicio, solB.id, "Validar con coordinación"),
  new RechazarSolicitudCommand(servicio, solB.id, "Material restringido"),
];
comandos.forEach((c) => panel.ejecutar(c));
console.log("Tipos ejecutados por el mismo método panel.ejecutar():", comandos.map((c) => c.constructor.name));
console.log("¿Todos son ComandoSolicitud?", comandos.every((c) => c instanceof ComandoSolicitud));

console.log("\n========================================");
console.log(" PRUEBA 8: Un lector no puede ejecutar ni deshacer comandos");
console.log("========================================");
sesion.logout();
sesion.login("lector1", "lector1");
try {
  panel.ejecutar(new AprobarSolicitudCommand(servicio, solB.id));
} catch (error) {
  console.log("Error capturado (ejecutar):", error.message);
}
try {
  panel.deshacerUltimo();
} catch (error) {
  console.log("Error capturado (deshacer):", error.message);
}
console.log(`${solB.id} sigue:`, estadoDe(solB.id));

console.log("\n========================================");
console.log(" PRUEBA 9: Casos de error");
console.log("========================================");
sesion.logout();
sesion.login("vmillan", "1234");
try {
  panel.ejecutar(new RechazarSolicitudCommand(servicio, solA.id, "   "));
} catch (error) {
  console.log("Error capturado (rechazo sin motivo):", error.message);
}
try {
  panel.ejecutar(new AprobarSolicitudCommand(servicio, solA.id));
} catch (error) {
  console.log("Error capturado (ya aprobada):", error.message);
}
try {
  const repetido = new AprobarSolicitudCommand(servicio, "SOL-999");
  panel.ejecutar(repetido);
} catch (error) {
  console.log("Error capturado (solicitud inexistente):", error.message);
}
try {
  panel.ejecutar({ ejecutar() {}, getDescripcion: () => "objeto suelto" });
} catch (error) {
  console.log("Error capturado (no es un comando):", error.message);
}
try {
  new ComandoSolicitud(servicio, solA.id);
} catch (error) {
  console.log("Error capturado (clase base):", error.message);
}
try {
  const vacio = new PanelBibliotecario();
  vacio.deshacerUltimo();
} catch (error) {
  console.log("Error capturado (historial vacío):", error.message);
}

sesion.logout();
