class StripeAPI {
  createCharge(amountInCents, currency, metadata) {
    const id = "ch_" + Math.random().toString(16).slice(2, 10);
    console.log(
      `[StripeAPI] Cobro creado: ${amountInCents} centavos (${currency}) | metadata: ${JSON.stringify(metadata)}`
    );
    return {
      id,
      status: "succeeded",
    };
  }

  isChargeSuccessful(charge) {
    return charge.status === "succeeded";
  }
}

module.exports = StripeAPI;
