class PasarelaPago {
  procesarPago(monto, concepto) {
    throw new Error("procesarPago() debe ser implementado por la subclase.");
  }
}

module.exports = PasarelaPago;
