const SesionManager = require("./auth/SesionManager");
const PasarelaPago = require("./pagos/PasarelaPago");
const StripeAPI = require("./pagos/StripeAPI");
const StripeAdapter = require("./pagos/StripeAdapter");

console.log("========================================");
console.log(" PRUEBA 1: Iniciar sesión (reutilizando el Singleton)");
console.log("========================================");
const sesion = SesionManager.getInstance();
sesion.login("vmillan", "1234");

console.log("\n========================================");
console.log(" PRUEBA 2: Procesar un pago a través del Adapter");
console.log("========================================");
const stripeApi = new StripeAPI(); // el Adaptee
const pasarela = new StripeAdapter(stripeApi); // el Adapter, usado como PasarelaPago

const resultado = pasarela.procesarPago(29900, "Suscripción Premium - mensual");
console.log("Resultado devuelto al sistema:", resultado);

console.log("\n========================================");
console.log(" PRUEBA 3: Confirmar que el Adapter cumple el contrato PasarelaPago");
console.log("========================================");
console.log("¿pasarela es instancia de PasarelaPago?", pasarela instanceof PasarelaPago);

console.log("\n========================================");
console.log(" PRUEBA 4: Confirmar que el monto se tradujo correctamente a centavos");
console.log("========================================");
console.log("Monto original enviado al sistema (pesos):", resultado.monto);
console.log("(La consola de StripeAPI arriba muestra el mismo monto ya convertido a centavos)");

console.log("\n========================================");
console.log(" PRUEBA 5: Procesar un segundo pago con otro concepto");
console.log("========================================");
const resultado2 = pasarela.procesarPago(9900, "Multa por retraso en devolución");
console.log("Resultado devuelto al sistema:", resultado2);

console.log("\n========================================");
console.log(" PRUEBA 6: Intentar usar el Target directamente (debe fallar)");
console.log("========================================");
try {
  const pasarelaBase = new PasarelaPago();
  pasarelaBase.procesarPago(1000, "Test");
} catch (error) {
  console.log("Error capturado como se esperaba:", error.message);
}
