const PasarelaPago = require("./PasarelaPago");
const SesionManager = require("../auth/SesionManager");

class StripeAdapter extends PasarelaPago {
  constructor(stripeApi) {
    super();
    this.stripe = stripeApi; // instancia del Adaptee
  }

  procesarPago(monto, concepto) {
    const sesion = SesionManager.getInstance();
    const usuario = sesion.getUsuarioActual();
    const nombreUsuario = usuario ? usuario.nombre : "Usuario invitado";

    // Traducción: pesos -> centavos, y armado de metadata para Stripe
    const montoEnCentavos = Math.round(monto * 100);
    const metadata = { usuario: nombreUsuario, concepto };

    const charge = this.stripe.createCharge(montoEnCentavos, "COP", metadata);
    const exitoso = this.stripe.isChargeSuccessful(charge);

    // Traducción del resultado de Stripe a la forma que espera el sistema
    return {
      exitoso,
      idTransaccion: charge.id,
      usuario: nombreUsuario,
      concepto,
      monto,
    };
  }
}

module.exports = StripeAdapter;
