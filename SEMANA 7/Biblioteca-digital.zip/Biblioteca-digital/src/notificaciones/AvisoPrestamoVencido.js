const AvisoBiblioteca = require("./AvisoBiblioteca");

class AvisoPrestamoVencido extends AvisoBiblioteca {
  notificar(usuario) {
    return this.canal.enviar(
      usuario.contacto,
      "Préstamo vencido",
      `Tu préstamo de "${usuario.libro}" venció el ${usuario.fechaVencimiento}.`
    );
  }
}

module.exports = AvisoPrestamoVencido;
