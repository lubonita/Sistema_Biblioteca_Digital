class AvisoBiblioteca {
  constructor(canal) {
    if (new.target === AvisoBiblioteca) {
      throw new Error("AvisoBiblioteca es una clase base y no puede instanciarse directamente.");
    }
    this.canal = canal; // el "puente" hacia el Implementador
  }

  notificar(usuario) {
    throw new Error("notificar() debe ser implementado por la subclase.");
  }

  // Permite cambiar el canal de envío en tiempo de ejecución,
  // sin crear una instancia nueva del aviso.
  cambiarCanal(nuevoCanal) {
    this.canal = nuevoCanal;
  }
}

module.exports = AvisoBiblioteca;
