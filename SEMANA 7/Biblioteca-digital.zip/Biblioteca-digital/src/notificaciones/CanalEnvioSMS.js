const CanalEnvio = require("./CanalEnvio");

class CanalEnvioSMS extends CanalEnvio {
  enviar(destinatario, asunto, mensaje) {
    console.log(`[CanalEnvioSMS] Para: ${destinatario} | "${asunto}: ${mensaje}"`);
    return `SMS enviado a ${destinatario}`;
  }
}

module.exports = CanalEnvioSMS;
