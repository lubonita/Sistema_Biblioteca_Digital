const CanalEnvioEmail = require("./notificaciones/CanalEnvioEmail");
const CanalEnvioSMS = require("./notificaciones/CanalEnvioSMS");
const CanalEnvioPush = require("./notificaciones/CanalEnvioPush");
const AvisoPrestamoVencido = require("./notificaciones/AvisoPrestamoVencido");
const AvisoReservaDisponible = require("./notificaciones/AvisoReservaDisponible");
const AvisoBiblioteca = require("./notificaciones/AvisoBiblioteca");

const usuario = {
  nombre: "Julio Cortázar Jr.",
  contacto: "julio@correo.com",
  libro: "Rayuela",
  fechaVencimiento: "2026-09-20",
};

console.log("========================================");
console.log(" PRUEBA 1: Aviso de préstamo vencido por Email");
console.log("========================================");
const aviso1 = new AvisoPrestamoVencido(new CanalEnvioEmail());
aviso1.notificar(usuario);

console.log("\n========================================");
console.log(" PRUEBA 2: El MISMO tipo de aviso, pero por SMS");
console.log("========================================");
const aviso2 = new AvisoPrestamoVencido(new CanalEnvioSMS());
aviso2.notificar(usuario);

console.log("\n========================================");
console.log(" PRUEBA 3: Un aviso DISTINTO (reserva disponible), por Push");
console.log("========================================");
const aviso3 = new AvisoReservaDisponible(new CanalEnvioPush());
aviso3.notificar(usuario);

console.log("\n========================================");
console.log(" PRUEBA 4: Cambiar el canal de un aviso en tiempo de ejecución");
console.log("========================================");
console.log("Antes del cambio (Email):");
aviso1.notificar(usuario);
aviso1.cambiarCanal(new CanalEnvioPush());
console.log("Después del cambio (Push), sin crear un aviso nuevo:");
aviso1.notificar(usuario);

console.log("\n========================================");
console.log(" PRUEBA 5: Confirmar que no hubo que crear clases combinadas");
console.log("========================================");
console.log(
  "Con 2 tipos de aviso x 3 canales, con herencia pura serían 6 clases combinadas."
);
console.log(
  "Con Bridge: solo 2 (Abstracción) + 3 (Implementador) = 5 clases, y cualquier combinación funciona."
);
console.log("¿aviso1 es AvisoPrestamoVencido?", aviso1.constructor.name === "AvisoPrestamoVencido");
console.log("¿aviso3 es AvisoReservaDisponible?", aviso3.constructor.name === "AvisoReservaDisponible");

console.log("\n========================================");
console.log(" PRUEBA 6: Intentar usar la Abstracción base directamente (debe fallar)");
console.log("========================================");
try {
  new AvisoBiblioteca(new CanalEnvioEmail());
} catch (error) {
  console.log("Error capturado como se esperaba:", error.message);
}
