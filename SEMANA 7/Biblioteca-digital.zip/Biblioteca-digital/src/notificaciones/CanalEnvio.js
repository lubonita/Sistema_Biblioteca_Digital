class CanalEnvio {
  enviar(destinatario, asunto, mensaje) {
    throw new Error("enviar() debe ser implementado por la subclase.");
  }
}

module.exports = CanalEnvio;
