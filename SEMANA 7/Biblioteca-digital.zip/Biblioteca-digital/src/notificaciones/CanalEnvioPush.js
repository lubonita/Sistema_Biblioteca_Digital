const CanalEnvio = require("./CanalEnvio");

class CanalEnvioPush extends CanalEnvio {
  enviar(destinatario, asunto, mensaje) {
    console.log(`[CanalEnvioPush] Notificación push para: ${destinatario} | "${asunto}"`);
    return `Push enviado a ${destinatario}`;
  }
}

module.exports = CanalEnvioPush;
