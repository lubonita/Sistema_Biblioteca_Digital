const AvisoBiblioteca = require("./AvisoBiblioteca");

class AvisoReservaDisponible extends AvisoBiblioteca {
  notificar(usuario) {
    return this.canal.enviar(
      usuario.contacto,
      "Reserva disponible",
      `Tu reserva de "${usuario.libro}" ya está disponible para recoger.`
    );
  }
}

module.exports = AvisoReservaDisponible;
