const CanalEnvio = require("./CanalEnvio");

class CanalEnvioEmail extends CanalEnvio {
  enviar(destinatario, asunto, mensaje) {
    console.log(`[CanalEnvioEmail] Para: ${destinatario} | Asunto: "${asunto}" | Mensaje: "${mensaje}"`);
    return `Email enviado a ${destinatario}`;
  }
}

module.exports = CanalEnvioEmail;
