const EjemplarLibro = require("./ejemplares/EjemplarLibro");
const RegistroPrototipos = require("./ejemplares/RegistroPrototipos");

console.log("========================================");
console.log(" PRUEBA 1: Crear un ejemplar original y clonarlo directamente");
console.log("========================================");
const ejemplarOriginal = new EjemplarLibro(
  "Cien años de soledad",
  "Gabriel García Márquez",
  "BIB-001",
  true,
  "2024-03-10",
  ["Ejemplar de referencia"]
);
console.log("Original:", ejemplarOriginal.getResumen());

const ejemplarClonado = ejemplarOriginal.clonar();
ejemplarClonado.codigoEjemplar = "BIB-002";
console.log("Clon (con nuevo código):", ejemplarClonado.getResumen());

console.log("\n========================================");
console.log(" PRUEBA 2: Confirmar que son objetos independientes");
console.log("========================================");
console.log("¿Son el mismo objeto?", ejemplarOriginal === ejemplarClonado);
console.log("Código del original:", ejemplarOriginal.codigoEjemplar);
console.log("Código del clon:", ejemplarClonado.codigoEjemplar);

console.log("\n========================================");
console.log(" PRUEBA 3: Confirmar que las notas no se comparten entre original y clon");
console.log("========================================");
ejemplarClonado.notas.push("Clon con detalle en la pasta");
console.log("Notas del original:", ejemplarOriginal.notas);
console.log("Notas del clon:", ejemplarClonado.notas);

console.log("\n========================================");
console.log(" PRUEBA 4: Usar el Registro de Prototipos");
console.log("========================================");
const registro = new RegistroPrototipos();

const plantillaEstandar = new EjemplarLibro(
  "(sin título aún)",
  "(sin autor aún)",
  "PLANTILLA-ESTANDAR",
  true,
  null,
  ["Ejemplar estándar, disponible para préstamo a domicilio"]
);
registro.registrar("estandar", plantillaEstandar);

const plantillaReferencia = new EjemplarLibro(
  "(sin título aún)",
  "(sin autor aún)",
  "PLANTILLA-REFERENCIA",
  false,
  null,
  ["Ejemplar de solo consulta en sala, no se presta a domicilio"]
);
registro.registrar("referencia", plantillaReferencia);

console.log("Plantillas registradas: estandar, referencia");

console.log("\n========================================");
console.log(" PRUEBA 5: Clonar desde el Registro y personalizar el resultado");
console.log("========================================");
const nuevoEjemplar = registro.obtenerClon("estandar");
nuevoEjemplar.tituloLibro = "Rayuela";
nuevoEjemplar.autorLibro = "Julio Cortázar";
nuevoEjemplar.codigoEjemplar = "BIB-045";
console.log("Nuevo ejemplar (clonado desde plantilla 'estandar'):", nuevoEjemplar.getResumen());
console.log("Notas heredadas de la plantilla:", nuevoEjemplar.notas);

console.log("\n========================================");
console.log(" PRUEBA 6: Intentar pedir un prototipo que no existe (debe fallar)");
console.log("========================================");
try {
  registro.obtenerClon("premium-inexistente");
} catch (error) {
  console.log("Error capturado como se esperaba:", error.message);
}
