const Reporte = require("./Reporte");

class ReportePDF extends Reporte {
  generar(usuario, datos) {
    console.log(`[ReportePDF] Generando reporte de actividad para ${usuario} en formato PDF.`);
    return `Reporte PDF de ${usuario}: ${datos}`;
  }
}

module.exports = ReportePDF;
