const SesionManager = require("../auth/SesionManager");

class GestorServicios {
  constructor(factory) {
    this.notificacion = factory.crearNotificacion();
    this.reporte = factory.crearReporte();
  }

  avisarYReportar(mensaje, datosActividad) {
    const sesion = SesionManager.getInstance();
    const usuario = sesion.getUsuarioActual();
    const nombreUsuario = usuario ? usuario.nombre : "Usuario invitado";

    this.notificacion.enviar(nombreUsuario, mensaje);
    return this.reporte.generar(nombreUsuario, datosActividad);
  }
}

module.exports = GestorServicios;
