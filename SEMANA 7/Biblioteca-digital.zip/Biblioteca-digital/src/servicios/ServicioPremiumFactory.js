const ServicioFactory = require("./ServicioFactory");
const NotificacionSMS = require("./NotificacionSMS");
const ReporteExcel = require("./ReporteExcel");

class ServicioPremiumFactory extends ServicioFactory {
  crearNotificacion() {
    return new NotificacionSMS();
  }

  crearReporte() {
    return new ReporteExcel();
  }
}

module.exports = ServicioPremiumFactory;
