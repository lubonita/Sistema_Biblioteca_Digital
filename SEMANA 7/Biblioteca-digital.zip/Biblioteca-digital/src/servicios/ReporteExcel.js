const Reporte = require("./Reporte");

class ReporteExcel extends Reporte {
  generar(usuario, datos) {
    console.log(`[ReporteExcel] Generando reporte de actividad para ${usuario} en formato Excel.`);
    return `Reporte Excel de ${usuario}: ${datos}`;
  }
}

module.exports = ReporteExcel;
