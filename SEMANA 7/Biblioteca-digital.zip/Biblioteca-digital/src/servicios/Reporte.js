class Reporte {
  generar(usuario, datos) {
    throw new Error("generar() debe ser implementado por la subclase.");
  }
}

module.exports = Reporte;
