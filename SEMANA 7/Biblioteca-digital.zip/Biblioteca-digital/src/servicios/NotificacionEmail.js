const Notificacion = require("./Notificacion");

class NotificacionEmail extends Notificacion {
  enviar(destinatario, mensaje) {
    console.log(`[NotificacionEmail] Para: ${destinatario} | Mensaje: "${mensaje}"`);
    return `Email enviado a ${destinatario}`;
  }
}

module.exports = NotificacionEmail;
