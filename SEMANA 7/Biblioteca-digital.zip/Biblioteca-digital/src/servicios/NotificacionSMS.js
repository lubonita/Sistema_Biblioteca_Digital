const Notificacion = require("./Notificacion");

class NotificacionSMS extends Notificacion {
  enviar(destinatario, mensaje) {
    console.log(`[NotificacionSMS] Para: ${destinatario} | Mensaje: "${mensaje}"`);
    return `SMS enviado a ${destinatario}`;
  }
}

module.exports = NotificacionSMS;
