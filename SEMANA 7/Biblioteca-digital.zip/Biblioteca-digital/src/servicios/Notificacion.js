class Notificacion {
  enviar(destinatario, mensaje) {
    throw new Error("enviar() debe ser implementado por la subclase.");
  }
}

module.exports = Notificacion;
