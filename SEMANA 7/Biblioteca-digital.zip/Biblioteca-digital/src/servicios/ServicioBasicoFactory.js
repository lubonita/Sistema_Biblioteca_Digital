const ServicioFactory = require("./ServicioFactory");
const NotificacionEmail = require("./NotificacionEmail");
const ReportePDF = require("./ReportePDF");

class ServicioBasicoFactory extends ServicioFactory {
  crearNotificacion() {
    return new NotificacionEmail();
  }

  crearReporte() {
    return new ReportePDF();
  }
}

module.exports = ServicioBasicoFactory;
