class ServicioFactory {
  crearNotificacion() {
    throw new Error("crearNotificacion() debe ser implementado por la subclase.");
  }

  crearReporte() {
    throw new Error("crearReporte() debe ser implementado por la subclase.");
  }
}

module.exports = ServicioFactory;
