const SesionManager = require("./auth/SesionManager");
const ServicioBasicoFactory = require("./servicios/ServicioBasicoFactory");
const ServicioPremiumFactory = require("./servicios/ServicioPremiumFactory");
const GestorServicios = require("./servicios/GestorServicios");

console.log("========================================");
console.log(" PRUEBA 1: Iniciar sesión (reutilizando el Singleton)");
console.log("========================================");
const sesion = SesionManager.getInstance();
sesion.login("vmillan", "1234");

console.log("\n========================================");
console.log(" PRUEBA 2: Usar la familia BÁSICA (Email + PDF)");
console.log("========================================");
const gestorBasico = new GestorServicios(new ServicioBasicoFactory());
gestorBasico.avisarYReportar(
  "Tu préstamo vence mañana.",
  "3 libros prestados este mes"
);

console.log("\n========================================");
console.log(" PRUEBA 3: Usar la familia PREMIUM (SMS + Excel)");
console.log("========================================");
const gestorPremium = new GestorServicios(new ServicioPremiumFactory());
gestorPremium.avisarYReportar(
  "Tu préstamo vence mañana.",
  "3 libros prestados este mes"
);

console.log("\n========================================");
console.log(" PRUEBA 4: Confirmar que cada familia es coherente (no se mezcla)");
console.log("========================================");
console.log("¿Notificación básica es NotificacionEmail?", gestorBasico.notificacion.constructor.name === "NotificacionEmail");
console.log("¿Reporte básico es ReportePDF?", gestorBasico.reporte.constructor.name === "ReportePDF");
console.log("¿Notificación premium es NotificacionSMS?", gestorPremium.notificacion.constructor.name === "NotificacionSMS");
console.log("¿Reporte premium es ReporteExcel?", gestorPremium.reporte.constructor.name === "ReporteExcel");

console.log("\n========================================");
console.log(" PRUEBA 5: Intentar usar la Fábrica Abstracta directamente (debe fallar)");
console.log("========================================");
try {
  const ServicioFactory = require("./servicios/ServicioFactory");
  const factoryBase = new ServicioFactory();
  factoryBase.crearNotificacion();
} catch (error) {
  console.log("Error capturado como se esperaba:", error.message);
}

console.log("\n========================================");
console.log(" PRUEBA 6: Intentar usar un Producto Abstracto directamente (debe fallar)");
console.log("========================================");
try {
  const Notificacion = require("./servicios/Notificacion");
  const notifBase = new Notificacion();
  notifBase.enviar("X", "Y");
} catch (error) {
  console.log("Error capturado como se esperaba:", error.message);
}
