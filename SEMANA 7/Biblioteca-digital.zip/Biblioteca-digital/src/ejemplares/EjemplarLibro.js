class EjemplarLibro {
  constructor(tituloLibro, autorLibro, codigoEjemplar, disponible, fechaAdquisicion, notas) {
    this.tituloLibro = tituloLibro;
    this.autorLibro = autorLibro;
    this.codigoEjemplar = codigoEjemplar;
    this.disponible = disponible;
    this.fechaAdquisicion = fechaAdquisicion;
    // Array: se copia con slice() al clonar, para que cada ejemplar
    // tenga su propia lista de notas y no comparta referencia.
    this.notas = notas || [];
  }

  // El propio objeto sabe copiarse a sí mismo.
  clonar() {
    return new EjemplarLibro(
      this.tituloLibro,
      this.autorLibro,
      this.codigoEjemplar,
      this.disponible,
      this.fechaAdquisicion,
      this.notas.slice() // copia independiente del arreglo, no la misma referencia
    );
  }

  getResumen() {
    return `Ejemplar [${this.codigoEjemplar}] de "${this.tituloLibro}" - ${this.disponible ? "disponible" : "prestado"}`;
  }
}

module.exports = EjemplarLibro;
