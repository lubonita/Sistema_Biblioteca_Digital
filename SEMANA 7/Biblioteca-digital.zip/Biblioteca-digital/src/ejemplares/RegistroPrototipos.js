class RegistroPrototipos {
  constructor() {
    this.prototipos = new Map();
  }

  registrar(nombre, prototipo) {
    this.prototipos.set(nombre, prototipo);
  }

  obtenerClon(nombre) {
    const prototipo = this.prototipos.get(nombre);
    if (!prototipo) {
      throw new Error(`No existe ningún prototipo registrado con el nombre "${nombre}".`);
    }
    return prototipo.clonar();
  }
}

module.exports = RegistroPrototipos;
