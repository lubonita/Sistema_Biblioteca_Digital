const $ = (id) => document.getElementById(id);
const esc = (t) => String(t ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
let cuentaPortal = null; // cuenta del lector que usa este portal
let catalogo = [];

// ---------------------------------------------------------- utilidades
function toast(texto, tipo) {
  const t = $("toast");
  t.textContent = texto;
  t.classList.toggle("ok", tipo === "APROBADA" || tipo === "ok");
  t.classList.add("ver");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => t.classList.remove("ver"), 4200);
}

async function api(patron, accion, datos = {}) {
  const r = await fetch(`/api/${patron}/${accion}`, {
    method: accion === "estado" ? "GET" : "POST",
    headers: { "Content-Type": "application/json" },
    body: accion === "estado" ? undefined : JSON.stringify(datos),
  });
  const respuesta = await r.json();
  if (respuesta.sesion !== undefined) pintarSesion(respuesta.sesion);
  return respuesta;
}

function pintarSesion(s) {
  $("sesionDot").classList.toggle("on", !!s);
  $("sesionTexto").textContent = s ? s.nombre : "Sin sesión";
  $("sesionRol").textContent = s ? s.rol : "";
}

// ---------------------------------------------------------- OBSERVER (front)
// Sujeto: las solicitudes del lector. Observadores: campana, lista, aviso e historial.
const misSolicitudes = new MisSolicitudesSujeto();
const contador = new ContadorCampana($("contadorCampana"));
const historial = new HistorialActividad($("actividad"));
misSolicitudes.suscribir(contador);
misSolicitudes.suscribir(new ListaMisSolicitudes($("misSolicitudes")));
misSolicitudes.suscribir(new AvisoEmergente((texto, tipo) => {
  toast(texto, tipo);
  $("campana").classList.remove("timbre");
  void $("campana").offsetWidth; // reinicia la animación
  $("campana").classList.add("timbre");
}));
misSolicitudes.suscribir(historial);

function marcarLeidos() {
  contador.marcarLeidos();
}

// ---------------------------------------------------------- STATE (front)
// Context: el visor. También es un Sujeto: la vista y el historial lo observan.
const visor = new VisorLibro();
const botones = {};
document.querySelectorAll(".visor-botones button").forEach((b) => {
  botones[b.dataset.accion] = b;
  b.addEventListener("click", () => accionVisor(b.dataset.accion));
});
visor.suscribir(new VistaVisor({
  estado: $("visorEstado"), titulo: $("visorTitulo"), pagina: $("visorPagina"),
  texto: $("visorTexto"), error: $("visorError"), botones,
}));
visor.suscribir(historial);
// Dibujo inicial (estado CERRADO)
new VistaVisor({
  estado: $("visorEstado"), titulo: $("visorTitulo"), pagina: $("visorPagina"),
  texto: $("visorTexto"), error: $("visorError"), botones,
}).actualizar("ESTADO_VISOR", visor.getInfo());

function accionVisor(accion) {
  try {
    visor[accion](); // el estado actual decide si es válido
    if (accion === "reintentar") cargarLibro(visor.libro.id);
  } catch (error) {
    toast(error.message);
  }
}

// Abrir: el visor pasa a CARGANDO y el back verifica la licencia
async function abrirLibro(id) {
  const s = misSolicitudes.getSolicitudes().find((x) => x.id === id);
  try {
    if (visor.getEstado() !== "CERRADO") visor.cerrar();
    visor.abrir({ id, titulo: s ? s.libro : id });
  } catch (error) {
    return toast(error.message);
  }
  await cargarLibro(id);
}

async function cargarLibro(id) {
  const r = await api("lector", "abrirLibro", { cuenta: cuentaPortal, id });
  await new Promise((ok) => setTimeout(ok, 400)); // deja ver el estado CARGANDO
  if (visor.getEstado() !== "CARGANDO") return; // el lector cerró mientras cargaba
  if (r.ok) visor.terminarCarga(r.resultado.paginas);
  else visor.fallarCarga(r.error);
}

// ---------------------------------------------------------- catálogo y préstamos
function pintarCatalogo() {
  $("catalogo").innerHTML = catalogo.map((l) => `
    <div class="libro-cat">
      <span class="badge">${esc(l.formato)}</span>
      <div class="info"><div class="t">${esc(l.titulo)}</div><div class="m">${esc(l.autor)} · ${l.licencias} licencia(s) libre(s)</div></div>
      <button class="btn-sec" onclick="solicitar('${esc(l.id)}')">Solicitar</button>
    </div>`).join("");
}

async function solicitar(libroId) {
  if (!cuentaPortal) return toast("Primero entra con tu cuenta.");
  const r = await api("lector", "solicitar", { cuenta: cuentaPortal, libroId, dispositivo: $("dispositivo").value });
  if (!r.ok) return toast(r.error);
  const x = r.resultado;
  toast(x.aprobada
    ? `Solicitud ${x.id} enviada: pasó todas las validaciones y quedó PENDIENTE para el bibliotecario.`
    : `Solicitud rechazada en ${x.validador}: ${x.motivo}`, x.aprobada ? "ok" : null);
  await sincronizar();
}

async function entrar() {
  const cuenta = $("cuenta").value;
  const claves = { lector1: "lector1", lzafra: "abcd", vmillan: "1234" };
  const r = await api("sesion", "login", { usuario: cuenta, password: claves[cuenta] });
  if (!r.ok) return toast(r.error);
  cuentaPortal = cuenta;
  $("portalDe").textContent = cuenta;
  await sincronizar();
}

// Trae del back las solicitudes del lector y se las entrega al Sujeto:
// el Sujeto detecta los cambios y avisa a todos sus observadores.
async function sincronizar() {
  if (!cuentaPortal) return;
  try {
    const r = await api("lector", "misSolicitudes", { cuenta: cuentaPortal });
    if (r.ok) misSolicitudes.actualizarDesdeServidor(r.resultado);
  } catch (e) {
    /* servidor no disponible: se reintenta en el siguiente ciclo */
  }
}

// ---------------------------------------------------------- inicio
(async function iniciar() {
  const e = await api("lector", "estado");
  catalogo = e.estado.catalogo;
  $("cuenta").innerHTML = e.estado.cuentas.map((c) => `<option value="${esc(c.cuenta)}">${esc(c.cuenta)} · plan ${esc(c.plan)}</option>`).join("");
  pintarCatalogo();
  if (e.sesion) {
    $("cuenta").value = e.sesion.usuario;
    cuentaPortal = e.sesion.usuario;
    $("portalDe").textContent = cuentaPortal;
  }
  await sincronizar();
  setInterval(sincronizar, 2000); // consulta periódica al back
})();
