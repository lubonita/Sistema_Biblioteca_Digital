"use strict";

const FichaLibroBuilder = require("./libros/FichaLibro/FichaLibroBuilder");
const CatalogadorDirector = require("./libros/FichaLibro/CatalogadorDirector");
const FichaEditable = require("./edicion/FichaEditable");
const MementoFicha = require("./edicion/MementoFicha");
const HistorialFicha = require("./edicion/HistorialFicha");
const SesionManager = require("./auth/SesionManager");

const sesion = SesionManager.getInstance();
const director = new CatalogadorDirector();
const builder = new FichaLibroBuilder();

console.log("========================================");
console.log(" PRUEBA 1: Crear la ficha con el Builder y volverla editable");
console.log("========================================");
sesion.login("lzafra", "abcd");
const fichaLibro = director.construirFichaCompleta(builder, {
  titulo: "Cien años de soledad",
  autor: "Gabriel García Márquez",
  anioPublicacion: 1967,
  categorias: ["Novela", "Realismo mágico"],
  idioma: "Español",
});
const ficha = new FichaEditable(fichaLibro);
const historial = new HistorialFicha(ficha);
console.log("Ficha original:", ficha.getResumen());

console.log("\n========================================");
console.log(" PRUEBA 2: Guardar una versión antes de cada cambio y editar");
console.log("========================================");
historial.guardar("Versión original");
ficha.editar("titulo", "Cien años de soledad (Edición conmemorativa)");
historial.guardar("Después de cambiar el título");
ficha.editar("anioPublicacion", 2017);
historial.guardar("Después de cambiar el año");
ficha.editar("categorias", ["Novela", "Edición especial"]);
console.log("Ficha editada:", ficha.getResumen());
console.log("Versiones en el historial:", historial.listar());

console.log("\n========================================");
console.log(" PRUEBA 3: Deshacer el último cambio (categorías)");
console.log("========================================");
historial.deshacer();
console.log("Ficha ahora:", ficha.getResumen());

console.log("\n========================================");
console.log(" PRUEBA 4: Deshacer todo hasta volver a la ficha original");
console.log("========================================");
while (historial.puedeDeshacer()) {
  historial.deshacer();
}
console.log("Ficha ahora:", ficha.getResumen());
console.log("¿Quedan cambios por deshacer?", historial.puedeDeshacer());

console.log("\n========================================");
console.log(" PRUEBA 5: La ficha y el memento guardan copias independientes de las categorías");
console.log("========================================");
historial.guardar("Antes de modificar el arreglo de categorías");
const categorias = ficha.obtener("categorias");
categorias.push("Categoría agregada desde fuera");
console.log("Categorías en la ficha (no cambiaron):", ficha.obtener("categorias"));
ficha.editar("categorias", ["Solo una categoría"]);
historial.deshacer();
console.log("Categorías restauradas:", ficha.obtener("categorias"));

console.log("\n========================================");
console.log(" PRUEBA 6: El Caretaker guarda el memento pero no puede leer su contenido");
console.log("========================================");
historial.guardar("Versión de prueba");
const memento = historial.verUltimo();
console.log("Descripción visible:", memento.getDescripcion());
console.log("Propiedades públicas del memento:", Object.keys(memento));
console.log("¿memento.estado existe?", memento.estado !== undefined);
try {
  memento.obtenerEstado(Symbol("llaveFicha"));
} catch (error) {
  console.log("Error capturado (leer con otra llave):", error.message);
}

console.log("\n========================================");
console.log(" PRUEBA 7: Una ficha no puede restaurarse con el memento de OTRA ficha");
console.log("========================================");
const otraFicha = new FichaEditable(director.construirFichaBasica(builder, { titulo: "Rayuela", autor: "Julio Cortázar" }));
try {
  otraFicha.restaurar(memento);
} catch (error) {
  console.log("Error capturado:", error.message);
}
console.log("Rayuela no cambió:", otraFicha.getResumen());

console.log("\n========================================");
console.log(" PRUEBA 8: Historial con límite de versiones (control de memoria)");
console.log("========================================");
const fichaDune = new FichaEditable(director.construirFichaBasica(builder, { titulo: "Dune", autor: "Frank Herbert" }));
const historialCorto = new HistorialFicha(fichaDune, 3);
for (let v = 1; v <= 5; v++) {
  historialCorto.guardar(`Versión ${v}`);
  fichaDune.editar("anioPublicacion", 1964 + v);
}
console.log("Versiones conservadas:", historialCorto.listar());

console.log("\n========================================");
console.log(" PRUEBA 9: Un lector no puede editar ni restaurar fichas");
console.log("========================================");
sesion.logout();
sesion.login("lector1", "lector1");
try {
  ficha.editar("titulo", "Título cambiado por un lector");
} catch (error) {
  console.log("Error capturado (editar):", error.message);
}
try {
  historial.deshacer();
} catch (error) {
  console.log("Error capturado (deshacer):", error.message);
}
console.log("La ficha sigue igual:", ficha.getResumen());
console.log("La versión NO se perdió; versiones en el historial:", historial.getCantidad());

console.log("\n========================================");
console.log(" PRUEBA 10: Otros casos de error");
console.log("========================================");
sesion.logout();
sesion.login("vmillan", "1234");
const historialVacio = new HistorialFicha(new FichaEditable(director.construirFichaBasica(builder, { titulo: "Fundación", autor: "Isaac Asimov" })));
try {
  historialVacio.deshacer();
} catch (error) {
  console.log("Error capturado (historial vacío):", error.message);
}
try {
  ficha.editar("precio", 50000);
} catch (error) {
  console.log("Error capturado (campo inexistente):", error.message);
}
try {
  new FichaEditable({ titulo: "Objeto suelto" });
} catch (error) {
  console.log("Error capturado (no es FichaLibro):", error.message);
}
try {
  new MementoFicha({ categorias: [] }, "llave-falsa", "Memento falso");
} catch (error) {
  console.log("Error capturado (memento falso):", error.message);
}

sesion.logout();
