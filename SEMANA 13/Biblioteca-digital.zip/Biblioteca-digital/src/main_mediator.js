"use strict";

const Mediador = require("./coordinacion/Mediador");
const MediadorBiblioteca = require("./coordinacion/MediadorBiblioteca");
const ModuloPrestamos = require("./coordinacion/ModuloPrestamos");
const ModuloReservas = require("./coordinacion/ModuloReservas");
const ModuloAvisos = require("./coordinacion/ModuloAvisos");

const dune = { isbn: "978-0441172719", titulo: "Dune", autor: "Frank Herbert", editorial: "Ace" };
const rayuela = { isbn: "978-8437604572", titulo: "Rayuela", autor: "Julio Cortázar", editorial: "Cátedra" };

const valentina = { nombre: "Valentina Millán", contacto: "vmillan@uts.edu.co", canal: "email" };
const luz = { nombre: "Luz Estela Zafra", contacto: "+57 300 123 4567", canal: "sms" };
const lector = { nombre: "Usuario Lector", contacto: "lector1-app", canal: "push" };

console.log("========================================");
console.log(" PRUEBA 1: Crear el mediador y registrar los tres módulos");
console.log("========================================");
const mediador = new MediadorBiblioteca();
const prestamos = new ModuloPrestamos(mediador);
const reservas = new ModuloReservas(mediador);
const avisos = new ModuloAvisos(mediador);
mediador.registrarModulos(prestamos, reservas, avisos);

console.log("\n========================================");
console.log(" PRUEBA 2: Prestar un libro y recibir reservas en la cola de espera");
console.log("========================================");
prestamos.prestar(valentina, dune, "2026-11-20");
reservas.reservar(dune.isbn, dune.titulo, luz);
reservas.reservar(dune.isbn, dune.titulo, lector);
console.log("Personas esperando Dune:", reservas.cantidadEnEspera(dune.isbn));

console.log("\n========================================");
console.log(" PRUEBA 3: Devolver el libro - el mediador coordina todo el flujo");
console.log("========================================");
const resultado1 = prestamos.devolver(dune.isbn, valentina);
console.log("Resultado:", resultado1);
console.log("Personas esperando Dune ahora:", reservas.cantidadEnEspera(dune.isbn));

console.log("\n========================================");
console.log(" PRUEBA 4: Segunda devolución - se avisa al siguiente, por su propio canal");
console.log("========================================");
prestamos.prestar(luz, dune, "2026-12-04");
const resultado2 = prestamos.devolver(dune.isbn, luz);
console.log("Resultado:", resultado2);
console.log("Personas esperando Dune ahora:", reservas.cantidadEnEspera(dune.isbn));

console.log("\n========================================");
console.log(" PRUEBA 5: Devolución sin reservas - no se envía ningún aviso");
console.log("========================================");
prestamos.prestar(lector, rayuela, "2026-11-25");
const resultado3 = prestamos.devolver(rayuela.isbn, lector);
console.log("Resultado:", resultado3);
console.log("Avisos enviados en total:", avisos.getTotalEnviados());

console.log("\n========================================");
console.log(" PRUEBA 6: Las colas de cada libro son independientes");
console.log("========================================");
prestamos.prestar(valentina, dune, "2026-12-10");
prestamos.prestar(luz, rayuela, "2026-12-10");
reservas.reservar(dune.isbn, dune.titulo, lector);
reservas.reservar(rayuela.isbn, rayuela.titulo, valentina);
prestamos.devolver(rayuela.isbn, luz);
console.log("Esperando Dune:", reservas.cantidadEnEspera(dune.isbn), "| Esperando Rayuela:", reservas.cantidadEnEspera(rayuela.isbn));

console.log("\n========================================");
console.log(" PRUEBA 7: Los módulos NO se conocen entre sí, solo conocen al mediador");
console.log("========================================");
const conoceOtroModulo = (modulo) =>
  Object.values(modulo).some((v) => v instanceof ModuloPrestamos || v instanceof ModuloReservas || v instanceof ModuloAvisos);
console.log("¿Préstamos conoce a otro módulo?", conoceOtroModulo(prestamos));
console.log("¿Reservas conoce a otro módulo?", conoceOtroModulo(reservas));
console.log("¿Avisos conoce a otro módulo?", conoceOtroModulo(avisos));
console.log("¿Los tres comparten el mismo mediador?",
  prestamos.mediador === mediador && reservas.mediador === mediador && avisos.mediador === mediador);

console.log("\n========================================");
console.log(" PRUEBA 8: Si el aviso falla, el usuario no pierde su turno");
console.log("========================================");
const usuarioFax = { nombre: "Usuario con fax", contacto: "fax-001", canal: "fax" };
const fundacion = { isbn: "978-0553293357", titulo: "Fundación", autor: "Isaac Asimov", editorial: "Bantam" };
prestamos.prestar(valentina, fundacion, "2026-12-15");
reservas.reservar(fundacion.isbn, fundacion.titulo, usuarioFax);
try {
  prestamos.devolver(fundacion.isbn, valentina);
} catch (error) {
  console.log("Error capturado:", error.message);
}
console.log("¿Sigue en la cola de Fundación?", reservas.cantidadEnEspera(fundacion.isbn) === 1);

console.log("\n========================================");
console.log(" PRUEBA 9: Casos de error");
console.log("========================================");
try {
  prestamos.devolver(rayuela.isbn, luz);
} catch (error) {
  console.log("Error capturado (libro no prestado):", error.message);
}
try {
  prestamos.devolver(dune.isbn, luz);
} catch (error) {
  console.log("Error capturado (usuario equivocado):", error.message);
}
try {
  prestamos.prestar(luz, dune, "2026-12-20");
} catch (error) {
  console.log("Error capturado (libro ya prestado):", error.message);
}
try {
  reservas.reservar(dune.isbn, dune.titulo, lector);
} catch (error) {
  console.log("Error capturado (reserva duplicada):", error.message);
}
try {
  mediador.notificar(reservas, "LIBRO_DEVUELTO", { isbn: dune.isbn, titulo: dune.titulo });
} catch (error) {
  console.log("Error capturado (emisor no autorizado):", error.message);
}
try {
  mediador.notificar(prestamos, "LIBRO_PERDIDO", {});
} catch (error) {
  console.log("Error capturado (evento desconocido):", error.message);
}
try {
  new ModuloReservas({});
} catch (error) {
  console.log("Error capturado (módulo sin mediador):", error.message);
}
try {
  new Mediador();
} catch (error) {
  console.log("Error capturado (interfaz Mediador):", error.message);
}
