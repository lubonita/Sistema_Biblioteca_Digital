"use strict";

const ModuloBiblioteca = require("./ModuloBiblioteca");
const AvisoReservaDisponible = require("../notificaciones/AvisoReservaDisponible");
const CanalEnvioEmail = require("../notificaciones/CanalEnvioEmail");
const CanalEnvioSMS = require("../notificaciones/CanalEnvioSMS");
const CanalEnvioPush = require("../notificaciones/CanalEnvioPush");

const CANALES = {
  email: () => new CanalEnvioEmail(),
  sms: () => new CanalEnvioSMS(),
  push: () => new CanalEnvioPush(),
};

class ModuloAvisos extends ModuloBiblioteca {
  #enviados = 0;

  avisarReservaDisponible(usuario, titulo) {
    const crearCanal = CANALES[usuario.canal || "email"];
    if (!crearCanal) {
      throw new Error(`El canal "${usuario.canal}" no está disponible.`);
    }
    const aviso = new AvisoReservaDisponible(crearCanal());
    const resultado = aviso.notificar({ contacto: usuario.contacto, libro: titulo });
    this.#enviados++;
    return resultado;
  }

  getTotalEnviados() {
    return this.#enviados;
  }
}

module.exports = ModuloAvisos;
