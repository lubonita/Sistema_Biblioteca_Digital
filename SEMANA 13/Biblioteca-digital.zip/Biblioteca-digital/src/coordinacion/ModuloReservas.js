"use strict";

const ModuloBiblioteca = require("./ModuloBiblioteca");

class ModuloReservas extends ModuloBiblioteca {
  #colas = new Map(); // isbn -> [usuarios en espera]

  reservar(isbn, titulo, usuario) {
    if (!this.#colas.has(isbn)) this.#colas.set(isbn, []);
    const cola = this.#colas.get(isbn);
    if (cola.some((u) => u.nombre === usuario.nombre)) {
      throw new Error(`${usuario.nombre} ya tiene una reserva de "${titulo}".`);
    }
    cola.push(usuario);
    console.log(`[Reservas] ${usuario.nombre} reservó "${titulo}". Posición en la cola: ${cola.length}.`);
    return cola.length;
  }

  // Saca de la cola al primero en espera (o devuelve null si no hay nadie).
  atenderSiguiente(isbn) {
    const cola = this.#colas.get(isbn);
    if (!cola || cola.length === 0) return null;
    const usuario = cola.shift();
    if (cola.length === 0) this.#colas.delete(isbn);
    return usuario;
  }

  // Devuelve a un usuario al primer lugar (si no se le pudo atender).
  reponerAlFrente(isbn, usuario) {
    if (!this.#colas.has(isbn)) this.#colas.set(isbn, []);
    this.#colas.get(isbn).unshift(usuario);
  }

  cantidadEnEspera(isbn) {
    return this.#colas.has(isbn) ? this.#colas.get(isbn).length : 0;
  }
}

module.exports = ModuloReservas;
