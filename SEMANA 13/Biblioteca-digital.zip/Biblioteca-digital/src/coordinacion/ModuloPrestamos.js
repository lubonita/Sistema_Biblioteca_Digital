"use strict";

const ModuloBiblioteca = require("./ModuloBiblioteca");
const FabricaLibrosCompartidos = require("../prestamos/FabricaLibrosCompartidos");
const PrestamoActivo = require("../prestamos/PrestamoActivo");

class ModuloPrestamos extends ModuloBiblioteca {
  #activos = new Map(); // isbn -> PrestamoActivo
  #fabrica = new FabricaLibrosCompartidos();
  #consecutivo = 0;

  prestar(usuario, datosLibro, vencimiento) {
    if (this.#activos.has(datosLibro.isbn)) {
      throw new Error(`"${datosLibro.titulo}" ya está prestado. Debe reservarse.`);
    }
    const libro = this.#fabrica.obtener(datosLibro);
    const codigo = `PRE-${String(++this.#consecutivo).padStart(3, "0")}`;
    const prestamo = new PrestamoActivo(usuario.nombre, libro, codigo, vencimiento);
    this.#activos.set(libro.isbn, prestamo);
    console.log(`[Préstamos] Préstamo registrado: ${prestamo.resumen()}`);
    return prestamo;
  }

  devolver(isbn, usuario) {
    const prestamo = this.#activos.get(isbn);
    if (!prestamo) {
      throw new Error(`No hay un préstamo activo para el ISBN ${isbn}.`);
    }
    if (prestamo.usuario !== usuario.nombre) {
      throw new Error(`El libro lo tiene ${prestamo.usuario}, no ${usuario.nombre}.`);
    }
    this.#activos.delete(isbn);
    console.log(`[Préstamos] Préstamo ${prestamo.codigoEjemplar} cerrado: "${prestamo.libro.titulo}" devuelto por ${usuario.nombre}.`);

    // Único punto de contacto con el resto del sistema:
    return this.mediador.notificar(this, "LIBRO_DEVUELTO", { isbn, titulo: prestamo.libro.titulo });
  }

  estaPrestado(isbn) {
    return this.#activos.has(isbn);
  }
}

module.exports = ModuloPrestamos;
