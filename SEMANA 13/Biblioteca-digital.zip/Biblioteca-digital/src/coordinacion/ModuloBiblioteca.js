"use strict";

const Mediador = require("./Mediador");

class ModuloBiblioteca {
  constructor(mediador) {
    if (new.target === ModuloBiblioteca) {
      throw new Error("ModuloBiblioteca es una clase base y no puede instanciarse directamente.");
    }
    if (!(mediador instanceof Mediador)) {
      throw new Error("Cada módulo necesita un Mediador para comunicarse.");
    }
    this.mediador = mediador;
  }
}

module.exports = ModuloBiblioteca;
