"use strict";

class Mediador {
  constructor() {
    if (new.target === Mediador) {
      throw new Error("Mediador es una interfaz y no se puede instanciar directamente.");
    }
  }

  notificar(emisor, evento, datos) {
    throw new Error("notificar() debe ser implementado por la subclase.");
  }
}

module.exports = Mediador;
