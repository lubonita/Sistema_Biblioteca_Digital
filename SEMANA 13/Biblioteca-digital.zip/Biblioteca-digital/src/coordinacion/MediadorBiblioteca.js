"use strict";

const Mediador = require("./Mediador");
const ModuloPrestamos = require("./ModuloPrestamos");
const ModuloReservas = require("./ModuloReservas");
const ModuloAvisos = require("./ModuloAvisos");

class MediadorBiblioteca extends Mediador {
  #prestamos = null;
  #reservas = null;
  #avisos = null;

  registrarModulos(prestamos, reservas, avisos) {
    if (!(prestamos instanceof ModuloPrestamos) ||
        !(reservas instanceof ModuloReservas) ||
        !(avisos instanceof ModuloAvisos)) {
      throw new Error("Se deben registrar un ModuloPrestamos, un ModuloReservas y un ModuloAvisos.");
    }
    this.#prestamos = prestamos;
    this.#reservas = reservas;
    this.#avisos = avisos;
    console.log("[Mediador] Módulos registrados: Préstamos, Reservas y Avisos.");
  }

  notificar(emisor, evento, datos) {
    if (!this.#prestamos) {
      throw new Error("El mediador no tiene módulos registrados.");
    }
    switch (evento) {
      case "LIBRO_DEVUELTO":
        if (emisor !== this.#prestamos) {
          throw new Error("Solo el módulo de préstamos puede informar una devolución.");
        }
        return this.#coordinarDevolucion(datos);
      default:
        throw new Error(`Evento desconocido para el mediador: "${evento}".`);
    }
  }

  #coordinarDevolucion({ isbn, titulo }) {
    console.log(`[Mediador] Evento LIBRO_DEVUELTO recibido para "${titulo}".`);
    const siguiente = this.#reservas.atenderSiguiente(isbn);
    if (!siguiente) {
      console.log(`[Mediador] No hay reservas: "${titulo}" queda disponible.`);
      return { titulo, avisadoA: null };
    }
    console.log(`[Mediador] Primero en la cola: ${siguiente.nombre}. Se solicita el aviso.`);
    try {
      this.#avisos.avisarReservaDisponible(siguiente, titulo);
    } catch (error) {
      // Si el aviso falla, el usuario no pierde su turno: vuelve al primer lugar.
      this.#reservas.reponerAlFrente(isbn, siguiente);
      throw error;
    }
    return { titulo, avisadoA: siguiente.nombre };
  }
}

module.exports = MediadorBiblioteca;
