"use strict";

const LibroCatalogado = require("./catalogo/LibroCatalogado");
const Categoria = require("./catalogo/Categoria");
const Iterador = require("./catalogo/iterador/Iterador");
const Agregado = require("./catalogo/iterador/Agregado");
const IteradorCatalogo = require("./catalogo/iterador/IteradorCatalogo");
const RecorridoCatalogo = require("./catalogo/iterador/RecorridoCatalogo");
const RecorridoLista = require("./catalogo/iterador/RecorridoLista");
const GeneradorRecomendaciones = require("./catalogo/iterador/GeneradorRecomendaciones");
const SesionManager = require("./auth/SesionManager");

// Catálogo de ejemplo armado con el Composite existente (sin modificarlo)
const novela = new Categoria("Novela");
novela.agregar(new LibroCatalogado("Cien años de soledad", 4.8));
novela.agregar(new LibroCatalogado("Rayuela", 4.5));

const cienciaFiccion = new Categoria("Ciencia Ficción");
cienciaFiccion.agregar(new LibroCatalogado("Dune", 4.7));
cienciaFiccion.agregar(new LibroCatalogado("Fundación", 4.6));

const literatura = new Categoria("Literatura");
literatura.agregar(novela);
literatura.agregar(cienciaFiccion);
literatura.agregar(new LibroCatalogado("Veinte poemas de amor", 4.3));

const catalogo = new RecorridoCatalogo(literatura);

console.log("========================================");
console.log(" PRUEBA 1: Recorrer el árbol del catálogo con haySiguiente() y siguiente()");
console.log("========================================");
const it = catalogo.crearIterador();
while (it.haySiguiente()) {
  const libro = it.siguiente();
  console.log(`- ${libro.titulo} (${libro.calificacion.toFixed(1)})  [${it.getRutaActual()}]`);
}

console.log("\n========================================");
console.log(" PRUEBA 2: El mismo catálogo recorrido con for...of (protocolo nativo)");
console.log("========================================");
for (const libro of catalogo) {
  console.log("-", libro.titulo);
}

console.log("\n========================================");
console.log(" PRUEBA 3: Dos iteradores independientes sobre el mismo catálogo");
console.log("========================================");
const itA = catalogo.crearIterador();
const itB = catalogo.crearIterador();
itA.siguiente();
itA.siguiente();
console.log("itA avanzó 2 veces; su próximo libro es:", itA.siguiente().titulo);
console.log("itB no se movió; su primer libro es:", itB.siguiente().titulo);

console.log("\n========================================");
console.log(" PRUEBA 4: Una lista plana (Novedades) se recorre con la MISMA interfaz");
console.log("========================================");
const novedades = new RecorridoLista("Novedades del mes", [
  new LibroCatalogado("El nombre del viento", 4.9),
  new LibroCatalogado("La sombra del viento", 4.4),
  new LibroCatalogado("Proyecto Hail Mary", 4.7),
]);
const itLista = novedades.crearIterador();
while (itLista.haySiguiente()) {
  console.log("-", itLista.siguiente().titulo);
}

console.log("\n========================================");
console.log(" PRUEBA 5: Iterador filtrado (solo libros con calificación >= 4.6)");
console.log("========================================");
const itFiltro = catalogo.crearIteradorFiltrado((libro) => libro.calificacion >= 4.6);
while (itFiltro.haySiguiente()) {
  const libro = itFiltro.siguiente();
  console.log(`- ${libro.titulo} (${libro.calificacion.toFixed(1)})`);
}

console.log("\n========================================");
console.log(" PRUEBA 6: El generador de recomendaciones no sabe si recorre árbol o lista");
console.log("========================================");
const sesion = SesionManager.getInstance();
sesion.login("lector1", "lector1");
const generador = new GeneradorRecomendaciones();
generador.recomendar(catalogo, 4.6, 2);
generador.recomendar(novedades, 4.6, 2);

console.log("\n========================================");
console.log(" PRUEBA 7: Escalabilidad - catálogo de 100.000 libros, recorrido perezoso");
console.log("========================================");
const granCatalogo = new Categoria("Catálogo general");
for (let c = 0; c < 100; c++) {
  const categoria = new Categoria(`Categoría ${c + 1}`);
  for (let l = 0; l < 1000; l++) {
    categoria.agregar(new LibroCatalogado(`Libro ${c + 1}-${l + 1}`, 3 + ((c + l) % 21) / 10));
  }
  granCatalogo.agregar(categoria);
}
console.log("Libros en el catálogo:", granCatalogo.getTotalLibros());

const itGrande = new IteradorCatalogo(granCatalogo);
const primeros = [];
while (itGrande.haySiguiente() && primeros.length < 5) {
  const libro = itGrande.siguiente();
  if (libro.calificacion >= 4.9) primeros.push(libro.titulo);
}
console.log("Primeros 5 libros con calificación >= 4.9:", primeros.join(", "));
console.log("Nodos visitados para encontrarlos:", itGrande.nodosVisitados, "de 100.101 nodos del árbol");

console.log("\n========================================");
console.log(" PRUEBA 8: Árbol muy profundo - recursión vs. iterador con pila");
console.log("========================================");
const raizProfunda = new Categoria("Nivel 0");
let actual = raizProfunda;
for (let n = 1; n <= 20000; n++) {
  const sub = new Categoria(`Nivel ${n}`);
  actual.agregar(sub);
  actual = sub;
}
actual.agregar(new LibroCatalogado("Libro en el fondo del árbol", 4.2));
try {
  raizProfunda.getTotalLibros();
  console.log("La recursión del Composite terminó sin problema.");
} catch (error) {
  console.log("La recursión del Composite falla:", error.constructor.name, "-", error.message);
}
const itProfundo = new IteradorCatalogo(raizProfunda);
console.log("El iterador con pila sí llega al libro:", itProfundo.siguiente().titulo);

console.log("\n========================================");
console.log(" PRUEBA 9: Casos de error");
console.log("========================================");
try {
  const itCorto = new RecorridoLista("Vacía", []).crearIterador();
  itCorto.siguiente();
} catch (error) {
  console.log("Error capturado (iterador agotado):", error.message);
}
try {
  new Iterador();
} catch (error) {
  console.log("Error capturado (interfaz Iterador):", error.message);
}
try {
  new Agregado();
} catch (error) {
  console.log("Error capturado (interfaz Agregado):", error.message);
}
try {
  new RecorridoCatalogo("Literatura");
} catch (error) {
  console.log("Error capturado (raíz inválida):", error.message);
}
try {
  catalogo.crearIteradorFiltrado("calificacion >= 4");
} catch (error) {
  console.log("Error capturado (filtro inválido):", error.message);
}
try {
  generador.recomendar([1, 2, 3]);
} catch (error) {
  console.log("Error capturado (colección no recorrible):", error.message);
}

sesion.logout();
