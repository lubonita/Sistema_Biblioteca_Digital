"use strict";

const Iterador = require("./Iterador");

class IteradorFiltrado extends Iterador {
  #base;
  #condicion;
  #pendiente = null;
  #hayPendiente = false;

  constructor(iteradorBase, condicion) {
    super();
    if (!(iteradorBase instanceof Iterador)) {
      throw new Error("IteradorFiltrado necesita otro Iterador como base.");
    }
    if (typeof condicion !== "function") {
      throw new Error("La condición del filtro debe ser una función.");
    }
    this.#base = iteradorBase;
    this.#condicion = condicion;
  }

  haySiguiente() {
    while (!this.#hayPendiente && this.#base.haySiguiente()) {
      const candidato = this.#base.siguiente();
      if (this.#condicion(candidato)) {
        this.#pendiente = candidato;
        this.#hayPendiente = true;
      }
    }
    return this.#hayPendiente;
  }

  siguiente() {
    if (!this.haySiguiente()) {
      throw new Error("No hay más elementos que cumplan el filtro.");
    }
    this.#hayPendiente = false;
    return this.#pendiente;
  }
}

module.exports = IteradorFiltrado;
