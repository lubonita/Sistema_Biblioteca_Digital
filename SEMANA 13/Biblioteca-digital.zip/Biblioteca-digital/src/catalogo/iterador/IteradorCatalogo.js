"use strict";

const Iterador = require("./Iterador");
const ElementoCatalogo = require("../ElementoCatalogo");
const Categoria = require("../Categoria");

class IteradorCatalogo extends Iterador {
  #pila;
  #rutaActual = "";

  constructor(raiz) {
    super();
    if (!(raiz instanceof ElementoCatalogo)) {
      throw new Error("IteradorCatalogo necesita un ElementoCatalogo como raíz.");
    }
    this.#pila = [{ elemento: raiz, ruta: [] }];
    this.nodosVisitados = 0; // para evidenciar el recorrido perezoso
  }

  // Avanza por la pila hasta dejar un libro en la cima (o vaciarla).
  haySiguiente() {
    while (this.#pila.length > 0) {
      const { elemento, ruta } = this.#pila[this.#pila.length - 1];
      if (!(elemento instanceof Categoria)) return true; // hoja lista para entregar

      this.#pila.pop();
      this.nodosVisitados++;
      const rutaHijos = [...ruta, elemento.nombre];
      // Se apilan al revés para que salgan en el mismo orden en que se agregaron.
      for (let i = elemento.elementos.length - 1; i >= 0; i--) {
        this.#pila.push({ elemento: elemento.elementos[i], ruta: rutaHijos });
      }
    }
    return false;
  }

  siguiente() {
    if (!this.haySiguiente()) {
      throw new Error("No hay más libros en el catálogo.");
    }
    const { elemento, ruta } = this.#pila.pop();
    this.nodosVisitados++;
    this.#rutaActual = ruta.join(" > ");
    return elemento;
  }

  // Categoría a la que pertenece el último libro entregado (ej. "Literatura > Novela").
  getRutaActual() {
    return this.#rutaActual;
  }
}

module.exports = IteradorCatalogo;
