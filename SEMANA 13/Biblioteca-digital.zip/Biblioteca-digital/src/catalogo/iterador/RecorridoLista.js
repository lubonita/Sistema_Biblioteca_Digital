"use strict";

const Agregado = require("./Agregado");
const IteradorLista = require("./IteradorLista");
const IteradorFiltrado = require("./IteradorFiltrado");

class RecorridoLista extends Agregado {
  #elementos;

  constructor(nombre, elementos = []) {
    super();
    this.nombre = nombre;
    this.#elementos = [...elementos];
  }

  agregar(elemento) {
    this.#elementos.push(elemento);
  }

  crearIterador() {
    return new IteradorLista(this.#elementos);
  }

  crearIteradorFiltrado(condicion) {
    return new IteradorFiltrado(this.crearIterador(), condicion);
  }

  getNombre() {
    return this.nombre;
  }
}

module.exports = RecorridoLista;
