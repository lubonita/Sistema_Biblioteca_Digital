"use strict";

class Iterador {
  constructor() {
    if (new.target === Iterador) {
      throw new Error("Iterador es una interfaz y no se puede instanciar directamente.");
    }
  }

  haySiguiente() {
    throw new Error("haySiguiente() debe ser implementado por la subclase.");
  }

  siguiente() {
    throw new Error("siguiente() debe ser implementado por la subclase.");
  }

  // Puente con el protocolo nativo: permite escribir  for (const libro of iterador)
  [Symbol.iterator]() {
    return {
      next: () =>
        this.haySiguiente()
          ? { value: this.siguiente(), done: false }
          : { value: undefined, done: true },
    };
  }
}

module.exports = Iterador;
