"use strict";

const Agregado = require("./Agregado");
const IteradorCatalogo = require("./IteradorCatalogo");
const IteradorFiltrado = require("./IteradorFiltrado");
const Categoria = require("../Categoria");

class RecorridoCatalogo extends Agregado {
  #raiz;

  constructor(raiz) {
    super();
    if (!(raiz instanceof Categoria)) {
      throw new Error("RecorridoCatalogo necesita una Categoria raíz del catálogo.");
    }
    this.#raiz = raiz;
  }

  crearIterador() {
    return new IteradorCatalogo(this.#raiz);
  }

  crearIteradorFiltrado(condicion) {
    return new IteradorFiltrado(this.crearIterador(), condicion);
  }

  getNombre() {
    return this.#raiz.nombre;
  }
}

module.exports = RecorridoCatalogo;
