"use strict";

const Iterador = require("./Iterador");

class IteradorLista extends Iterador {
  #elementos;
  #posicion = 0;

  constructor(elementos) {
    super();
    if (!Array.isArray(elementos)) {
      throw new Error("IteradorLista necesita un arreglo de elementos.");
    }
    this.#elementos = elementos;
  }

  haySiguiente() {
    return this.#posicion < this.#elementos.length;
  }

  siguiente() {
    if (!this.haySiguiente()) {
      throw new Error("No hay más elementos en la lista.");
    }
    return this.#elementos[this.#posicion++];
  }
}

module.exports = IteradorLista;
