"use strict";

const Agregado = require("./Agregado");
const SesionManager = require("../../auth/SesionManager");

class GeneradorRecomendaciones {
  recomendar(coleccion, calificacionMinima = 4.5, cantidad = 3) {
    if (!(coleccion instanceof Agregado)) {
      throw new Error("Solo se puede recomendar a partir de un Agregado recorrible.");
    }
    if (!Number.isInteger(cantidad) || cantidad <= 0) {
      throw new Error("La cantidad de recomendaciones debe ser un entero mayor que cero.");
    }

    const usuario = SesionManager.getInstance().usuarioActual;
    const destinatario = usuario ? usuario.nombre : "Invitado";

    const iterador = coleccion.crearIteradorFiltrado(
      (libro) => libro.calificacion >= calificacionMinima
    );

    const recomendados = [];
    while (iterador.haySiguiente() && recomendados.length < cantidad) {
      recomendados.push(iterador.siguiente());
    }

    console.log(
      `[Recomendaciones] Para ${destinatario} desde "${coleccion.getNombre()}" ` +
        `(calificación >= ${calificacionMinima}):`
    );
    recomendados.forEach((libro, i) =>
      console.log(`  ${i + 1}. ${libro.titulo} (${libro.calificacion.toFixed(1)})`)
    );
    if (recomendados.length === 0) console.log("  (sin libros que cumplan el criterio)");

    return recomendados;
  }
}

module.exports = GeneradorRecomendaciones;
