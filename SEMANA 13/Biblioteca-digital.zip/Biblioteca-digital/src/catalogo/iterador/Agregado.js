"use strict";

class Agregado {
  constructor() {
    if (new.target === Agregado) {
      throw new Error("Agregado es una interfaz y no se puede instanciar directamente.");
    }
  }

  crearIterador() {
    throw new Error("crearIterador() debe ser implementado por la subclase.");
  }

  // Cada for...of sobre el agregado arranca un recorrido NUEVO desde el inicio.
  [Symbol.iterator]() {
    return this.crearIterador()[Symbol.iterator]();
  }
}

module.exports = Agregado;
