"use strict";

class MementoFicha {
  #estado;
  #llave;
  #descripcion;
  #fecha;

  constructor(estado, llave, descripcion) {
    if (typeof llave !== "symbol") {
      throw new Error("Un MementoFicha solo puede ser creado por una FichaEditable.");
    }
    this.#estado = Object.freeze({ ...estado, categorias: Object.freeze([...estado.categorias]) });
    this.#llave = llave;
    this.#descripcion = descripcion;
    this.#fecha = new Date();
  }

  // Datos públicos: sirven para listar el historial sin revelar el contenido.
  getDescripcion() {
    return this.#descripcion;
  }

  getFecha() {
    return this.#fecha;
  }

  // Solo quien presente la misma llave con la que se creó puede leer el estado.
  obtenerEstado(llave) {
    if (llave !== this.#llave) {
      throw new Error("Acceso denegado: solo la ficha que creó este memento puede leerlo.");
    }
    return this.#estado;
  }
}

module.exports = MementoFicha;
