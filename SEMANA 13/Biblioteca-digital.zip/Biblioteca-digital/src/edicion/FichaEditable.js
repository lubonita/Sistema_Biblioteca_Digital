"use strict";

const FichaLibro = require("../libros/FichaLibro/FichaLibro");
const MementoFicha = require("./MementoFicha");
const SesionManager = require("../auth/SesionManager");

const CAMPOS_EDITABLES = [
  "titulo", "autor", "portadaUrl", "sinopsis", "isbn",
  "categorias", "anioPublicacion", "idioma", "editorial", "disponible",
];
const ROLES_PERMITIDOS = ["administrador", "bibliotecario"];

class FichaEditable {
  #ficha;
  #llave = Symbol("llaveFicha"); // privada y distinta para cada ficha

  constructor(ficha) {
    if (!(ficha instanceof FichaLibro)) {
      throw new Error("FichaEditable necesita una FichaLibro construida con el Builder.");
    }
    this.#ficha = ficha;
  }

  #verificarPermiso() {
    const usuario = SesionManager.getInstance().getUsuarioActual();
    if (!usuario) throw new Error("Debe iniciar sesión para editar fichas.");
    if (!ROLES_PERMITIDOS.includes(usuario.rol)) {
      throw new Error(`El rol "${usuario.rol}" no tiene permiso para editar fichas.`);
    }
    return usuario;
  }

  editar(campo, valor) {
    const usuario = this.#verificarPermiso();
    if (!CAMPOS_EDITABLES.includes(campo)) {
      throw new Error(`El campo "${campo}" no existe en la ficha del libro.`);
    }
    this.#ficha[campo] = Array.isArray(valor) ? [...valor] : valor;
    console.log(`[Edición] ${usuario.nombre} cambió "${campo}".`);
    return this;
  }

  obtener(campo) {
    const valor = this.#ficha[campo];
    return Array.isArray(valor) ? [...valor] : valor;
  }

  getResumen() {
    return this.#ficha.getResumen();
  }

  // Toma la "foto" del estado actual.
  crearMemento(descripcion = "Versión guardada") {
    const estado = {};
    CAMPOS_EDITABLES.forEach((campo) => (estado[campo] = this.obtener(campo)));
    return new MementoFicha(estado, this.#llave, descripcion);
  }

  // Vuelve al estado guardado en el memento.
  restaurar(memento) {
    this.#verificarPermiso();
    if (!(memento instanceof MementoFicha)) {
      throw new Error("Solo se puede restaurar a partir de un MementoFicha.");
    }
    const estado = memento.obtenerEstado(this.#llave); // falla si el memento es de otra ficha
    CAMPOS_EDITABLES.forEach((campo) => {
      const valor = estado[campo];
      this.#ficha[campo] = Array.isArray(valor) ? [...valor] : valor;
    });
    console.log(`[Edición] Ficha restaurada a: "${memento.getDescripcion()}".`);
  }
}

module.exports = FichaEditable;
