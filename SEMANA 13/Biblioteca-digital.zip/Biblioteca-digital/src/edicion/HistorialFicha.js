"use strict";

const FichaEditable = require("./FichaEditable");

class HistorialFicha {
  #ficha;
  #pila = [];
  #limite;

  constructor(fichaEditable, limite = 20) {
    if (!(fichaEditable instanceof FichaEditable)) {
      throw new Error("HistorialFicha necesita una FichaEditable.");
    }
    if (!Number.isInteger(limite) || limite <= 0) {
      throw new Error("El límite del historial debe ser un entero mayor que cero.");
    }
    this.#ficha = fichaEditable;
    this.#limite = limite;
  }

  // Guarda el estado actual ANTES de hacer un cambio.
  guardar(descripcion) {
    this.#pila.push(this.#ficha.crearMemento(descripcion));
    if (this.#pila.length > this.#limite) this.#pila.shift(); // descarta la versión más antigua
    console.log(`[Historial] Versión guardada: "${descripcion}" (${this.#pila.length}/${this.#limite}).`);
  }

  // Devuelve la ficha a la última versión guardada.
  deshacer() {
    if (this.#pila.length === 0) {
      throw new Error("No hay cambios para deshacer.");
    }
    // Primero restaura y solo después retira el memento: si la restauración
    // falla (por ejemplo, por falta de permisos), la versión no se pierde.
    this.#ficha.restaurar(this.#pila[this.#pila.length - 1]);
    this.#pila.pop();
  }

  puedeDeshacer() {
    return this.#pila.length > 0;
  }

  getCantidad() {
    return this.#pila.length;
  }

  // Solo muestra datos públicos de cada memento, nunca su contenido.
  listar() {
    return this.#pila.map((m, i) => `${i + 1}. ${m.getDescripcion()}`);
  }

  // Permite comprobar en las pruebas que el Caretaker no puede leer el contenido.
  verUltimo() {
    return this.#pila[this.#pila.length - 1];
  }
}

module.exports = HistorialFicha;
