"use strict";

// =====================================================================
// SERVIDOR DEL PANEL GRÁFICO (sin librerías externas, solo Node.js)
// ---------------------------------------------------------------------
// La página web NO tiene copias de las clases: cada botón llama a este
// servidor, que ejecuta las clases REALES de src/ y le devuelve a la
// página el resultado y los mismos console.log que se verían en la consola.
//
// Uso (desde la raíz del proyecto):   node web/servidor.js
// Luego abrir en el navegador:         http://localhost:3000
// =====================================================================

const http = require("http");
const fs = require("fs");
const path = require("path");

const PUERTO = Number(process.env.PORT) || 3000;
const CARPETA_PANEL = path.join(__dirname, "panel");

// Un adaptador por patrón (cada uno usa las clases reales de src/)
const fabricas = {
  sesion: require("./api/sesion"),
  // Creacionales
  singleton: require("./api/singleton"),
  factory: require("./api/factory"),
  builder: require("./api/builder"),
  abstractFactory: require("./api/abstractFactory"),
  prototype: require("./api/prototype"),
  // Estructurales
  adapter: require("./api/adapter"),
  bridge: require("./api/bridge"),
  decoratorSuscripcion: require("./api/decoratorSuscripcion"),
  composite: require("./api/composite"),
  decoratorReporte: require("./api/decoratorReporte"),
  facade: require("./api/facade"),
  flyweight: require("./api/flyweight"),
  proxy: require("./api/proxy"),
  // Comportamiento
  iterator: require("./api/iterator"),
  memento: require("./api/memento"),
  mediator: require("./api/mediator"),
};
const instancias = {};

const TIPOS = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
};

// Ejecuta una función capturando todo lo que imprima con console.log
function ejecutarCapturando(funcion) {
  const consola = [];
  const logOriginal = console.log;
  console.log = (...args) =>
    consola.push(args.map((a) => (typeof a === "string" ? a : JSON.stringify(a))).join(" "));
  try {
    const resultado = funcion();
    return { ok: true, resultado, consola };
  } catch (error) {
    return { ok: false, error: error.message, consola };
  } finally {
    console.log = logOriginal;
  }
}

// Consultas internas de estado: se ejecutan sin mostrar sus mensajes.
function silencioso(funcion) {
  return ejecutarCapturando(funcion).resultado;
}

// Se crean los escenarios iniciales sin ensuciar la terminal del servidor.
for (const nombre of Object.keys(fabricas)) instancias[nombre] = silencioso(() => fabricas[nombre]());

function responderJSON(res, codigo, datos) {
  res.writeHead(codigo, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(datos));
}

function leerCuerpo(req) {
  return new Promise((resolver) => {
    let texto = "";
    req.on("data", (parte) => (texto += parte));
    req.on("end", () => {
      try {
        resolver(texto ? JSON.parse(texto) : {});
      } catch {
        resolver({});
      }
    });
  });
}

async function atenderAPI(req, res, patron, accion) {
  if (!instancias[patron]) return responderJSON(res, 404, { ok: false, error: `Patrón "${patron}" no existe.` });

  const sesionActual = () => silencioso(() => instancias.sesion.estado());

  if (accion === "estado") {
    return responderJSON(res, 200, {
      ok: true, consola: [], estado: silencioso(() => instancias[patron].estado()), sesion: sesionActual(),
    });
  }
  if (accion === "reiniciar") {
    const r = ejecutarCapturando(() => {
      instancias[patron] = fabricas[patron]();
      console.log(`[Panel] Escenario de ${patron} reiniciado.`);
    });
    return responderJSON(res, 200, { ...r, estado: silencioso(() => instancias[patron].estado()), sesion: sesionActual() });
  }

  const modulo = instancias[patron];
  if (req.method !== "POST" || typeof modulo.acciones[accion] !== "function") {
    return responderJSON(res, 404, { ok: false, error: `Acción "${accion}" no disponible.` });
  }
  const datos = await leerCuerpo(req);
  const r = ejecutarCapturando(() => modulo.acciones[accion](datos));
  responderJSON(res, 200, { ...r, estado: silencioso(() => modulo.estado()), sesion: sesionActual() });
}

function servirArchivo(res, ruta) {
  const archivo = path.normalize(path.join(CARPETA_PANEL, ruta === "/" ? "panel.html" : ruta));
  if (!archivo.startsWith(CARPETA_PANEL)) {
    res.writeHead(403);
    return res.end("Acceso denegado");
  }
  fs.readFile(archivo, (error, contenido) => {
    if (error) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      return res.end("No encontrado");
    }
    res.writeHead(200, { "Content-Type": TIPOS[path.extname(archivo)] || "application/octet-stream" });
    res.end(contenido);
  });
}

const servidor = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const partes = url.pathname.split("/").filter(Boolean);
  if (partes[0] === "api" && partes.length === 3) {
    return atenderAPI(req, res, partes[1], partes[2]);
  }
  servirArchivo(res, url.pathname);
});

servidor.listen(PUERTO, () => {
  console.log("==============================================");
  console.log(" Panel gráfico - Sistema de Biblioteca Digital");
  console.log("==============================================");
  console.log(` Abre en el navegador: http://localhost:${PUERTO}`);
  console.log(" Para detener el servidor: Ctrl + C");
});
