"use strict";

// Adaptador web del patrón Flyweight (clases reales de src/prestamos).
// Muchos préstamos comparten el MISMO objeto LibroCompartido.

const FabricaLibrosCompartidos = require("../../src/prestamos/FabricaLibrosCompartidos");
const PrestamoActivo = require("../../src/prestamos/PrestamoActivo");

const LIBROS = {
  cien: { isbn: "978-0307474728", titulo: "Cien años de soledad", autor: "Gabriel García Márquez", editorial: "Vintage Español" },
  rayuela: { isbn: "978-8437604572", titulo: "Rayuela", autor: "Julio Cortázar", editorial: "Cátedra" },
  dune: { isbn: "978-0441172719", titulo: "Dune", autor: "Frank Herbert", editorial: "Ace" },
};

module.exports = function crearEscenarioFlyweight() {
  let fabrica = new FabricaLibrosCompartidos();
  let prestamos = [];
  let consecutivo = 0;
  let masivo = null;

  return {
    acciones: {
      prestar({ libro, usuario = "Usuario" }) {
        if (!LIBROS[libro]) throw new Error("Libro desconocido.");
        const compartido = fabrica.obtener(LIBROS[libro]);
        const p = new PrestamoActivo(usuario.trim() || "Usuario", compartido, `EJ-${String(++consecutivo).padStart(3, "0")}`, "2026-12-01");
        prestamos.unshift(p);
        console.log(p.resumen());
        const otros = prestamos.filter((x) => x !== p && x.libro.isbn === compartido.isbn);
        if (otros.length) console.log(`¿Comparte el objeto de libro con ${otros[0].codigoEjemplar}?`, otros[0].libro === p.libro);
        console.log("Objetos LibroCompartido creados:", fabrica.getTotalCompartidos());
        return p.resumen();
      },
      masivo({ total = 100000 }) {
        const n = Math.min(Math.max(Number(total) || 100000, 1), 200000);
        const f = new FabricaLibrosCompartidos();
        const catalogo = Object.values(LIBROS);
        const inicio = Date.now();
        let ultimo;
        for (let i = 0; i < n; i++) ultimo = new PrestamoActivo(`usuario-${i}`, f.obtener(catalogo[i % catalogo.length]), `EJ-${i}`, "2026-11-30");
        masivo = { prestamos: n, compartidos: f.getTotalCompartidos(), ahorro: (1 - f.getTotalCompartidos() / n) * 100, ms: Date.now() - inicio };
        console.log("Préstamos creados:", n);
        console.log("Objetos LibroCompartido con Flyweight:", f.getTotalCompartidos());
        console.log("Objetos de libro SIN Flyweight (una copia por préstamo):", n);
        console.log("Ahorro de objetos de libro:", masivo.ahorro.toFixed(3) + "%");
        return masivo;
      },
      modificarCompartido() {
        const p = prestamos[0];
        if (!p) throw new Error("Primero registra un préstamo.");
        p.libro.titulo = "Título alterado"; // el objeto está congelado: lanza error en modo estricto
        return true;
      },
    },
    estado() {
      return {
        prestamos: prestamos.slice(0, 8).map((p) => ({ codigo: p.codigoEjemplar, usuario: p.usuario, titulo: p.libro.titulo, isbn: p.libro.isbn })),
        totalPrestamos: prestamos.length,
        compartidos: [...fabrica.cache.values()].map((l) => ({ isbn: l.isbn, titulo: l.titulo, usos: prestamos.filter((p) => p.libro === l).length })),
        libros: Object.entries(LIBROS).map(([clave, l]) => ({ clave, titulo: l.titulo })),
        masivo,
      };
    },
  };
};
