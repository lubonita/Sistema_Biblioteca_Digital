"use strict";

// Adaptador web del patrón Decorator aplicado a reportes (src/reportes).
// El reporte base se envuelve con las capas que se marquen.

const ReportePrestamosBase = require("../../src/reportes/ReportePrestamosBase");
const EncabezadoInstitucional = require("../../src/reportes/EncabezadoInstitucional");
const NotasAlMargen = require("../../src/reportes/NotasAlMargen");
const PieConFirma = require("../../src/reportes/PieConFirma");
const MarcaAgua = require("../../src/reportes/MarcaAgua");
const SesionManager = require("../../src/auth/SesionManager");

const PRESTAMOS = [
  { libro: "Cien años de soledad", vencimiento: "2026-11-20" },
  { libro: "Rayuela", vencimiento: "2026-11-27" },
];

module.exports = function crearEscenarioDecoratorReporte() {
  let ultimo = null;

  return {
    acciones: {
      generar({ encabezado, notas = "", firmante = "", marca = "" }) {
        const u = SesionManager.getInstance().getUsuarioActual();
        let reporte = new ReportePrestamosBase(u ? u.nombre : "Usuario invitado", PRESTAMOS);
        const capas = ["ReportePrestamosBase"];
        if (encabezado) { reporte = new EncabezadoInstitucional(reporte); capas.push("EncabezadoInstitucional"); }
        const listaNotas = String(notas).split("\n").map((n) => n.trim()).filter(Boolean);
        if (listaNotas.length) {
          reporte = new NotasAlMargen(reporte);
          listaNotas.forEach((n) => reporte.agregarObservacion(n));
          capas.push("NotasAlMargen");
        }
        if (firmante.trim()) { reporte = new PieConFirma(reporte, firmante.trim()); capas.push("PieConFirma"); }
        if (marca.trim()) { reporte = new MarcaAgua(reporte, marca.trim()); capas.push("MarcaAgua"); }
        const contenido = reporte.generar();
        console.log(`[Reporte] getDescripcion(): ${reporte.getDescripcion()}`);
        console.log(contenido);
        ultimo = { contenido, descripcion: reporte.getDescripcion(), capas };
        return ultimo;
      },
    },
    estado() {
      return { ultimo };
    },
  };
};
