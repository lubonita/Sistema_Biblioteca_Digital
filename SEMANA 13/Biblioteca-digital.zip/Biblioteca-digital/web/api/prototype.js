"use strict";

// Adaptador web del patrón Prototype (clases reales de src/ejemplares).
// Se clonan ejemplares a partir de las plantillas registradas y se demuestra
// que cada clon tiene su propia lista de notas.

const EjemplarLibro = require("../../src/ejemplares/EjemplarLibro");
const RegistroPrototipos = require("../../src/ejemplares/RegistroPrototipos");

module.exports = function crearEscenarioPrototype() {
  const registro = new RegistroPrototipos();
  const plantillas = {
    estandar: new EjemplarLibro("(sin título aún)", "(sin autor aún)", "PLANTILLA-ESTANDAR", true, null,
      ["Ejemplar estándar, disponible para préstamo a domicilio"]),
    referencia: new EjemplarLibro("(sin título aún)", "(sin autor aún)", "PLANTILLA-REFERENCIA", false, null,
      ["Ejemplar de solo consulta en sala, no se presta a domicilio"]),
  };
  Object.entries(plantillas).forEach(([nombre, p]) => registro.registrar(nombre, p));

  const ejemplares = [];
  let consecutivo = 0;

  const ver = (e, origen) => ({
    resumen: e.getResumen(), codigo: e.codigoEjemplar, titulo: e.tituloLibro, autor: e.autorLibro,
    disponible: e.disponible, notas: [...e.notas], origen,
  });

  return {
    acciones: {
      clonar({ plantilla, titulo, autor }) {
        const clon = registro.obtenerClon(plantilla); // falla si la plantilla no existe
        clon.tituloLibro = titulo && titulo.trim() ? titulo.trim() : clon.tituloLibro;
        clon.autorLibro = autor && autor.trim() ? autor.trim() : clon.autorLibro;
        clon.codigoEjemplar = `BIB-${String(++consecutivo).padStart(3, "0")}`;
        ejemplares.unshift({ objeto: clon, origen: plantilla });
        console.log(`[Prototype] registro.obtenerClon("${plantilla}") ->`, clon.getResumen());
        console.log("¿El clon es el mismo objeto que la plantilla?", clon === plantillas[plantilla]);
        return ver(clon, plantilla);
      },
      agregarNota({ codigo, nota }) {
        const item = ejemplares.find((x) => x.objeto.codigoEjemplar === codigo);
        if (!item) throw new Error(`No existe el ejemplar ${codigo}.`);
        if (!nota || !nota.trim()) throw new Error("La nota está vacía.");
        item.objeto.notas.push(nota.trim());
        console.log(`[Prototype] Nota agregada a ${codigo}.`);
        console.log(`Notas de ${codigo}:`, JSON.stringify(item.objeto.notas));
        console.log(`Notas de la plantilla "${item.origen}" (no cambian):`, JSON.stringify(plantillas[item.origen].notas));
        return true;
      },
      clonarInexistente() {
        return registro.obtenerClon("premium-inexistente"); // debe fallar
      },
    },
    estado() {
      return {
        plantillas: Object.entries(plantillas).map(([nombre, p]) => ({ nombre, ...ver(p, null) })),
        ejemplares: ejemplares.slice(0, 6).map((x) => ver(x.objeto, x.origen)),
      };
    },
  };
};
