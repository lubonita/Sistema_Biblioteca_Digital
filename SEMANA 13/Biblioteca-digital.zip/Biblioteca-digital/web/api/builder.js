"use strict";

// Adaptador web del patrón Builder (clases reales de src/libros/FichaLibro).
// Construcción manual (encadenando solo los métodos de los campos llenados)
// o con el Director (ficha básica o completa).

const FichaLibroBuilder = require("../../src/libros/FichaLibro/FichaLibroBuilder");
const CatalogadorDirector = require("../../src/libros/FichaLibro/CatalogadorDirector");

// campo del formulario -> método del builder
const METODOS = [
  ["titulo", "setTitulo"],
  ["autor", "setAutor"],
  ["anioPublicacion", "setAnioPublicacion"],
  ["categorias", "setCategorias"],
  ["idioma", "setIdioma"],
  ["editorial", "setEditorial"],
  ["isbn", "setISBN"],
  ["sinopsis", "setSinopsis"],
];

const limpiar = (campo, valor) => {
  if (campo === "anioPublicacion") return Number(valor);
  if (campo === "categorias") return String(valor).split(",").map((c) => c.trim()).filter(Boolean);
  return String(valor).trim();
};

const describir = (ficha) => ({
  resumen: ficha.getResumen(),
  campos: {
    titulo: ficha.titulo, autor: ficha.autor, anioPublicacion: ficha.anioPublicacion,
    categorias: ficha.categorias, idioma: ficha.idioma, editorial: ficha.editorial,
    isbn: ficha.isbn, sinopsis: ficha.sinopsis, disponible: ficha.disponible,
  },
});

module.exports = function crearEscenarioBuilder() {
  const fichas = [];
  const director = new CatalogadorDirector();

  return {
    acciones: {
      construirManual(datos) {
        const builder = new FichaLibroBuilder();
        const cadena = ["new FichaLibroBuilder()"];
        for (const [campo, metodo] of METODOS) {
          const valor = datos[campo];
          if (valor === undefined || valor === null || String(valor).trim() === "") continue;
          builder[metodo](limpiar(campo, valor));
          cadena.push(`.${metodo}(${JSON.stringify(limpiar(campo, valor))})`);
        }
        cadena.push(".build()");
        console.log("[Builder] " + cadena.join(""));
        const ficha = builder.build(); // falla si no hay título y autor
        const item = { origen: "Manual (encadenado)", cadena: cadena.join("\n  "), ...describir(ficha) };
        fichas.unshift(item);
        console.log("Ficha construida:", ficha.getResumen());
        return item;
      },
      construirConDirector({ tipo, titulo, autor }) {
        const builder = new FichaLibroBuilder();
        let ficha;
        if (tipo === "basica") {
          ficha = director.construirFichaBasica(builder, { titulo, autor });
        } else {
          ficha = director.construirFichaCompleta(builder, {
            titulo, autor,
            anioPublicacion: 1967,
            categorias: ["Novela", "Realismo mágico"],
            idioma: "Español",
            editorial: "Sudamericana",
            isbn: "978-0307474728",
            sinopsis: "La historia de la familia Buendía a lo largo de siete generaciones.",
          });
        }
        const item = { origen: `Director · ${tipo === "basica" ? "construirFichaBasica" : "construirFichaCompleta"}`, ...describir(ficha) };
        fichas.unshift(item);
        console.log(`[Director] ${item.origen}():`, ficha.getResumen());
        return item;
      },
    },
    estado() {
      return { fichas: fichas.slice(0, 5) };
    },
  };
};
