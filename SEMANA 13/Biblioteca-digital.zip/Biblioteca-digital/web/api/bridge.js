"use strict";

// Adaptador web del patrón Bridge (clases reales de src/notificaciones).
// Dos jerarquías independientes: el TIPO de aviso y el CANAL de envío.
// Cualquier aviso funciona con cualquier canal.

const AvisoPrestamoVencido = require("../../src/notificaciones/AvisoPrestamoVencido");
const AvisoReservaDisponible = require("../../src/notificaciones/AvisoReservaDisponible");
const CanalEnvioEmail = require("../../src/notificaciones/CanalEnvioEmail");
const CanalEnvioSMS = require("../../src/notificaciones/CanalEnvioSMS");
const CanalEnvioPush = require("../../src/notificaciones/CanalEnvioPush");

const AVISOS = { vencido: AvisoPrestamoVencido, reserva: AvisoReservaDisponible };
const CANALES = { email: CanalEnvioEmail, sms: CanalEnvioSMS, push: CanalEnvioPush };
const CONTACTOS = { email: "julio@correo.com", sms: "+57 300 123 4567", push: "app-julio" };

module.exports = function crearEscenarioBridge() {
  const enviados = [];
  const avisoReutilizado = new AvisoPrestamoVencido(new CanalEnvioEmail());

  const usuario = (canal, libro) => ({
    nombre: "Julio Cortázar Jr.", contacto: CONTACTOS[canal], libro: libro || "Rayuela", fechaVencimiento: "2026-11-20",
  });

  return {
    acciones: {
      enviar({ aviso, canal, libro }) {
        if (!AVISOS[aviso]) throw new Error("Tipo de aviso desconocido.");
        if (!CANALES[canal]) throw new Error("Canal desconocido.");
        const instancia = new AVISOS[aviso](new CANALES[canal]());
        const resultado = instancia.notificar(usuario(canal, libro));
        enviados.unshift({ aviso: instancia.constructor.name, canal: instancia.canal.constructor.name, resultado });
        return resultado;
      },
      cambiarCanal({ canal, libro }) {
        if (!CANALES[canal]) throw new Error("Canal desconocido.");
        avisoReutilizado.cambiarCanal(new CANALES[canal]());
        console.log(`[Bridge] Mismo objeto AvisoPrestamoVencido, ahora con ${avisoReutilizado.canal.constructor.name}.`);
        const resultado = avisoReutilizado.notificar(usuario(canal, libro));
        enviados.unshift({ aviso: "AvisoPrestamoVencido (reutilizado)", canal: avisoReutilizado.canal.constructor.name, resultado });
        return resultado;
      },
    },
    estado() {
      const combinaciones = new Set(enviados.map((e) => e.aviso.split(" ")[0] + "|" + e.canal));
      return {
        enviados: enviados.slice(0, 6),
        combinacionesUsadas: [...combinaciones],
        canalActualReutilizado: avisoReutilizado.canal.constructor.name,
      };
    },
  };
};
