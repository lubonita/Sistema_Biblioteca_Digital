"use strict";

// Adaptador web del patrón Iterator. Usa las clases REALES de src/catalogo.
// El iterador "paso a paso" se guarda entre clics: como es perezoso, avanza
// solo cuando el usuario pide siguiente(), igual que en la consola.

const LibroCatalogado = require("../../src/catalogo/LibroCatalogado");
const Categoria = require("../../src/catalogo/Categoria");
const IteradorCatalogo = require("../../src/catalogo/iterador/IteradorCatalogo");
const RecorridoCatalogo = require("../../src/catalogo/iterador/RecorridoCatalogo");
const RecorridoLista = require("../../src/catalogo/iterador/RecorridoLista");
const GeneradorRecomendaciones = require("../../src/catalogo/iterador/GeneradorRecomendaciones");

module.exports = function crearEscenarioIterator() {
  // Mismo catálogo de main_iterator.js, armado con el Composite
  const novela = new Categoria("Novela");
  novela.agregar(new LibroCatalogado("Cien años de soledad", 4.8));
  novela.agregar(new LibroCatalogado("Rayuela", 4.5));
  const cienciaFiccion = new Categoria("Ciencia Ficción");
  cienciaFiccion.agregar(new LibroCatalogado("Dune", 4.7));
  cienciaFiccion.agregar(new LibroCatalogado("Fundación", 4.6));
  const literatura = new Categoria("Literatura");
  literatura.agregar(novela);
  literatura.agregar(cienciaFiccion);
  literatura.agregar(new LibroCatalogado("Veinte poemas de amor", 4.3));

  const categorias = { Literatura: literatura, Novela: novela, "Ciencia Ficción": cienciaFiccion };
  const catalogo = new RecorridoCatalogo(literatura);
  const novedades = new RecorridoLista("Novedades del mes", [
    new LibroCatalogado("El nombre del viento", 4.9),
    new LibroCatalogado("La sombra del viento", 4.4),
    new LibroCatalogado("Proyecto Hail Mary", 4.7),
  ]);
  const generador = new GeneradorRecomendaciones();

  let iteradorActual = null;
  let pasoActual = null;

  const colecciones = { catalogo, novedades };
  const titulos = (libros) => libros.map((l) => ({ titulo: l.titulo, calificacion: l.calificacion }));

  return {
    acciones: {
      crearIterador() {
        iteradorActual = catalogo.crearIterador();
        pasoActual = null;
        console.log("[Panel] catalogo.crearIterador() -> nuevo IteradorCatalogo en la posición inicial.");
        return true;
      },

      siguiente() {
        if (!iteradorActual) this.crearIterador();
        if (!iteradorActual.haySiguiente()) {
          console.log("[Panel] haySiguiente() = false: el recorrido terminó.");
          pasoActual = { fin: true, nodosVisitados: iteradorActual.nodosVisitados };
          return pasoActual;
        }
        const libro = iteradorActual.siguiente();
        pasoActual = {
          titulo: libro.titulo,
          calificacion: libro.calificacion,
          ruta: iteradorActual.getRutaActual(),
          nodosVisitados: iteradorActual.nodosVisitados,
        };
        console.log(`[Iterador] siguiente() -> ${libro.titulo} (${libro.calificacion.toFixed(1)})  [${pasoActual.ruta}]`);
        return pasoActual;
      },

      recorrerTodo({ coleccion = "catalogo" }) {
        const origen = colecciones[coleccion];
        if (!origen) throw new Error("Colección desconocida.");
        const libros = [];
        for (const libro of origen) libros.push(libro); // for...of gracias a Symbol.iterator
        libros.forEach((l) => console.log(`- ${l.titulo}`));
        return titulos(libros);
      },

      recorrerFiltrado({ coleccion = "catalogo", minimo = 4.6 }) {
        const origen = colecciones[coleccion];
        if (!origen) throw new Error("Colección desconocida.");
        const min = Number(minimo);
        const it = origen.crearIteradorFiltrado((libro) => libro.calificacion >= min);
        const libros = [];
        while (it.haySiguiente()) libros.push(it.siguiente());
        console.log(`[Panel] IteradorFiltrado (calificación >= ${min}): ${libros.length} libro(s).`);
        libros.forEach((l) => console.log(`- ${l.titulo} (${l.calificacion.toFixed(1)})`));
        return titulos(libros);
      },

      recomendar({ coleccion = "catalogo", minimo = 4.6, cantidad = 2 }) {
        const origen = colecciones[coleccion];
        if (!origen) throw new Error("Colección desconocida.");
        return titulos(generador.recomendar(origen, Number(minimo), Number(cantidad)));
      },

      agregarLibro({ categoria, titulo, calificacion }) {
        const destino = categorias[categoria];
        if (!destino) throw new Error("Categoría desconocida.");
        const nota = Number(calificacion);
        if (!titulo || !titulo.trim()) throw new Error("El libro necesita un título.");
        if (Number.isNaN(nota) || nota < 0 || nota > 5) throw new Error("La calificación debe estar entre 0 y 5.");
        destino.agregar(new LibroCatalogado(titulo.trim(), nota));
        console.log(`[Composite] Libro "${titulo.trim()}" agregado a la categoría "${categoria}".`);
        return true;
      },

      escalabilidad() {
        const inicio = Date.now();
        const grande = new Categoria("Catálogo general");
        for (let c = 0; c < 100; c++) {
          const cat = new Categoria(`Categoría ${c + 1}`);
          for (let l = 0; l < 1000; l++) {
            cat.agregar(new LibroCatalogado(`Libro ${c + 1}-${l + 1}`, 3 + ((c + l) % 21) / 10));
          }
          grande.agregar(cat);
        }
        const total = grande.getTotalLibros();
        const it = new IteradorCatalogo(grande);
        const encontrados = [];
        while (it.haySiguiente() && encontrados.length < 5) {
          const libro = it.siguiente();
          if (libro.calificacion >= 4.9) encontrados.push(libro.titulo);
        }
        const resultado = {
          totalLibros: total,
          totalNodos: total + 101,
          visitados: it.nodosVisitados,
          encontrados,
          milisegundos: Date.now() - inicio,
        };
        console.log("Libros en el catálogo:", total);
        console.log("Primeros 5 libros con calificación >= 4.9:", encontrados.join(", "));
        console.log("Nodos visitados para encontrarlos:", it.nodosVisitados, "de", resultado.totalNodos, "nodos del árbol");
        return resultado;
      },
    },

    // Solo para DIBUJAR el árbol en pantalla (vista del Composite).
    estado() {
      const dibujar = (elemento) =>
        elemento instanceof Categoria
          ? { tipo: "categoria", nombre: elemento.nombre, hijos: elemento.elementos.map(dibujar) }
          : { tipo: "libro", titulo: elemento.titulo, calificacion: elemento.calificacion };
      const listaNovedades = [];
      for (const libro of novedades) listaNovedades.push({ titulo: libro.titulo, calificacion: libro.calificacion });
      return {
        arbol: dibujar(literatura),
        novedades: listaNovedades,
        categorias: Object.keys(categorias),
        paso: pasoActual,
        iteradorActivo: iteradorActual !== null,
      };
    },
  };
};
