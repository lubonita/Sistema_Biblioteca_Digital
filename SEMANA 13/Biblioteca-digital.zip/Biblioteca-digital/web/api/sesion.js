"use strict";

// Adaptador web del Singleton SesionManager (clase real de src/auth).
// La sesión es la MISMA instancia para todas las pestañas del panel,
// igual que en el sistema: así el Memento y el Iterator ven al mismo usuario.

const SesionManager = require("../../src/auth/SesionManager");

module.exports = function crearSesion() {
  return {
    acciones: {
      login({ usuario, password }) {
        const ok = SesionManager.getInstance().login(usuario, password);
        if (!ok) throw new Error("Usuario o contraseña incorrectos.");
        return true;
      },
      logout() {
        SesionManager.getInstance().logout();
        return true;
      },
    },
    estado() {
      const usuario = SesionManager.getInstance().getUsuarioActual();
      return usuario ? { nombre: usuario.nombre, rol: usuario.rol, usuario: usuario.usuario } : null;
    },
  };
};
