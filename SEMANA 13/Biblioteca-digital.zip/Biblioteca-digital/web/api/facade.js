"use strict";

// Adaptador web del patrón Facade (src/portal/PortalUsuarioFacade).
// Cada botón es UNA llamada a la fachada; ella coordina los subsistemas.

const PortalUsuarioFacade = require("../../src/portal/PortalUsuarioFacade");
const LibroCatalogado = require("../../src/catalogo/LibroCatalogado");
const Categoria = require("../../src/catalogo/Categoria");

// Qué patrones coordina cada operación (según el código de la fachada)
const SUBSISTEMAS = {
  consultarCalificacionCatalogo: ["Composite"],
  suscribirse: ["Singleton", "Decorator (costos)", "Adapter (Stripe)"],
  generarReporteOficial: ["Singleton", "Decorator (reportes)"],
  notificarPrestamoVencido: ["Bridge"],
};

module.exports = function crearEscenarioFacade() {
  const novela = new Categoria("Novela");
  novela.agregar(new LibroCatalogado("Cien años de soledad", 4.8));
  novela.agregar(new LibroCatalogado("Rayuela", 4.5));
  const cf = new Categoria("Ciencia Ficción");
  cf.agregar(new LibroCatalogado("Dune", 4.7));
  const raiz = new Categoria("Catálogo");
  raiz.agregar(novela);
  raiz.agregar(cf);

  const portal = new PortalUsuarioFacade(raiz);
  let ultimo = null;

  const registrar = (operacion, resultado) => {
    ultimo = { operacion, subsistemas: SUBSISTEMAS[operacion], resultado };
    return resultado;
  };

  return {
    acciones: {
      consultarCalificacionCatalogo() {
        const r = portal.consultarCalificacionCatalogo();
        console.log("[Portal] consultarCalificacionCatalogo() ->", JSON.stringify(r));
        return registrar("consultarCalificacionCatalogo", r);
      },
      suscribirse({ costoBase = 29900, pagoAnual, estudiante, dispositivosExtra = 0 }) {
        const r = portal.suscribirse({ costoBase: Number(costoBase), pagoAnual: !!pagoAnual, estudiante: !!estudiante, dispositivosExtra: Number(dispositivosExtra) || 0 });
        console.log("[Portal] suscribirse() ->", r.exito ? `total $${r.total.toFixed(2)}, transacción ${r.idTransaccion}` : r.mensaje);
        return registrar("suscribirse", r);
      },
      generarReporteOficial({ firmante = "Coordinación de Biblioteca" }) {
        const r = portal.generarReporteOficial(
          [{ libro: "Dune", vencimiento: "2026-11-30" }, { libro: "Rayuela", vencimiento: "2026-12-05" }],
          firmante
        );
        console.log("[Portal] generarReporteOficial() ->", r.exito ? "reporte generado" : r.mensaje);
        return registrar("generarReporteOficial", r);
      },
      notificarPrestamoVencido({ canal = "email" }) {
        const r = portal.notificarPrestamoVencido(
          { contacto: canal === "sms" ? "+57 300 123 4567" : canal === "push" ? "app-lector" : "lector@correo.com", libro: "Dune", fechaVencimiento: "2026-11-01" },
          canal
        );
        return registrar("notificarPrestamoVencido", { exito: true, mensaje: r });
      },
    },
    estado() {
      return { ultimo };
    },
  };
};
