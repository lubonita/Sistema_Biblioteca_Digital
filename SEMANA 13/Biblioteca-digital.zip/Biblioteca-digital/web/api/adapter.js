"use strict";

// Adaptador web del patrón Adapter (clases reales de src/pagos).
// El sistema pide procesarPago(pesos, concepto); StripeAdapter lo traduce a la
// interfaz de Stripe (centavos + metadata) y traduce la respuesta de vuelta.

const PasarelaPago = require("../../src/pagos/PasarelaPago");
const StripeAPI = require("../../src/pagos/StripeAPI");
const StripeAdapter = require("../../src/pagos/StripeAdapter");

module.exports = function crearEscenarioAdapter() {
  const pasarela = new StripeAdapter(new StripeAPI());
  const pagos = [];

  return {
    acciones: {
      pagar({ monto, concepto }) {
        const valor = Number(monto);
        if (!Number.isFinite(valor) || valor <= 0) throw new Error("El monto debe ser un número mayor que cero.");
        const resultado = pasarela.procesarPago(valor, concepto || "Suscripción biblioteca digital");
        const item = { ...resultado, centavos: Math.round(valor * 100), esPasarela: pasarela instanceof PasarelaPago };
        pagos.unshift(item);
        console.log("[Sistema] Respuesta traducida por el adaptador:", JSON.stringify(resultado));
        return item;
      },
      usarStripeDirecto() {
        // El sistema solo conoce procesarPago(); StripeAPI no lo tiene.
        const stripe = new StripeAPI();
        if (typeof stripe.procesarPago !== "function") {
          throw new Error("StripeAPI no tiene procesarPago(): su interfaz es createCharge(centavos, moneda, metadata). Por eso se necesita el adaptador.");
        }
        return true;
      },
    },
    estado() {
      return { pagos: pagos.slice(0, 5) };
    },
  };
};
