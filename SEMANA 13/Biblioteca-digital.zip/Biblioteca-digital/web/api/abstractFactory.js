"use strict";

// Adaptador web del patrón Abstract Factory (clases reales de src/servicios).
// Al elegir una familia, GestorServicios recibe una notificación y un reporte
// que SIEMPRE combinan entre sí (Email+PDF o SMS+Excel).

const ServicioBasicoFactory = require("../../src/servicios/ServicioBasicoFactory");
const ServicioPremiumFactory = require("../../src/servicios/ServicioPremiumFactory");
const GestorServicios = require("../../src/servicios/GestorServicios");

const FAMILIAS = {
  basica: () => new ServicioBasicoFactory(),
  premium: () => new ServicioPremiumFactory(),
};

module.exports = function crearEscenarioAbstractFactory() {
  const historial = [];

  return {
    acciones: {
      ejecutar({ familia, mensaje, datos }) {
        if (!FAMILIAS[familia]) throw new Error(`Familia "${familia}" no existe.`);
        const fabrica = FAMILIAS[familia]();
        const gestor = new GestorServicios(fabrica);
        const resultado = gestor.avisarYReportar(
          mensaje || "Tu préstamo vence mañana.",
          datos || "3 préstamos activos este mes"
        );
        const item = {
          familia,
          fabrica: fabrica.constructor.name,
          notificacion: gestor.notificacion.constructor.name,
          reporte: gestor.reporte.constructor.name,
          resultado,
        };
        historial.unshift(item);
        return item;
      },
    },
    estado() {
      return { historial: historial.slice(0, 5) };
    },
  };
};
