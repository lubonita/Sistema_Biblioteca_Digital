"use strict";

// Adaptador web del patrón Memento. Usa las clases REALES de src/edicion y
// la FichaLibro del Builder. Los permisos los decide la propia FichaEditable
// consultando el Singleton SesionManager (no se validan aquí).

const FichaLibroBuilder = require("../../src/libros/FichaLibro/FichaLibroBuilder");
const CatalogadorDirector = require("../../src/libros/FichaLibro/CatalogadorDirector");
const FichaEditable = require("../../src/edicion/FichaEditable");
const HistorialFicha = require("../../src/edicion/HistorialFicha");

const LIMITE_WEB = 5;
const CAMPOS = ["titulo", "autor", "anioPublicacion", "categorias", "idioma", "editorial"];

module.exports = function crearEscenarioMemento() {
  const director = new CatalogadorDirector();
  const ficha = new FichaEditable(
    director.construirFichaCompleta(new FichaLibroBuilder(), {
      titulo: "Cien años de soledad",
      autor: "Gabriel García Márquez",
      anioPublicacion: 1967,
      categorias: ["Novela", "Realismo mágico"],
      idioma: "Español",
      editorial: "Sudamericana",
    })
  );
  const historial = new HistorialFicha(ficha, LIMITE_WEB);

  const convertir = (campo, valor) => {
    if (campo === "anioPublicacion") {
      const anio = Number(valor);
      if (!Number.isInteger(anio)) throw new Error("El año debe ser un número entero.");
      return anio;
    }
    if (campo === "categorias") return String(valor).split(",").map((c) => c.trim()).filter(Boolean);
    return String(valor);
  };

  return {
    acciones: {
      guardarYEditar({ campo, valor }) {
        historial.guardar(`Antes de cambiar "${campo}"`);
        ficha.editar(campo, convertir(campo, valor));
        return ficha.getResumen();
      },
      guardarVersion({ descripcion }) {
        historial.guardar(descripcion && descripcion.trim() ? descripcion.trim() : "Versión guardada");
        return true;
      },
      deshacer() {
        historial.deshacer();
        return ficha.getResumen();
      },
      inspeccionarMemento() {
        const memento = historial.verUltimo();
        if (!memento) throw new Error("No hay versiones guardadas para inspeccionar.");
        const resultado = {
          descripcion: memento.getDescripcion(),
          propiedadesPublicas: Object.keys(memento),
          estadoDirecto: memento.estado === undefined ? "undefined" : "visible",
        };
        console.log("Descripción visible:", resultado.descripcion);
        console.log("Propiedades públicas del memento:", JSON.stringify(resultado.propiedadesPublicas));
        console.log("memento.estado ->", resultado.estadoDirecto);
        try {
          memento.obtenerEstado(Symbol("llaveFicha"));
        } catch (error) {
          resultado.intentoLectura = error.message;
          console.log("Intento de leer con otra llave:", error.message);
        }
        return resultado;
      },
    },
    estado() {
      const campos = {};
      CAMPOS.forEach((c) => (campos[c] = ficha.obtener(c)));
      return {
        campos,
        resumen: ficha.getResumen(),
        versiones: historial.listar(),
        cantidad: historial.getCantidad(),
        limite: LIMITE_WEB,
        puedeDeshacer: historial.puedeDeshacer(),
      };
    },
  };
};
