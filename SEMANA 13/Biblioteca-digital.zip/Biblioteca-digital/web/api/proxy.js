"use strict";

// Adaptador web del patrón Proxy (clases reales de src/certificados).
// Cadena: Protección(Caché(Virtual(real))). El cliente solo usa "emisor".

const CertificadoPazYSalvo = require("../../src/certificados/CertificadoPazYSalvo");
const CertificadoProxyProteccion = require("../../src/certificados/CertificadoProxyProteccion");
const CertificadoProxyCache = require("../../src/certificados/CertificadoProxyCache");
const CertificadoProxyVirtual = require("../../src/certificados/CertificadoProxyVirtual");

module.exports = function crearEscenarioProxy() {
  const instanciasPrevias = CertificadoPazYSalvo.instancias; // el contador es estático
  const virtual = new CertificadoProxyVirtual(() => new CertificadoPazYSalvo());
  const cache = new CertificadoProxyCache(virtual);
  const emisor = new CertificadoProxyProteccion(cache);
  const certificados = [];

  return {
    acciones: {
      emitir({ idUsuario }) {
        const id = (idUsuario || "").trim();
        if (!id) throw new Error("Indica el código del estudiante.");
        const aciertosAntes = cache.aciertos;
        const cert = emisor.emitir(id);
        const desdeCache = cache.aciertos > aciertosAntes;
        certificados.unshift({ ...cert, desdeCache });
        console.log(`Certificado ${cert.numero} para ${id}${desdeCache ? " (desde caché, mismo objeto)" : ""}`);
        return { ...cert, desdeCache };
      },
    },
    estado() {
      return {
        realCreado: virtual.estaCreado(),
        instanciasReales: CertificadoPazYSalvo.instancias - instanciasPrevias,
        emisionesReales: virtual.real ? virtual.real.emisiones : 0,
        aciertosCache: cache.aciertos,
        denegados: emisor.intentosDenegados,
        enCache: [...cache.cache.keys()],
        certificados: certificados.slice(0, 6),
      };
    },
  };
};
