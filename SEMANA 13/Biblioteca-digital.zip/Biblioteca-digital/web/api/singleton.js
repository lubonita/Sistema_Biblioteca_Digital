"use strict";

// Adaptador web del patrón Singleton (clase real src/auth/SesionManager).
// Dos "módulos" del sistema piden la instancia por separado; el panel compara
// si recibieron exactamente el mismo objeto (===).

const SesionManager = require("../../src/auth/SesionManager");

// Identificador visual para cada objeto distinto que se reciba
const ids = new WeakMap();
let contador = 0;
const huella = (obj) => {
  if (!ids.has(obj)) ids.set(obj, `SesionManager@${String(++contador).padStart(3, "0")}`);
  return ids.get(obj);
};

module.exports = function crearEscenarioSingleton() {
  const referencias = { A: null, B: null };

  return {
    acciones: {
      pedirInstancia({ modulo }) {
        if (!["A", "B"].includes(modulo)) throw new Error("Módulo desconocido.");
        referencias[modulo] = SesionManager.getInstance();
        console.log(`[Panel] Módulo ${modulo} recibió: ${huella(referencias[modulo])}`);
        if (referencias.A && referencias.B) {
          console.log("¿Módulo A y Módulo B tienen la misma instancia?", referencias.A === referencias.B);
        }
        return huella(referencias[modulo]);
      },
      intentarNew() {
        new SesionManager(); // debe fallar: ya existe la instancia
        return "Se creó otra instancia (esto no debería pasar)";
      },
    },
    estado() {
      const s = SesionManager.getInstance();
      const u = s.getUsuarioActual();
      return {
        A: referencias.A ? huella(referencias.A) : null,
        B: referencias.B ? huella(referencias.B) : null,
        misma: referencias.A && referencias.B ? referencias.A === referencias.B : null,
        usuario: u ? `${u.nombre} (${u.rol})` : null,
        desde: s.fechaInicioSesion ? new Date(s.fechaInicioSesion).toLocaleTimeString("es-CO") : null,
        registrados: s.usuariosRegistrados.map((x) => `${x.usuario} · ${x.rol}`),
      };
    },
  };
};
