"use strict";

// Adaptador web del patrón Decorator aplicado a costos (src/suscripciones).
// Cada opción marcada ENVUELVE al cálculo anterior; el orden importa.

const SuscripcionBase = require("../../src/suscripciones/SuscripcionBase");
const DescuentoPagoAnual = require("../../src/suscripciones/DescuentoPagoAnual");
const DescuentoEstudiante = require("../../src/suscripciones/DescuentoEstudiante");
const RecargoDispositivosExtra = require("../../src/suscripciones/RecargoDispositivosExtra");
const SuscripcionDecorator = require("../../src/suscripciones/SuscripcionDecorator");

module.exports = function crearEscenarioDecoratorSuscripcion() {
  let ultimo = null;

  return {
    acciones: {
      calcular({ costoBase = 29900, capas = [], dispositivos = 1 }) {
        const base = Number(costoBase);
        if (!Number.isFinite(base) || base <= 0) throw new Error("El costo base debe ser mayor que cero.");
        let calculo = new SuscripcionBase(base);
        const envolturas = ["new SuscripcionBase(" + base + ")"];
        for (const capa of capas) {
          if (capa === "anual") calculo = new DescuentoPagoAnual(calculo);
          else if (capa === "estudiante") calculo = new DescuentoEstudiante(calculo);
          else if (capa === "dispositivos") calculo = new RecargoDispositivosExtra(calculo, Number(dispositivos) || 1);
          else throw new Error(`Capa desconocida: ${capa}`);
          envolturas.push(calculo.constructor.name);
        }
        const total = calculo.calcular();
        console.log(calculo.detalle());
        console.log(`  TOTAL: $${total.toFixed(2)}`);
        // Expresión en el orden real de envoltura (la última capa queda afuera)
        const expresion = envolturas.slice(1).reduce(
          (acc, c) => `new ${c}(${acc}${c === "RecargoDispositivosExtra" ? ", " + (Number(dispositivos) || 1) : ""})`,
          envolturas[0]
        );
        ultimo = { total, detalle: calculo.detalle().split("\n"), capas: envolturas, expresion };
        return ultimo;
      },
      instanciarDecoratorBase() {
        new SuscripcionDecorator(new SuscripcionBase(29900)); // debe fallar
        return true;
      },
    },
    estado() {
      return { ultimo };
    },
  };
};
