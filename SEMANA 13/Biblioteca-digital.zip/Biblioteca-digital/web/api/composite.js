"use strict";

// Adaptador web del patrón Composite (clases reales de src/catalogo).
// Libros (hojas) y categorías (ramas) responden a los mismos métodos.

const ElementoCatalogo = require("../../src/catalogo/ElementoCatalogo");
const LibroCatalogado = require("../../src/catalogo/LibroCatalogado");
const Categoria = require("../../src/catalogo/Categoria");

module.exports = function crearEscenarioComposite() {
  const novela = new Categoria("Novela");
  novela.agregar(new LibroCatalogado("Cien años de soledad", 4.8));
  novela.agregar(new LibroCatalogado("Rayuela", 4.5));
  const cf = new Categoria("Ciencia Ficción");
  cf.agregar(new LibroCatalogado("Dune", 4.7));
  cf.agregar(new LibroCatalogado("Fundación", 4.6));
  const literatura = new Categoria("Literatura");
  literatura.agregar(novela);
  literatura.agregar(cf);
  literatura.agregar(new LibroCatalogado("Veinte poemas de amor", 4.3));

  const categorias = new Map([["Literatura", literatura], ["Novela", novela], ["Ciencia Ficción", cf]]);

  return {
    acciones: {
      agregarLibro({ categoria, titulo, calificacion }) {
        const destino = categorias.get(categoria);
        if (!destino) throw new Error("Categoría desconocida.");
        const nota = Number(calificacion);
        if (!titulo || !titulo.trim()) throw new Error("El libro necesita un título.");
        if (Number.isNaN(nota) || nota < 0 || nota > 5) throw new Error("La calificación debe estar entre 0 y 5.");
        destino.agregar(new LibroCatalogado(titulo.trim(), nota));
        console.log(`[Composite] ${categoria}.agregar(new LibroCatalogado("${titulo.trim()}", ${nota}))`);
        return true;
      },
      agregarCategoria({ padre, nombre }) {
        const destino = categorias.get(padre);
        if (!destino) throw new Error("Categoría padre desconocida.");
        if (!nombre || !nombre.trim()) throw new Error("La categoría necesita un nombre.");
        if (categorias.has(nombre.trim())) throw new Error("Ya existe una categoría con ese nombre.");
        const nueva = new Categoria(nombre.trim());
        destino.agregar(nueva);
        categorias.set(nueva.nombre, nueva);
        console.log(`[Composite] ${padre}.agregar(new Categoria("${nueva.nombre}"))`);
        return true;
      },
      mostrar({ categoria = "Literatura" }) {
        const c = categorias.get(categoria);
        if (!c) throw new Error("Categoría desconocida.");
        c.mostrar();
        console.log(`Promedio: ${c.getCalificacionPromedio().toFixed(2)} | Total de libros: ${c.getTotalLibros()}`);
        return true;
      },
      usarComponente() {
        new ElementoCatalogo().getCalificacionPromedio(); // debe fallar
        return true;
      },
    },
    estado() {
      const dibujar = (e) => e instanceof Categoria
        ? { tipo: "categoria", nombre: e.nombre, promedio: e.getCalificacionPromedio(), total: e.getTotalLibros(), hijos: e.elementos.map(dibujar) }
        : { tipo: "libro", titulo: e.titulo, promedio: e.getCalificacionPromedio(), total: e.getTotalLibros() };
      return { arbol: dibujar(literatura), categorias: [...categorias.keys()] };
    },
  };
};
