"use strict";

// Adaptador web del patrón Mediator. Usa las clases REALES de src/coordinacion.
// La cola de reservas es privada del módulo: la página solo muestra lo que el
// módulo expone (cantidadEnEspera). El "tenedor" de cada libro sale del
// PrestamoActivo que devolvió prestar().

const MediadorBiblioteca = require("../../src/coordinacion/MediadorBiblioteca");
const ModuloPrestamos = require("../../src/coordinacion/ModuloPrestamos");
const ModuloReservas = require("../../src/coordinacion/ModuloReservas");
const ModuloAvisos = require("../../src/coordinacion/ModuloAvisos");

const LIBROS = {
  dune: { isbn: "978-0441172719", titulo: "Dune", autor: "Frank Herbert", editorial: "Ace" },
  rayuela: { isbn: "978-8437604572", titulo: "Rayuela", autor: "Julio Cortázar", editorial: "Cátedra" },
  fundacion: { isbn: "978-0553293357", titulo: "Fundación", autor: "Isaac Asimov", editorial: "Bantam" },
  cien: { isbn: "978-0307474728", titulo: "Cien años de soledad", autor: "Gabriel García Márquez", editorial: "Vintage Español" },
};
const USUARIOS = {
  valentina: { nombre: "Valentina Millán", contacto: "vmillan@uts.edu.co", canal: "email" },
  luz: { nombre: "Luz Estela Zafra", contacto: "+57 300 123 4567", canal: "sms" },
  lector: { nombre: "Usuario Lector", contacto: "lector1-app", canal: "push" },
  fax: { nombre: "Usuario con fax", contacto: "fax-001", canal: "fax" },
};

module.exports = function crearEscenarioMediator() {
  const mediador = new MediadorBiblioteca();
  const prestamos = new ModuloPrestamos(mediador);
  const reservas = new ModuloReservas(mediador);
  const avisos = new ModuloAvisos(mediador);
  mediador.registrarModulos(prestamos, reservas, avisos);

  const tenedores = {}; // isbn -> clave de usuario (según el PrestamoActivo recibido)
  const devoluciones = []; // resultados que devolvió devolver()

  const libro = (clave) => {
    if (!LIBROS[clave]) throw new Error("Libro desconocido.");
    return LIBROS[clave];
  };
  const usuario = (clave) => {
    if (!USUARIOS[clave]) throw new Error("Usuario desconocido.");
    return USUARIOS[clave];
  };

  return {
    acciones: {
      prestar({ usuario: u, libro: l, vencimiento = "2026-12-15" }) {
        const prestamo = prestamos.prestar(usuario(u), libro(l), vencimiento);
        tenedores[libro(l).isbn] = u;
        return prestamo.resumen();
      },
      reservar({ usuario: u, libro: l }) {
        return reservas.reservar(libro(l).isbn, libro(l).titulo, usuario(u));
      },
      devolver({ libro: l, usuario: u }) {
        const datos = libro(l);
        const quien = u || tenedores[datos.isbn];
        if (!quien) throw new Error(`No hay un préstamo activo para el ISBN ${datos.isbn}.`);
        let resultado;
        try {
          resultado = prestamos.devolver(datos.isbn, usuario(quien)); // aquí entra el mediador
        } finally {
          // Aunque el aviso falle, el préstamo pudo cerrarse: se refleja lo que dice el módulo.
          if (!prestamos.estaPrestado(datos.isbn)) delete tenedores[datos.isbn];
        }
        const avisado = Object.values(USUARIOS).find((x) => x.nombre === resultado.avisadoA);
        devoluciones.unshift({ ...resultado, canal: avisado ? avisado.canal : null });
        return resultado;
      },
    },
    estado() {
      return {
        libros: Object.entries(LIBROS).map(([clave, d]) => ({
          clave,
          titulo: d.titulo,
          isbn: d.isbn,
          prestado: prestamos.estaPrestado(d.isbn),
          tenedor: tenedores[d.isbn] ? USUARIOS[tenedores[d.isbn]].nombre : null,
          enEspera: reservas.cantidadEnEspera(d.isbn),
        })),
        usuarios: Object.entries(USUARIOS).map(([clave, x]) => ({ clave, nombre: x.nombre, canal: x.canal })),
        avisosEnviados: avisos.getTotalEnviados(),
        devoluciones: devoluciones.slice(0, 6),
      };
    },
  };
};
