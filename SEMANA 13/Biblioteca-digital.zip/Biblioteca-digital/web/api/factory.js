"use strict";

// Adaptador web del patrón Factory Method (clases reales de src/libros).
// El panel elige el CREADOR concreto; el creador decide qué libro fabricar.

const CatalogoServicePDF = require("../../src/libros/CatalogoServicePDF");
const CatalogoServiceEPUB = require("../../src/libros/CatalogoServiceEPUB");
const CatalogoServiceMOBI = require("../../src/libros/CatalogoServiceMOBI");
const LibroDigital = require("../../src/libros/LibroDigital");

const CREADORES = {
  PDF: () => new CatalogoServicePDF(),
  EPUB: () => new CatalogoServiceEPUB(),
  MOBI: () => new CatalogoServiceMOBI(),
};

module.exports = function crearEscenarioFactory() {
  const estante = [];

  return {
    acciones: {
      registrar({ formato, titulo, autor }) {
        if (!CREADORES[formato]) throw new Error(`Formato "${formato}" no soportado.`);
        if (!titulo || !autor) throw new Error("El libro necesita título y autor.");
        const creador = CREADORES[formato]();
        const libro = creador.registrarYAbrir(titulo.trim(), autor.trim());
        const item = {
          titulo: libro.titulo,
          autor: libro.autor,
          producto: libro.constructor.name,
          creador: creador.constructor.name,
          esLibroDigital: libro instanceof LibroDigital,
        };
        estante.unshift(item);
        return item;
      },
      instanciarBase() {
        new LibroDigital("Libro genérico", "Autor"); // debe fallar
        return "Se creó un LibroDigital genérico (no debería pasar)";
      },
    },
    estado() {
      return { estante };
    },
  };
};
