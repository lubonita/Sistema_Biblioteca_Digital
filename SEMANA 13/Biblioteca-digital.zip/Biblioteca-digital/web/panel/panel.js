// =====================================================================
// Lógica de la PÁGINA (solo interfaz).
// Aquí no hay ninguna clase de patrón: cada acción se envía al servidor,
// que ejecuta las clases reales de src/ y devuelve resultado + consola.
// =====================================================================

// Orden del curso. "listo: false" = la pestaña aún no está construida.
const GRUPOS = [
  { id: "creacionales", nombre: "Creacionales" },
  { id: "estructurales", nombre: "Estructurales" },
  { id: "comportamiento", nombre: "Comportamiento" },
];
const PATRONES = [
  { id: "singleton", nombre: "Singleton", grupo: "creacionales" },
  { id: "factory", nombre: "Factory Method", grupo: "creacionales" },
  { id: "builder", nombre: "Builder", grupo: "creacionales" },
  { id: "abstractFactory", nombre: "Abstract Factory", grupo: "creacionales" },
  { id: "prototype", nombre: "Prototype", grupo: "creacionales" },
  { id: "adapter", nombre: "Adapter", grupo: "estructurales" },
  { id: "bridge", nombre: "Bridge", grupo: "estructurales" },
  { id: "decoratorSuscripcion", nombre: "Decorator · costos", grupo: "estructurales" },
  { id: "composite", nombre: "Composite", grupo: "estructurales" },
  { id: "decoratorReporte", nombre: "Decorator · reportes", grupo: "estructurales" },
  { id: "facade", nombre: "Facade", grupo: "estructurales" },
  { id: "flyweight", nombre: "Flyweight", grupo: "estructurales" },
  { id: "proxy", nombre: "Proxy", grupo: "estructurales" },
  { id: "iterator", nombre: "Iterator", grupo: "comportamiento" },
  { id: "memento", nombre: "Memento", grupo: "comportamiento" },
  { id: "mediator", nombre: "Mediator", grupo: "comportamiento" },
];
const disponibles = () => PATRONES.filter((p) => document.getElementById("panel-" + p.id));

const estado = {};

// ---------------------------------------------------------- utilidades
const $ = (id) => document.getElementById(id);
const esc = (t) => String(t ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function toast(texto, ok = false) {
  const t = $("toast");
  t.textContent = texto;
  t.classList.toggle("ok", ok);
  t.classList.add("ver");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => t.classList.remove("ver"), 3200);
}

function escribirConsola(patron, comando, respuesta) {
  const caja = $("consola-" + patron);
  if (!caja) return;
  const linea = (texto, clase) => `<div class="line ${clase}">${esc(texto)}</div>`;
  let html = linea("> " + comando, "cmd");
  (respuesta.consola || []).forEach((l) => {
    let clase = "";
    if (l.startsWith("[SesionManager]")) clase = "dim";
    else if (l.startsWith("[Mediador]")) clase = "med";
    else if (/^\[(Login|Edición|Historial|Préstamos|Reservas|Canal|Recomendaciones|Composite|Iterador)/.test(l)) clase = "ok";
    html += linea(l, clase);
  });
  if (!respuesta.ok) html += linea("Error: " + respuesta.error, "err");
  caja.insertAdjacentHTML("beforeend", html);
  caja.parentElement.scrollTop = caja.parentElement.scrollHeight;
}

async function api(patron, accion, datos = {}, comando) {
  let respuesta;
  try {
    const r = await fetch(`/api/${patron}/${accion}`, {
      method: accion === "estado" ? "GET" : "POST",
      headers: { "Content-Type": "application/json" },
      body: accion === "estado" ? undefined : JSON.stringify(datos),
    });
    respuesta = await r.json();
  } catch (e) {
    toast("No hay conexión con el servidor. ¿Está corriendo node web/servidor.js?");
    return null;
  }
  if (respuesta.sesion !== undefined) pintarSesion(respuesta.sesion);
  if (patron !== "sesion" && respuesta.estado) {
    estado[patron] = respuesta.estado;
    pintar[patron]();
  }
  if (comando) escribirConsola(patron === "sesion" ? pestañaActual() : patron, comando, respuesta);
  if (!respuesta.ok && comando) toast(respuesta.error);
  // Al cambiar la sesión, el monitor del Singleton muestra el nuevo estado compartido
  if (patron === "sesion" && accion !== "estado" && estado.singleton !== undefined) await api("singleton", "estado");
  return respuesta;
}

let tabActual = "singleton";
function pestañaActual() {
  return tabActual;
}

function pintarNavegacion() {
  const lista = disponibles();
  const grupoActual = (PATRONES.find((p) => p.id === tabActual) || {}).grupo;
  $("grupos").innerHTML = GRUPOS.map((g) => {
    const n = lista.filter((p) => p.grupo === g.id).length;
    return `<button class="grupo-btn ${g.id === grupoActual ? "active" : ""}" ${n ? "" : "disabled"}
      onclick="cambiarGrupo('${g.id}')">${g.nombre}<span class="cuenta">${n ? n : "pronto"}</span></button>`;
  }).join("");
  const numero = (p) => String(PATRONES.indexOf(p) + 1).padStart(2, "0");
  $("tabs").innerHTML = lista.filter((p) => p.grupo === grupoActual).map((p) =>
    `<button class="tab-btn ${p.id === tabActual ? "active" : ""}" data-tab="${p.id}" onclick="cambiarTab('${p.id}')">
      <span class="num">${numero(p)}</span> ${p.nombre}</button>`).join("");
}

function cambiarGrupo(grupo) {
  const primero = disponibles().find((p) => p.grupo === grupo);
  if (primero) cambiarTab(primero.id);
}

function cambiarTab(tab) {
  if (!document.getElementById("panel-" + tab)) return;
  tabActual = tab;
  document.querySelectorAll(".tab-panel").forEach((p) => p.classList.toggle("active", p.id === "panel-" + tab));
  pintarNavegacion();
  try { localStorage.setItem("panel-tab", tab); } catch (e) { /* sin almacenamiento */ }
}

async function reiniciar(patron) {
  await api(patron, "reiniciar", {}, `reiniciar escenario (${patron})`);
  if (patron === "memento") $("meInspeccion").innerHTML = "";
  if (patron === "iterator") { $("itResultados").innerHTML = '<div class="vacio">Los resultados aparecerán aquí.</div>'; $("itEscala").innerHTML = ""; }
  if (patron === "mediator") marcarFlujo([]);
}

// ---------------------------------------------------------- sesión (Singleton)
function pintarSesion(s) {
  $("sesionDot").classList.toggle("on", !!s);
  $("sesionTexto").textContent = s ? s.nombre : "Sin sesión";
  $("sesionRol").textContent = s ? s.rol : "";
}
async function iniciarSesion() {
  const [usuario, password] = $("sesionUsuario").value.split("|");
  await api("sesion", "login", { usuario, password }, `SesionManager.getInstance().login("${usuario}", "****")`);
}
async function cerrarSesion() {
  await api("sesion", "logout", {}, "SesionManager.getInstance().logout()");
}

// ---------------------------------------------------------- render por patrón
const pintar = {
  singleton() {
    const e = estado.singleton;
    if (!e) return;
    $("sgA").textContent = e.A || "—";
    $("sgB").textContent = e.B || "—";
    const banner = $("sgBanner");
    if (e.misma === null) banner.textContent = "Pide la instancia en ambos módulos para comparar";
    else banner.textContent = e.misma ? "moduloA === moduloB → true · es el MISMO objeto" : "moduloA === moduloB → false";
    $("sgEstado").innerHTML = `
      <dt>usuarioActual</dt><dd>${esc(e.usuario || "null (sin sesión)")}</dd>
      <dt>fechaInicioSesion</dt><dd>${esc(e.desde || "null")}</dd>
      <dt>usuariosRegistrados</dt><dd>${e.registrados.map(esc).join("<br>")}</dd>`;
  },

  factory() {
    const e = estado.factory;
    if (!e) return;
    $("fmEstante").innerHTML = e.estante.length
      ? e.estante.map((l) => `<div class="libro-item"><span class="badge">${esc(l.producto.replace("Libro", ""))}</span>
          <div class="info"><div class="titulo">${esc(l.titulo)}</div><div class="meta">${esc(l.autor)}</div>
          <div class="estante-item-sub">${esc(l.creador)} → new ${esc(l.producto)}()</div></div></div>`).join("")
      : '<div class="empty-estante">Aún no se ha registrado ningún libro.</div>';
  },

  builder() {
    const e = estado.builder;
    if (!e) return;
    $("bdFichas").innerHTML = e.fichas.length
      ? e.fichas.map((f) => `<div class="ficha-cons">
          <div class="cab"><b>${esc(f.campos.titulo)}</b><span class="pill">${esc(f.origen)}</span></div>
          ${f.cadena ? `<pre class="codigo">${esc(f.cadena)}</pre>` : ""}
          <div class="resumen">getResumen(): ${esc(f.resumen)}</div>
          <div class="campos-mini">${Object.entries(f.campos).map(([k, v]) => {
            const vacio = v === null || (Array.isArray(v) && !v.length);
            return `<span class="pill ${vacio ? "nulo" : "on"}">${esc(k)}${vacio ? ": null" : ""}</span>`;
          }).join("")}</div></div>`).join("")
      : '<div class="vacio">Aún no se ha construido ninguna ficha.</div>';
  },

  abstractFactory() {
    const e = estado.abstractFactory;
    if (!e) return;
    const ultimo = e.historial[0];
    if (ultimo) {
      $("afResultado").innerHTML = `
        <div class="productos">
          <div class="producto"><span class="etiqueta">crearNotificacion()</span><span class="clase">${esc(ultimo.notificacion)}</span></div>
          <div class="producto"><span class="etiqueta">crearReporte()</span><span class="clase">${esc(ultimo.reporte)}</span></div>
        </div>
        <div class="resumen">Fábrica: <code>${esc(ultimo.fabrica)}</code><br>Resultado: ${esc(ultimo.resultado)}</div>`;
    }
    $("afHistorial").innerHTML = e.historial.length
      ? e.historial.map((h) => `<div class="resultado"><span>${esc(h.fabrica)}</span><span class="pill">${esc(h.notificacion.replace("Notificacion", ""))} + ${esc(h.reporte.replace("Reporte", ""))}</span></div>`).join("")
      : '<div class="vacio">Sin ejecuciones todavía.</div>';
  },

  prototype() {
    const e = estado.prototype;
    if (!e) return;
    $("ptPlantillas").innerHTML = e.plantillas.map((p) => `<div class="plantilla">
        <div class="t">${esc(p.nombre)} <span class="tipo-coleccion">${esc(p.codigo)}</span></div>
        <ul class="notas">${p.notas.map((n) => `<li>${esc(n)}</li>`).join("")}</ul></div>`).join("");
    $("ptEjemplares").innerHTML = e.ejemplares.length
      ? e.ejemplares.map((c) => {
          const base = e.plantillas.find((p) => p.nombre === c.origen);
          const heredadas = base ? base.notas.length : 0;
          return `<div class="clon">
            <div class="cab" style="display:flex;justify-content:space-between;gap:8px"><b>${esc(c.codigo)} · ${esc(c.titulo)}</b><span class="pill">clon de ${esc(c.origen)}</span></div>
            <div class="mini-sub" style="margin:4px 0 0">${esc(c.resumen)}</div>
            <ul class="notas">${c.notas.map((n, i) => `<li class="${i >= heredadas ? "nueva" : ""}">${esc(n)}</li>`).join("")}</ul>
            <div class="fila-nota"><input id="nota-${esc(c.codigo)}" placeholder="Nueva nota para este clon" />
            <button class="btn-sec" onclick="ptNota('${esc(c.codigo)}')">Agregar nota</button></div></div>`;
        }).join("")
      : '<div class="vacio">Aún no hay clones. Clona una plantilla.</div>';
  },

  adapter() {
    const e = estado.adapter;
    if (!e || !e.pagos.length) return;
    const p = e.pagos[0];
    const fmt = (n) => Number(n).toLocaleString("es-CO");
    $("adTraduccion").innerHTML = `
      <div class="productos">
        <div class="producto"><span class="etiqueta">Entra (sistema)</span><span class="clase">procesarPago(${fmt(p.monto)}, "...")</span></div>
        <div class="producto"><span class="etiqueta">Sale (Stripe)</span><span class="clase">createCharge(${fmt(p.centavos)}, "COP", {...})</span></div>
      </div>
      <dl class="ficha-campos">
        <dt>exitoso</dt><dd>${p.exitoso}</dd>
        <dt>idTransaccion</dt><dd>${esc(p.idTransaccion)}</dd>
        <dt>usuario</dt><dd>${esc(p.usuario)}</dd>
        <dt>instanceof</dt><dd>StripeAdapter es PasarelaPago → ${p.esPasarela}</dd>
      </dl>
      <p class="mini-titulo">Pagos anteriores</p>
      ${e.pagos.map((x) => `<div class="resultado"><span>$${fmt(x.monto)} → ${fmt(x.centavos)} centavos</span><span class="pill">${esc(x.idTransaccion)}</span></div>`).join("")}`;
  },

  bridge() {
    const e = estado.bridge;
    if (!e) return;
    const usadas = new Set(e.combinacionesUsadas);
    const avisos = [["vencido", "AvisoPrestamoVencido"], ["reserva", "AvisoReservaDisponible"]];
    const canales = [["email", "CanalEnvioEmail"], ["sms", "CanalEnvioSMS"], ["push", "CanalEnvioPush"]];
    $("brMatriz").innerHTML = `<div class="matriz"><span class="esquina"></span>${canales.map((c) => `<span class="cab">${c[1]}</span>`).join("")}
      ${avisos.map((a) => `<span class="fila-cab">${a[1]}</span>${canales.map((c) =>
        `<button class="${usadas.has(a[1] + "|" + c[1]) ? "usada" : ""}" onclick="brEnviar('${a[0]}','${c[0]}')">Enviar</button>`).join("")}`).join("")}</div>
      <p class="hint" style="margin:12px 0 0">Combinaciones usadas: ${usadas.size} de 6, con solo 5 clases (2 avisos + 3 canales).</p>`;
    $("brActual").innerHTML = `avisoReutilizado.canal → <code>${esc(e.canalActualReutilizado)}</code>`;
    $("brEnviados").innerHTML = e.enviados.length
      ? e.enviados.map((x) => `<div class="resultado"><span>${esc(x.aviso)}</span><span class="pill">${esc(x.canal.replace("CanalEnvio", ""))}</span></div>`).join("")
      : '<div class="vacio">Sin envíos todavía.</div>';
  },

  decoratorSuscripcion() {
    const e = estado.decoratorSuscripcion;
    if (!e || !e.ultimo) return;
    const u = e.ultimo;
    // Cajas anidadas: la capa más externa por fuera
    let cajas = `<div class="capas nucleo"><span class="nombre">${esc(u.capas[0])}</span></div>`;
    u.capas.slice(1).forEach((c) => { cajas = `<div class="capas"><span class="nombre">${esc(c)}</span>${cajas}</div>`; });
    $("dsResultado").innerHTML = `
      <div class="etiqueta">calcular()</div>
      <div class="total">$${u.total.toLocaleString("es-CO", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
      <div class="etiqueta">detalle()</div>
      <pre class="lineas">${esc(u.detalle.join("\n"))}</pre>
      <pre class="codigo">${esc(u.expresion)}</pre>
      ${cajas}`;
  },

  composite() {
    const e = estado.composite;
    if (!e) return;
    const nodo = (n) => n.tipo === "libro"
      ? `<li><div class="nodo-libro"><span>${esc(n.titulo)}</span><span class="badge">${n.promedio.toFixed(1)}</span></div></li>`
      : `<li><div class="nodo-cat">${esc(n.nombre)}<span class="stats"><span class="pill on">prom ${n.promedio.toFixed(2)}</span><span class="pill">${n.total} libro(s)</span></span></div><ul>${n.hijos.map(nodo).join("")}</ul></li>`;
    $("cpArbol").innerHTML = nodo(e.arbol);
    ["cpCat", "cpPadre"].forEach((id) => {
      const actual = $(id).value;
      $(id).innerHTML = e.categorias.map((c) => `<option>${esc(c)}</option>`).join("");
      if (e.categorias.includes(actual)) $(id).value = actual;
    });
  },

  decoratorReporte() {
    const e = estado.decoratorReporte;
    if (!e || !e.ultimo) return;
    $("drDescripcion").textContent = "getDescripcion(): " + e.ultimo.descripcion;
    $("drCapas").innerHTML = e.ultimo.capas.map((c, i) => `<span class="pill ${i ? "on" : ""}">${esc(c)}</span>`).join("<span>→</span>");
    $("drPapel").textContent = e.ultimo.contenido;
  },

  facade() {
    const e = estado.facade;
    if (!e || !e.ultimo) return;
    const u = e.ultimo;
    document.querySelectorAll("#fcSubsistemas .step").forEach((s) => s.classList.toggle("on", u.subsistemas.includes(s.dataset.sub)));
    const r = u.resultado;
    let cuerpo;
    if (r.contenido) cuerpo = `<pre class="papel">${esc(r.contenido)}</pre>`;
    else if (r.detalle) cuerpo = `<div class="total">$${r.total.toLocaleString("es-CO", { maximumFractionDigits: 2 })}</div><pre class="lineas">${esc(r.detalle)}</pre><div class="mini-sub">Transacción: ${esc(r.idTransaccion)}</div>`;
    else cuerpo = `<pre class="lineas">${esc(JSON.stringify(r, null, 2))}</pre>`;
    $("fcResultado").innerHTML = `<div class="resumen">portal.<b>${esc(u.operacion)}()</b> · ${r.exito === false ? "rechazado" : "listo"}</div>${cuerpo}`;
  },

  flyweight() {
    const e = estado.flyweight;
    if (!e) return;
    if (!$("fwLibro").options.length) $("fwLibro").innerHTML = e.libros.map((l) => `<option value="${l.clave}">${esc(l.titulo)}</option>`).join("");
    $("fwPrestamos").innerHTML = e.prestamos.length
      ? `<p class="mini-titulo">Préstamos (${e.totalPrestamos})</p>` + e.prestamos.map((p) => `<div class="resultado"><span><span class="n">${esc(p.codigo)}</span>${esc(p.usuario)}</span><span class="pill">${esc(p.titulo)}</span></div>`).join("")
      : '<div class="vacio">Aún no hay préstamos.</div>';
    $("fwCompartidos").innerHTML = e.compartidos.length
      ? e.compartidos.map((c) => `<div class="comparte"><div class="usos">${c.usos}</div><div><div class="t">${esc(c.titulo)}</div><div class="m">1 objeto LibroCompartido · ISBN ${esc(c.isbn)}<br>usado por ${c.usos} préstamo(s)</div></div></div>`).join("")
      : '<div class="vacio">La fábrica aún no ha creado ningún libro compartido.</div>';
    if (e.masivo) {
      const m = e.masivo, fmt = (n) => n.toLocaleString("es-CO");
      $("fwMasivo").innerHTML = `<div class="metricas" style="grid-template-columns:1fr 1fr">
        <div class="metrica"><div class="valor">${fmt(m.prestamos)}</div><div class="desc">préstamos creados</div></div>
        <div class="metrica"><div class="valor">${fmt(m.compartidos)}</div><div class="desc">objetos de libro (sin Flyweight: ${fmt(m.prestamos)})</div></div>
        <div class="metrica"><div class="valor">${m.ahorro.toFixed(3)}%</div><div class="desc">menos objetos de libro</div></div>
        <div class="metrica"><div class="valor">${fmt(m.ms)} ms</div><div class="desc">tiempo de creación</div></div></div>`;
    }
  },

  proxy() {
    const e = estado.proxy;
    if (!e) return;
    const real = document.querySelector('#pxCadena .paso[data-px="real"]');
    real.classList.toggle("on", e.realCreado);
    $("pxRealEstado").textContent = e.realCreado ? "creado (1 vez)" : "no creado todavía";
    $("pxMetricas").innerHTML = [
      [e.instanciasReales, "instancias del servicio real"],
      [e.emisionesReales, "emisiones reales (costosas)"],
      [e.aciertosCache, "respuestas desde caché"],
      [e.denegados, "intentos denegados"],
    ].map(([v, d]) => `<div class="metrica"><div class="valor">${v}</div><div class="desc">${d}</div></div>`).join("");
    $("pxCertificados").innerHTML = e.certificados.length
      ? e.certificados.map((c) => `<div class="resultado"><span><span class="n">${esc(c.numero)}</span>${esc(c.idUsuario)}</span><span class="pill ${c.desdeCache ? "on" : ""}">${c.desdeCache ? "caché" : "emisión real"}</span></div>`).join("")
      : '<div class="vacio">Aún no se han emitido certificados.</div>';
  },

  iterator() {
    const e = estado.iterator;
    if (!e) return;
    const paso = e.paso;
    const visitados = new Set();
    // Libros ya entregados = los que aparecen antes del actual en un recorrido en profundidad
    const orden = [];
    (function recorrer(n) { if (n.tipo === "libro") orden.push(n.titulo); else n.hijos.forEach(recorrer); })(e.arbol);
    if (paso && !paso.fin) {
      for (const t of orden) { if (t === paso.titulo) break; visitados.add(t); }
    } else if (paso && paso.fin) orden.forEach((t) => visitados.add(t));

    const nodo = (n) => {
      if (n.tipo === "libro") {
        const clase = paso && !paso.fin && paso.titulo === n.titulo ? "actual" : visitados.has(n.titulo) ? "visitado" : "";
        return `<li><div class="nodo-libro ${clase}"><span>${esc(n.titulo)}</span><span class="badge">${n.calificacion.toFixed(1)}</span></div></li>`;
      }
      return `<li><div class="nodo-cat">${esc(n.nombre)}</div><ul>${n.hijos.map(nodo).join("")}</ul></li>`;
    };
    $("itArbol").innerHTML = nodo(e.arbol);
    $("itNovedades").innerHTML = e.novedades
      .map((l) => `<div class="resultado"><span>${esc(l.titulo)}</span><span class="pill">${l.calificacion.toFixed(1)}</span></div>`).join("");

    const sel = $("itCat");
    if (sel.options.length !== e.categorias.length) sel.innerHTML = e.categorias.map((c) => `<option>${esc(c)}</option>`).join("");

    const c = $("itCursor");
    if (!paso) {
      c.innerHTML = `<div class="etiqueta">Último siguiente()</div><div class="grande">${e.iteradorActivo ? "Iterador listo en la posición inicial" : "Sin iterador todavía"}</div><div class="meta">Pulsa siguiente() para avanzar</div>`;
    } else if (paso.fin) {
      c.innerHTML = `<div class="etiqueta">haySiguiente() = false</div><div class="grande">Recorrido terminado</div><div class="meta">nodosVisitados: ${paso.nodosVisitados}</div>`;
    } else {
      c.innerHTML = `<div class="etiqueta">Último siguiente()</div><div class="grande">${esc(paso.titulo)} · ${paso.calificacion.toFixed(1)}</div><div class="meta">ruta: ${esc(paso.ruta)}<br>nodosVisitados: ${paso.nodosVisitados}</div>`;
    }
  },

  memento() {
    const e = estado.memento;
    if (!e) return;
    const anteriores = pintar.memento.ultimos || {};
    $("meCampos").innerHTML = Object.entries(e.campos).map(([k, v]) => {
      const texto = Array.isArray(v) ? v.join(", ") : v;
      const cambio = anteriores[k] !== undefined && anteriores[k] !== String(texto) ? "cambio" : "";
      return `<dt>${esc(k)}</dt><dd class="${cambio}">${esc(texto)}</dd>`;
    }).join("");
    pintar.memento.ultimos = Object.fromEntries(Object.entries(e.campos).map(([k, v]) => [k, String(Array.isArray(v) ? v.join(", ") : v)]));
    $("meResumen").textContent = "getResumen(): " + e.resumen;
    $("meCapTexto").textContent = `${e.cantidad} / ${e.limite}`;
    $("meCapBarra").style.width = (e.cantidad / e.limite) * 100 + "%";
    $("mePila").innerHTML = e.versiones.length
      ? e.versiones.map((v, i) => `<div class="version ${i === e.versiones.length - 1 ? "tope" : ""}"><span>${esc(v)}</span><span class="candado">contenido privado</span></div>`).join("")
      : '<div class="vacio">El historial está vacío.</div>';
    $("meDeshacer").disabled = !e.puedeDeshacer;
    if (!pintar.memento.relleno) { meRellenar(); pintar.memento.relleno = true; }
  },

  mediator() {
    const e = estado.mediator;
    if (!e) return;
    const opcionesU = e.usuarios.map((u) => `<option value="${u.clave}">${esc(u.nombre)} · ${u.canal}</option>`).join("");
    const opcionesL = e.libros.map((l) => `<option value="${l.clave}">${esc(l.titulo)}</option>`).join("");
    ["mdPUsuario", "mdRUsuario"].forEach((id) => { if (!$(id).options.length) $(id).innerHTML = opcionesU; });
    ["mdPLibro", "mdRLibro"].forEach((id) => { if (!$(id).options.length) $(id).innerHTML = opcionesL; });
    if ($("mdRUsuario").selectedIndex === 0 && !pintar.mediator.inicial) { $("mdRUsuario").selectedIndex = 1; pintar.mediator.inicial = true; }

    $("mdLibros").innerHTML = e.libros.map((l) => `
      <div class="estado-libro">
        <div class="info"><div class="t">${esc(l.titulo)}</div><div class="m">${l.prestado ? "lo tiene " + esc(l.tenedor || "—") : "disponible"}</div></div>
        ${l.prestado ? `<button class="btn-sec" onclick="mdDevolver('${l.clave}')">Devolver</button>` : '<span class="pill">libre</span>'}
      </div>`).join("");
    $("mdColas").innerHTML = e.libros.map((l) => `
      <div class="estado-libro"><div class="info"><div class="t">${esc(l.titulo)}</div></div>
      <span class="pill ${l.enEspera ? "on" : ""}">en espera: ${l.enEspera}</span></div>`).join("");
    $("mdTotal").textContent = e.avisosEnviados;
    $("mdDevoluciones").innerHTML = e.devoluciones.length
      ? e.devoluciones.map((d) => d.avisadoA
          ? `<div class="aviso-item"><b>${esc(d.titulo)}</b> devuelto → aviso a ${esc(d.avisadoA)} <span class="pill canal">${esc(d.canal)}</span></div>`
          : `<div class="aviso-item sin"><b>${esc(d.titulo)}</b> devuelto → sin reservas, queda disponible</div>`).join("")
      : '<div class="vacio">Aún no hay devoluciones.</div>';
  },
};

// ---------------------------------------------------------- acciones Singleton
async function sgPedir(modulo) { await api("singleton", "pedirInstancia", { modulo }, `modulo${modulo} = SesionManager.getInstance()`); }
async function sgNew() { await api("singleton", "intentarNew", {}, "new SesionManager()"); }

// ---------------------------------------------------------- acciones Factory Method
let fmSeleccion = "PDF";
function fmFormato(f) {
  fmSeleccion = f;
  document.querySelectorAll("#fmFormatos .formato-card").forEach((c) => c.classList.toggle("selected", c.dataset.formato === f));
  $("fmCreador").textContent = `CatalogoService${f}.crearLibro()`;
  $("fmProducto").textContent = `Libro${f}`;
}
async function fmRegistrar() {
  const titulo = $("fmTitulo").value, autor = $("fmAutor").value;
  await api("factory", "registrar", { formato: fmSeleccion, titulo, autor }, `new CatalogoService${fmSeleccion}().registrarYAbrir("${titulo}", "${autor}")`);
}
async function fmBase() { await api("factory", "instanciarBase", {}, 'new LibroDigital("Libro genérico", "Autor")'); }

// ---------------------------------------------------------- acciones Builder
async function bdManual() {
  const datos = {
    titulo: $("bdTitulo").value, autor: $("bdAutor").value, anioPublicacion: $("bdAnio").value,
    idioma: $("bdIdioma").value, categorias: $("bdCategorias").value, editorial: $("bdEditorial").value,
  };
  await api("builder", "construirManual", datos, "builder.setTitulo(...).setAutor(...)...build()");
}
async function bdDirector() {
  const tipo = $("bdTipo").value;
  const metodo = tipo === "basica" ? "construirFichaBasica" : "construirFichaCompleta";
  await api("builder", "construirConDirector", { tipo, titulo: $("bdDTitulo").value, autor: $("bdDAutor").value }, `director.${metodo}(builder, {...})`);
}

// ---------------------------------------------------------- acciones Abstract Factory
let afSeleccion = "basica";
function afFamilia(f) {
  afSeleccion = f;
  document.querySelectorAll("#afFamilias .formato-card").forEach((c) => c.classList.toggle("selected", c.dataset.familia === f));
}
async function afEjecutar() {
  const clase = afSeleccion === "basica" ? "ServicioBasicoFactory" : "ServicioPremiumFactory";
  await api("abstractFactory", "ejecutar", { familia: afSeleccion, mensaje: $("afMensaje").value, datos: $("afDatos").value },
    `new GestorServicios(new ${clase}()).avisarYReportar(...)`);
}

// ---------------------------------------------------------- acciones Prototype
async function ptClonar() {
  const plantilla = $("ptPlantilla").value;
  await api("prototype", "clonar", { plantilla, titulo: $("ptTitulo").value, autor: $("ptAutor").value }, `registro.obtenerClon("${plantilla}")`);
}
async function ptNota(codigo) {
  const campo = $("nota-" + codigo);
  await api("prototype", "agregarNota", { codigo, nota: campo ? campo.value : "" }, `${codigo}.notas.push(...)`);
}
async function ptInexistente() { await api("prototype", "clonarInexistente", {}, 'registro.obtenerClon("premium-inexistente")'); }

// ---------------------------------------------------------- acciones Adapter
async function adPagar() {
  const monto = $("adMonto").value, concepto = $("adConcepto").value;
  await api("adapter", "pagar", { monto, concepto }, `pasarela.procesarPago(${monto}, "${concepto}")`);
}
async function adDirecto() { await api("adapter", "usarStripeDirecto", {}, "new StripeAPI().procesarPago(...)"); }

// ---------------------------------------------------------- acciones Bridge
async function brEnviar(aviso, canal) {
  const clases = { vencido: "AvisoPrestamoVencido", reserva: "AvisoReservaDisponible", email: "CanalEnvioEmail", sms: "CanalEnvioSMS", push: "CanalEnvioPush" };
  await api("bridge", "enviar", { aviso, canal, libro: $("brLibro").value }, `new ${clases[aviso]}(new ${clases[canal]}()).notificar(usuario)`);
}
async function brCambiar() {
  const canal = $("brCanal").value;
  await api("bridge", "cambiarCanal", { canal, libro: $("brLibro").value }, `avisoReutilizado.cambiarCanal(new ${$("brCanal").selectedOptions[0].text}())`);
}

// ---------------------------------------------------------- acciones Decorator (costos)
const dsCapas = [];
const DS_CLASES = { anual: "DescuentoPagoAnual", estudiante: "DescuentoEstudiante", dispositivos: "RecargoDispositivosExtra" };
function dsCapa(check) {
  const capa = check.dataset.capa;
  const i = dsCapas.indexOf(capa);
  if (check.checked && i < 0) dsCapas.push(capa);
  if (!check.checked && i >= 0) dsCapas.splice(i, 1);
  $("dsOrden").textContent = ["SuscripcionBase", ...dsCapas.map((c) => DS_CLASES[c])].join(" → ");
}
async function dsCalcular() {
  await api("decoratorSuscripcion", "calcular", { costoBase: $("dsBase").value, capas: dsCapas, dispositivos: $("dsDispositivos").value },
    `calculo.calcular()  // ${["SuscripcionBase", ...dsCapas.map((c) => DS_CLASES[c])].join(" → ")}`);
}
async function dsBaseError() { await api("decoratorSuscripcion", "instanciarDecoratorBase", {}, "new SuscripcionDecorator(base)"); }

// ---------------------------------------------------------- acciones Composite
async function cpLibro() {
  const datos = { categoria: $("cpCat").value, titulo: $("cpTitulo").value, calificacion: $("cpNota").value };
  const r = await api("composite", "agregarLibro", datos, `${datos.categoria}.agregar(new LibroCatalogado(...))`);
  if (r && r.ok) $("cpTitulo").value = "";
}
async function cpCategoria() {
  const datos = { padre: $("cpPadre").value, nombre: $("cpNombre").value };
  const r = await api("composite", "agregarCategoria", datos, `${datos.padre}.agregar(new Categoria("${datos.nombre}"))`);
  if (r && r.ok) $("cpNombre").value = "";
}
async function cpMostrar() { await api("composite", "mostrar", { categoria: "Literatura" }, "literatura.mostrar()"); }
async function cpComponente() { await api("composite", "usarComponente", {}, "new ElementoCatalogo().getCalificacionPromedio()"); }

// ---------------------------------------------------------- acciones Decorator (reportes)
async function drGenerar() {
  await api("decoratorReporte", "generar", {
    encabezado: $("drEncabezado").checked, notas: $("drNotas").value, firmante: $("drFirmante").value, marca: $("drMarca").value,
  }, "reporte.generar()");
}

// ---------------------------------------------------------- acciones Facade
async function fcConsultar() { await api("facade", "consultarCalificacionCatalogo", {}, "portal.consultarCalificacionCatalogo()"); }
async function fcSuscribirse() {
  await api("facade", "suscribirse", {
    costoBase: $("fcCosto").value, pagoAnual: $("fcAnual").checked, estudiante: $("fcEstudiante").checked, dispositivosExtra: $("fcDisp").value,
  }, "portal.suscribirse({...})");
}
async function fcReporte() { await api("facade", "generarReporteOficial", { firmante: $("fcFirmante").value }, "portal.generarReporteOficial(prestamos, firmante)"); }
async function fcNotificar() { const canal = $("fcCanal").value; await api("facade", "notificarPrestamoVencido", { canal }, `portal.notificarPrestamoVencido(datos, "${canal}")`); }

// ---------------------------------------------------------- acciones Flyweight
async function fwPrestar() {
  const libro = $("fwLibro").value, usuario = $("fwUsuario").value;
  await api("flyweight", "prestar", { libro, usuario }, `new PrestamoActivo("${usuario}", fabrica.obtener(${libro}), ...)`);
}
async function fwModificar() { await api("flyweight", "modificarCompartido", {}, 'prestamo.libro.titulo = "Título alterado"'); }
async function fwMasivo() {
  $("fwMasivo").innerHTML = '<p class="hint" style="margin:12px 0 0">Creando…</p>';
  await api("flyweight", "masivo", { total: 100000 }, "100.000 préstamos sobre 3 libros");
}

// ---------------------------------------------------------- acciones Proxy
async function pxEmitir() {
  const id = $("pxId").value;
  const r = await api("proxy", "emitir", { idUsuario: id }, `emisor.emitir("${id}")`);
  if (!r) return;
  const consola = (r.consola || []).join("\n");
  document.querySelectorAll("#pxCadena .paso").forEach((p) => p.classList.remove("on", "no"));
  const marcar = (px, clase) => { const el = document.querySelector(`#pxCadena .paso[data-px="${px}"]`); if (el) el.classList.add(clase); };
  if (estado.proxy && estado.proxy.realCreado) marcar("real", "on"); // el servicio real sigue existiendo
  if (!r.ok) { marcar("proteccion", "no"); return; }
  marcar("proteccion", "on"); marcar("cache", "on");
  if (!/desde caché/.test(consola)) { marcar("virtual", "on"); marcar("real", "on"); }
}

// ---------------------------------------------------------- acciones Iterator
const itCol = () => $("itColeccion").value;
function pintarResultados(lista, numerar) {
  $("itResultados").innerHTML = lista && lista.length
    ? lista.map((l, i) => `<div class="resultado"><span>${numerar ? `<span class="n">${i + 1}.</span>` : ""}${esc(l.titulo)}</span><span class="pill">${l.calificacion.toFixed(1)}</span></div>`).join("")
    : '<div class="vacio">Ningún libro cumple el criterio.</div>';
}
async function itSiguiente() { await api("iterator", "siguiente", {}, "iterador.siguiente()"); }
async function itNuevo() { await api("iterator", "crearIterador", {}, "catalogo.crearIterador()"); }
async function itTodo() {
  const r = await api("iterator", "recorrerTodo", { coleccion: itCol() }, `for (const libro of ${itCol()}) ...`);
  if (r && r.ok) pintarResultados(r.resultado, false);
}
async function itFiltrar() {
  const minimo = $("itMin").value;
  const r = await api("iterator", "recorrerFiltrado", { coleccion: itCol(), minimo }, `${itCol()}.crearIteradorFiltrado(l => l.calificacion >= ${minimo})`);
  if (r && r.ok) pintarResultados(r.resultado, false);
}
async function itRecomendar() {
  const minimo = $("itMin").value, cantidad = $("itCantidad").value;
  const r = await api("iterator", "recomendar", { coleccion: itCol(), minimo, cantidad }, `generador.recomendar(${itCol()}, ${minimo}, ${cantidad})`);
  if (r && r.ok) pintarResultados(r.resultado, true);
}
async function itAgregar() {
  const datos = { categoria: $("itCat").value, titulo: $("itTitulo").value, calificacion: $("itNota").value };
  const r = await api("iterator", "agregarLibro", datos, `${datos.categoria}.agregar(new LibroCatalogado("${datos.titulo}", ${datos.calificacion}))`);
  if (r && r.ok) { $("itTitulo").value = ""; toast("Libro agregado al árbol del catálogo.", true); }
}
async function itEscalabilidad() {
  $("itEscala").innerHTML = '<p class="hint" style="margin:14px 0 0">Ejecutando…</p>';
  const r = await api("iterator", "escalabilidad", {}, "Prueba de escalabilidad con 100.000 libros");
  if (!r || !r.ok) { $("itEscala").innerHTML = ""; return; }
  const d = r.resultado;
  const pct = (d.visitados / d.totalNodos) * 100;
  const fmt = (n) => n.toLocaleString("es-CO");
  $("itEscala").innerHTML = `
    <div class="metricas">
      <div class="metrica"><div class="valor">${fmt(d.totalLibros)}</div><div class="desc">libros en el catálogo</div></div>
      <div class="metrica"><div class="valor">${fmt(d.visitados)}</div><div class="desc">nodos visitados</div></div>
      <div class="metrica"><div class="valor">${pct.toFixed(3)}%</div><div class="desc">del árbol (${fmt(d.totalNodos)} nodos)</div></div>
      <div class="metrica"><div class="valor">${fmt(d.milisegundos)} ms</div><div class="desc">armar + recorrer</div></div>
    </div>
    <div class="barra" title="Parte del árbol recorrida"><div style="width:${Math.max(pct, 0.4)}%"></div></div>
    <p class="hint" style="margin:10px 0 0">Encontrados: ${d.encontrados.map(esc).join(", ")}. El iterador se detuvo apenas tuvo los 5.</p>`;
}

// ---------------------------------------------------------- acciones Memento
function meRellenar() {
  const e = estado.memento;
  const campo = $("meCampo").value;
  if (!e) return;
  const v = e.campos[campo];
  $("meValor").value = Array.isArray(v) ? v.join(", ") : v ?? "";
  $("meValor").type = campo === "anioPublicacion" ? "number" : "text";
  $("meHint").textContent = campo === "categorias" ? "Separa las categorías con comas." : "Se guardará una versión antes de aplicar el cambio.";
}
async function meEditar() {
  const campo = $("meCampo").value, valor = $("meValor").value;
  const r = await api("memento", "guardarYEditar", { campo, valor }, `historial.guardar(...); ficha.editar("${campo}", ${JSON.stringify(valor)})`);
  if (r && r.ok) $("meInspeccion").innerHTML = "";
}
async function meDeshacer() {
  const r = await api("memento", "deshacer", {}, "historial.deshacer()");
  if (r && r.ok) { meRellenar(); $("meInspeccion").innerHTML = ""; }
}
async function meInspeccionar() {
  const r = await api("memento", "inspeccionarMemento", {}, "const memento = historial.verUltimo()");
  if (!r || !r.ok) return;
  const d = r.resultado;
  $("meInspeccion").innerHTML = `<div class="inspeccion">
    memento.getDescripcion() → "${esc(d.descripcion)}"<br>
    Object.keys(memento) → ${esc(JSON.stringify(d.propiedadesPublicas))}<br>
    memento.estado → ${esc(d.estadoDirecto)}<br>
    memento.obtenerEstado(otraLlave) → <span class="err">${esc(d.intentoLectura)}</span></div>`;
}

// ---------------------------------------------------------- acciones Mediator
function marcarFlujo(pasos) {
  document.querySelectorAll("#mdFlujo .paso").forEach((p) => p.classList.remove("on"));
  clearTimeout(marcarFlujo.timers);
  pasos.forEach((paso, i) => setTimeout(() => {
    const el = document.querySelector(`#mdFlujo .paso[data-paso="${paso}"]`);
    if (el) el.classList.add("on");
  }, i * 280));
}
async function mdPrestar() {
  const usuario = $("mdPUsuario").value, libro = $("mdPLibro").value;
  await api("mediator", "prestar", { usuario, libro }, `prestamos.prestar(${usuario}, ${libro})`);
  marcarFlujo([]);
}
async function mdReservar() {
  const usuario = $("mdRUsuario").value, libro = $("mdRLibro").value;
  await api("mediator", "reservar", { usuario, libro }, `reservas.reservar(${libro}, ${usuario})`);
}
async function mdDevolver(libro) {
  const r = await api("mediator", "devolver", { libro }, `prestamos.devolver(${libro})`);
  if (!r) return;
  const consola = (r.consola || []).join("\n");
  const pasos = ["prestamos", "mediador", "reservas"];
  if (/Se solicita el aviso/.test(consola)) pasos.push("avisos");
  marcarFlujo(r.ok || /Mediador/.test(consola) ? pasos : ["prestamos"]);
}

// ---------------------------------------------------------- inicio
(async function iniciar() {
  let inicial = "singleton";
  try { const t = localStorage.getItem("panel-tab"); if (t && $("panel-" + t)) inicial = t; } catch (e) { /* sin almacenamiento */ }
  cambiarTab(inicial);
  await Promise.all(disponibles().map((p) => api(p.id, "estado")));
  const s = await api("sesion", "estado");
  if (s && s.ok) pintarSesion(s.estado ?? null);
})();
