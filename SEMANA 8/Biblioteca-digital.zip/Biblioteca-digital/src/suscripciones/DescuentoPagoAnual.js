
const SuscripcionDecorator = require("./SuscripcionDecorator");

const PORCENTAJE = 0.15;

class DescuentoPagoAnual extends SuscripcionDecorator {
  calcular() {
    return this.componente.calcular() * (1 - PORCENTAJE);
  }

  detalle() {
    const ahorro = this.componente.calcular() * PORCENTAJE;
    return (
      this.componente.detalle() +
      `\n  - Descuento pago anual (-${PORCENTAJE * 100}%): -$${ahorro.toFixed(2)}`
    );
  }
}

module.exports = DescuentoPagoAnual;
