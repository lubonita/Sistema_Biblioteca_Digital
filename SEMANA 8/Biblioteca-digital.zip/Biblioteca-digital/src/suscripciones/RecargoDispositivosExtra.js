
const SuscripcionDecorator = require("./SuscripcionDecorator");

const RECARGO_POR_DISPOSITIVO = 4900;

class RecargoDispositivosExtra extends SuscripcionDecorator {
  constructor(componente, cantidadDispositivosExtra) {
    super(componente);
    this.cantidadDispositivosExtra = cantidadDispositivosExtra;
  }

  calcular() {
    return this.componente.calcular() + RECARGO_POR_DISPOSITIVO * this.cantidadDispositivosExtra;
  }

  detalle() {
    const recargo = RECARGO_POR_DISPOSITIVO * this.cantidadDispositivosExtra;
    return (
      this.componente.detalle() +
      `\n  + Recargo ${this.cantidadDispositivosExtra} dispositivo(s) extra: +$${recargo.toFixed(2)}`
    );
  }
}

module.exports = RecargoDispositivosExtra;
