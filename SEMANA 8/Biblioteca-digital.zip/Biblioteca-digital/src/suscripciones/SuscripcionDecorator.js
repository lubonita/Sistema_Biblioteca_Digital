
const CalculoSuscripcion = require("./CalculoSuscripcion");

class SuscripcionDecorator extends CalculoSuscripcion {
  constructor(componente) {
    super();
    if (new.target === SuscripcionDecorator) {
      throw new Error("SuscripcionDecorator es una clase base y no puede instanciarse directamente.");
    }
    this.componente = componente;
  }

  calcular() {
    return this.componente.calcular();
  }

  detalle() {
    return this.componente.detalle();
  }
}

module.exports = SuscripcionDecorator;
