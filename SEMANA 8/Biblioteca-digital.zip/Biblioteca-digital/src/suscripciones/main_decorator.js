

const CalculoSuscripcion = require("./suscripciones/CalculoSuscripcion");
const SuscripcionBase = require("./suscripciones/SuscripcionBase");
const SuscripcionDecorator = require("./suscripciones/SuscripcionDecorator");
const DescuentoPagoAnual = require("./suscripciones/DescuentoPagoAnual");
const DescuentoEstudiante = require("./suscripciones/DescuentoEstudiante");
const RecargoDispositivosExtra = require("./suscripciones/RecargoDispositivosExtra");

console.log("========================================");
console.log(" PRUEBA 1: Suscripción base, sin decorar");
console.log("========================================");
let calculo1 = new SuscripcionBase(29900);
console.log(calculo1.detalle());
console.log(`TOTAL: $${calculo1.calcular().toFixed(2)}`);

console.log("\n========================================");
console.log(" PRUEBA 2: Base + descuento por pago anual");
console.log("========================================");
calculo1 = new DescuentoPagoAnual(calculo1);
console.log(calculo1.detalle());
console.log(`TOTAL: $${calculo1.calcular().toFixed(2)}`);

console.log("\n========================================");
console.log(" PRUEBA 3: Base + pago anual + descuento estudiante (combinación de 2)");
console.log("========================================");
calculo1 = new DescuentoEstudiante(calculo1);
console.log(calculo1.detalle());
console.log(`TOTAL: $${calculo1.calcular().toFixed(2)}`);

console.log("\n========================================");
console.log(" PRUEBA 4: Otra combinación, con 3 decoradores y recargo por dispositivos");
console.log("========================================");
let calculo2 = new SuscripcionBase(29900);
calculo2 = new DescuentoEstudiante(calculo2);
calculo2 = new RecargoDispositivosExtra(calculo2, 2);
console.log(calculo2.detalle());
console.log(`TOTAL: $${calculo2.calcular().toFixed(2)}`);

console.log("\n========================================");
console.log(" PRUEBA 5: Confirmar que el ORDEN de decoración afecta el resultado");
console.log("========================================");
let ordenA = new SuscripcionBase(29900);
ordenA = new RecargoDispositivosExtra(ordenA, 2); // recargo primero
ordenA = new DescuentoEstudiante(ordenA); // descuento después (aplica también al recargo)

let ordenB = new SuscripcionBase(29900);
ordenB = new DescuentoEstudiante(ordenB); // descuento primero
ordenB = new RecargoDispositivosExtra(ordenB, 2); // recargo después (no se descuenta)

console.log("Orden A (recargo, luego descuento) TOTAL:", ordenA.calcular().toFixed(2));
console.log("Orden B (descuento, luego recargo) TOTAL:", ordenB.calcular().toFixed(2));
console.log("¿Dan el mismo resultado?", ordenA.calcular() === ordenB.calcular());

console.log("\n========================================");
console.log(" PRUEBA 6: Confirmar que cada decorador sigue cumpliendo la interfaz CalculoSuscripcion");
console.log("========================================");
console.log("¿calculo1 es instancia de CalculoSuscripcion?", calculo1 instanceof CalculoSuscripcion);
console.log("¿calculo2 es instancia de CalculoSuscripcion?", calculo2 instanceof CalculoSuscripcion);

console.log("\n========================================");
console.log(" PRUEBA 7: Intentar usar el Decorator abstracto directamente (debe fallar)");
console.log("========================================");
try {
  new SuscripcionDecorator(new SuscripcionBase(29900));
} catch (error) {
  console.log("Error capturado como se esperaba:", error.message);
}
