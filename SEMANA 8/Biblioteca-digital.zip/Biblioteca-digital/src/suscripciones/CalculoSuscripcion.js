
class CalculoSuscripcion {
  calcular() {
    throw new Error("calcular() debe ser implementado por la subclase.");
  }

  detalle() {
    throw new Error("detalle() debe ser implementado por la subclase.");
  }
}

module.exports = CalculoSuscripcion;
