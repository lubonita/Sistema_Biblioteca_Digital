

const SuscripcionDecorator = require("./SuscripcionDecorator");

const PORCENTAJE = 0.10;

class DescuentoEstudiante extends SuscripcionDecorator {
  calcular() {
    return this.componente.calcular() * (1 - PORCENTAJE);
  }

  detalle() {
    const ahorro = this.componente.calcular() * PORCENTAJE;
    return (
      this.componente.detalle() +
      `\n  - Descuento estudiante (-${PORCENTAJE * 100}%): -$${ahorro.toFixed(2)}`
    );
  }
}

module.exports = DescuentoEstudiante;
