

const CalculoSuscripcion = require("./CalculoSuscripcion");

class SuscripcionBase extends CalculoSuscripcion {
  constructor(costoBase) {
    super();
    this.costoBase = costoBase;
  }

  calcular() {
    return this.costoBase;
  }

  detalle() {
    return `Suscripción base: $${this.costoBase.toFixed(2)}`;
  }
}

module.exports = SuscripcionBase;
