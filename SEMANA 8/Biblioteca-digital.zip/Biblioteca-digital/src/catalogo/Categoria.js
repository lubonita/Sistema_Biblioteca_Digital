const ElementoCatalogo = require("./ElementoCatalogo");

class Categoria extends ElementoCatalogo {
  constructor(nombre) {
    super();
    this.nombre = nombre;
    this.elementos = [];
  }

  agregar(elemento) {
    this.elementos.push(elemento);
  }

  eliminar(elemento) {
    this.elementos = this.elementos.filter((e) => e !== elemento);
  }

  getCalificacionPromedio() {
    if (this.elementos.length === 0) return 0;
    const suma = this.elementos.reduce((acc, e) => acc + e.getCalificacionPromedio(), 0);
    return suma / this.elementos.length;
  }

  getTotalLibros() {
    return this.elementos.reduce((acc, e) => acc + e.getTotalLibros(), 0);
  }

  mostrar(indentacion = "") {
    console.log(`${indentacion}+ Categoría: ${this.nombre}`);
    this.elementos.forEach((e) => e.mostrar(indentacion + "  "));
  }
}

module.exports = Categoria;
