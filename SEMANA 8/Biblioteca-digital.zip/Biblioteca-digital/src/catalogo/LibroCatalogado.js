const ElementoCatalogo = require("./ElementoCatalogo");

class LibroCatalogado extends ElementoCatalogo {
  constructor(titulo, calificacion) {
    super();
    this.titulo = titulo;
    this.calificacion = calificacion;
  }

  getCalificacionPromedio() {
    return this.calificacion;
  }

  getTotalLibros() {
    return 1;
  }

  mostrar(indentacion = "") {
    console.log(`${indentacion}- Libro: ${this.titulo} (calificación ${this.calificacion.toFixed(1)})`);
  }
}

module.exports = LibroCatalogado;
