const ElementoCatalogo = require("./catalogo/ElementoCatalogo");
const LibroCatalogado = require("./catalogo/LibroCatalogado");
const Categoria = require("./catalogo/Categoria");

console.log("========================================");
console.log(" PRUEBA 1: Crear libros individuales (hojas)");
console.log("========================================");
const cienAnios = new LibroCatalogado("Cien años de soledad", 4.8);
const rayuela = new LibroCatalogado("Rayuela", 4.5);
const dune = new LibroCatalogado("Dune", 4.7);
const fundacion = new LibroCatalogado("Fundación", 4.6);
console.log("Libros creados:", cienAnios.titulo, "|", rayuela.titulo, "|", dune.titulo, "|", fundacion.titulo);

console.log("\n========================================");
console.log(" PRUEBA 2: Agrupar libros en categorías (ramas de primer nivel)");
console.log("========================================");
const novela = new Categoria("Novela");
novela.agregar(cienAnios);
novela.agregar(rayuela);

const cienciaFiccion = new Categoria("Ciencia Ficción");
cienciaFiccion.agregar(dune);
cienciaFiccion.agregar(fundacion);

console.log("Promedio de Novela:", novela.getCalificacionPromedio().toFixed(2));
console.log("Promedio de Ciencia Ficción:", cienciaFiccion.getCalificacionPromedio().toFixed(2));

console.log("\n========================================");
console.log(" PRUEBA 3: Anidar categorías dentro de una categoría superior");
console.log("========================================");
const literatura = new Categoria("Literatura");
literatura.agregar(novela);
literatura.agregar(cienciaFiccion);

// Un libro también se puede agregar directamente a una categoría de nivel superior
const poemario = new LibroCatalogado("Veinte poemas de amor", 4.3);
literatura.agregar(poemario);

console.log("'Literatura' contiene 2 subcategorías + 1 libro suelto, de forma recursiva.");

console.log("\n========================================");
console.log(" PRUEBA 4: Calcular el promedio de TODA la categoría superior con el mismo método");
console.log("========================================");
console.log("Promedio general de 'Literatura':", literatura.getCalificacionPromedio().toFixed(2));
console.log("Total de libros en 'Literatura':", literatura.getTotalLibros());

console.log("\n========================================");
console.log(" PRUEBA 5: Mostrar el árbol completo (recorrido recursivo)");
console.log("========================================");
literatura.mostrar();

console.log("\n========================================");
console.log(" PRUEBA 6: Confirmar que hoja y rama cumplen la MISMA interfaz");
console.log("========================================");
console.log("¿cienAnios es ElementoCatalogo?", cienAnios instanceof ElementoCatalogo);
console.log("¿literatura es ElementoCatalogo?", literatura instanceof ElementoCatalogo);
console.log(
  "¿Un libro individual también responde a getCalificacionPromedio()?",
  typeof cienAnios.getCalificacionPromedio === "function"
);

console.log("\n========================================");
console.log(" PRUEBA 7: Intentar usar el Component directamente (debe fallar)");
console.log("========================================");
try {
  const elementoBase = new ElementoCatalogo();
  elementoBase.getCalificacionPromedio();
} catch (error) {
  console.log("Error capturado como se esperaba:", error.message);
}
