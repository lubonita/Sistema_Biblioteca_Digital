class ElementoCatalogo {
  getCalificacionPromedio() {
    throw new Error("getCalificacionPromedio() debe ser implementado por la subclase.");
  }

  getTotalLibros() {
    throw new Error("getTotalLibros() debe ser implementado por la subclase.");
  }

  mostrar(indentacion) {
    throw new Error("mostrar() debe ser implementado por la subclase.");
  }
}

module.exports = ElementoCatalogo;
