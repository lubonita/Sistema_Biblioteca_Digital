# Sistema de Biblioteca Digital

Proyecto integrador del curso **Patrones de Software** — Grupo E195
Docente: Ing. Eliecer Montero Ojeda

## Descripción

Sistema orientado a la gestión de libros digitales, préstamos, reservas y
recomendaciones, con soporte para múltiples formatos (PDF, EPUB, MOBI),
múltiples dispositivos de lectura, sistema de suscripciones y acceso
multiusuario simultáneo, pensado para escalar a más de 100.000 usuarios.

Este proyecto se desarrolla de forma incremental: en cada entrega semanal
se incorpora un nuevo patrón de software sobre la misma base de código.

## Patrones implementados

| Semana | Patrón         | Módulo                          | Estado          |
|--------|----------------|----------------------------------|-----------------|
| 2      | Singleton      | `src/auth/SesionManager.js`      | ✅ Implementado |
| 4      | Factory Method | `src/libros/`                    | ✅ Implementado |

## Estructura del proyecto

```
biblioteca-digital/
├── src/
│   ├── auth/
│   │   └── SesionManager.js        # Singleton: gestión única de sesión/login
│   ├── libros/
│   │   ├── LibroDigital.js         # Producto (base)
│   │   ├── LibroPDF.js             # Producto Concreto
│   │   ├── LibroEPUB.js            # Producto Concreto
│   │   ├── LibroMOBI.js            # Producto Concreto
│   │   ├── CatalogoService.js      # Creador (abstracto, con el método fábrica)
│   │   ├── CatalogoServicePDF.js   # Creador Concreto
│   │   ├── CatalogoServiceEPUB.js  # Creador Concreto
│   │   └── CatalogoServiceMOBI.js  # Creador Concreto
│   ├── main.js                     # Pruebas por consola — Singleton
│   └── main_factory.js             # Pruebas por consola — Factory Method
├── web/
│   └── index.html                  # Versión visual con pestañas por patrón
└── README.md
```

- **`src/`**: contiene todo el código fuente de la aplicación.
- **`src/auth/`**: agrupa la lógica relacionada con autenticación y sesión
  de usuarios.
- **`src/libros/`**: agrupa la lógica relacionada con la creación de libros
  digitales según su formato. A medida que se agreguen nuevos patrones,
  cada uno tendrá su propia carpeta temática dentro de `src/` (por ejemplo
  `src/prestamos/`, `src/recomendaciones/`, etc.).
- **`web/index.html`**: versión visual del proyecto, organizada por
  pestañas — una por cada patrón implementado — para facilitar la
  comprensión del funcionamiento de cada uno.

## Patrón Singleton — Semana 2

Se implementó en `SesionManager`, el módulo responsable de controlar la
autenticación (login/logout) y el estado de la sesión activa. Se eligió
como Singleton porque el sistema requiere un único punto de control de
sesión compartido por todos los módulos, evitando estados inconsistentes
sobre quién está autenticado en un momento dado.

## Patrón Factory Method — Semana 4

Se implementó en el módulo `libros`, específicamente en `CatalogoService`
y sus tres variantes concretas (`CatalogoServicePDF`, `CatalogoServiceEPUB`,
`CatalogoServiceMOBI`). Cada formato tiene su propio Creador Concreto
responsable de construir su tipo de libro, evitando condicionales
dispersos y permitiendo agregar nuevos formatos sin modificar el código
existente (Principio Abierto/Cerrado). Este módulo se apoya en el
Singleton `SesionManager` para asociar cada libro creado al usuario
autenticado, sin haber tenido que modificarlo.

## Cómo ejecutar el proyecto

Requisitos: [Node.js](https://nodejs.org/) instalado.

```bash
# Desde la carpeta raíz del proyecto

# Pruebas del patrón Singleton
node src/main.js

# Pruebas del patrón Factory Method
node src/main_factory.js
```

**`src/main.js`** ejecuta una serie de pruebas por consola que demuestran:
- Que siempre se obtiene la misma instancia de `SesionManager`.
- Que el estado de sesión se comparte entre distintas referencias.
- Que no es posible crear una instancia adicional con `new`.
- El flujo completo de login y logout.

**`src/main_factory.js`** ejecuta una serie de pruebas por consola que
demuestran:
- Que cada `CatalogoService` concreto crea un tipo distinto de libro
  (PDF, EPUB o MOBI) según su propia implementación de `crearLibro()`.
- Que el Factory Method se integra con el Singleton de sesión sin
  necesidad de modificarlo.
- Que no es posible instanciar directamente las clases base
  `LibroDigital` y `CatalogoService` — solo a través de sus subclases
  concretas.

## Próximas entregas

En las siguientes semanas se irán incorporando patrones adicionales
(Abstract Factory, Builder, Prototype, Adapter, Bridge, Composite,
Decorator, Facade, Flyweight, Proxy, Chain of Responsibility, Command,
Interpreter, Mediator, Memento, Observer, State, Strategy, Template
Method, Visitor) sobre esta misma base de código.
