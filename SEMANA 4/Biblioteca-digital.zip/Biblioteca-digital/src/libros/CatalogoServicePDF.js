const CatalogoService = require("./CatalogoService");
const LibroPDF = require("./LibroPDF");

class CatalogoServicePDF extends CatalogoService {
  crearLibro(titulo, autor) {
    return new LibroPDF(titulo, autor);
  }
}

module.exports = CatalogoServicePDF;
