const LibroDigital = require("./LibroDigital");

class LibroEPUB extends LibroDigital {
  abrir() {
    console.log(`[LibroEPUB] Abriendo "${this.titulo}" con el lector de EPUB (texto reflable).`);
    return `Contenido en formato EPUB de "${this.titulo}"`;
  }
}

module.exports = LibroEPUB;
