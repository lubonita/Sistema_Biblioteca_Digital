const SesionManager = require("../auth/SesionManager");

class CatalogoService {
  // Método fábrica: las subclases deciden qué LibroDigital retornar
  crearLibro(titulo, autor) {
    throw new Error("crearLibro() debe ser implementado por la subclase.");
  }

  // Método de negocio: usa el producto sin conocer su clase concreta
  registrarYAbrir(titulo, autor) {
    const libro = this.crearLibro(titulo, autor);

    const sesion = SesionManager.getInstance();
    const usuario = sesion.getUsuarioActual();
    const nombreUsuario = usuario ? usuario.nombre : "Usuario invitado";

    console.log(`[CatalogoService] ${nombreUsuario} solicitó: ${libro.getInfo()}`);
    libro.abrir();
    return libro;
  }
}

module.exports = CatalogoService;
