const LibroDigital = require("./LibroDigital");

class LibroPDF extends LibroDigital {
  abrir() {
    console.log(`[LibroPDF] Abriendo "${this.titulo}" con el lector de PDF.`);
    return `Contenido en formato PDF de "${this.titulo}"`;
  }
}

module.exports = LibroPDF;
