const CatalogoService = require("./CatalogoService");
const LibroEPUB = require("./LibroEPUB");

class CatalogoServiceEPUB extends CatalogoService {
  crearLibro(titulo, autor) {
    return new LibroEPUB(titulo, autor);
  }
}

module.exports = CatalogoServiceEPUB;
