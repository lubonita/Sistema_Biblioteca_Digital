const CatalogoService = require("./CatalogoService");
const LibroMOBI = require("./LibroMOBI");

class CatalogoServiceMOBI extends CatalogoService {
  crearLibro(titulo, autor) {
    return new LibroMOBI(titulo, autor);
  }
}

module.exports = CatalogoServiceMOBI;
