class LibroDigital {
  constructor(titulo, autor) {
    if (new.target === LibroDigital) {
      throw new Error(
        "LibroDigital es una clase base y no puede instanciarse directamente."
      );
    }
    this.titulo = titulo;
    this.autor = autor;
  }

  abrir() {
    throw new Error("El método abrir() debe ser implementado por la subclase.");
  }

  getInfo() {
    return `"${this.titulo}" de ${this.autor} [${this.constructor.name}]`;
  }
}

module.exports = LibroDigital;
