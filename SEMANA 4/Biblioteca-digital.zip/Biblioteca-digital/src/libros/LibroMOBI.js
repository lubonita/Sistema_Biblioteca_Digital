const LibroDigital = require("./LibroDigital");

class LibroMOBI extends LibroDigital {
  abrir() {
    console.log(`[LibroMOBI] Abriendo "${this.titulo}" con el lector compatible con Kindle (MOBI).`);
    return `Contenido en formato MOBI de "${this.titulo}"`;
  }
}

module.exports = LibroMOBI;
