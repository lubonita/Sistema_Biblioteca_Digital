/**
 * main_factory.js
 * ---------------------------------------------------
 * Pruebas por consola del patrón Factory Method aplicado
 * a la creación de libros digitales (PDF, EPUB, MOBI)
 * en el Sistema de Biblioteca Digital.
 * ---------------------------------------------------
 */

const SesionManager = require("./auth/SesionManager");
const CatalogoServicePDF = require("./libros/CatalogoServicePDF");
const CatalogoServiceEPUB = require("./libros/CatalogoServiceEPUB");
const CatalogoServiceMOBI = require("./libros/CatalogoServiceMOBI");

console.log("========================================");
console.log(" PRUEBA 1: Iniciar sesión (usa el Singleton de la semana pasada)");
console.log("========================================");
const sesion = SesionManager.getInstance();
sesion.login("vmillan", "1234");

console.log("\n========================================");
console.log(" PRUEBA 2: Crear y abrir un libro en formato PDF");
console.log("========================================");
const catalogoPDF = new CatalogoServicePDF();
catalogoPDF.registrarYAbrir("Cien años de soledad", "Gabriel García Márquez");

console.log("\n========================================");
console.log(" PRUEBA 3: Crear y abrir un libro en formato EPUB");
console.log("========================================");
const catalogoEPUB = new CatalogoServiceEPUB();
catalogoEPUB.registrarYAbrir("Rayuela", "Julio Cortázar");

console.log("\n========================================");
console.log(" PRUEBA 4: Crear y abrir un libro en formato MOBI");
console.log("========================================");
const catalogoMOBI = new CatalogoServiceMOBI();
catalogoMOBI.registrarYAbrir("El túnel", "Ernesto Sabato");

console.log("\n========================================");
console.log(" PRUEBA 5: Confirmar que cada catálogo produce un tipo distinto de libro");
console.log("========================================");
const libroPDF = catalogoPDF.crearLibro("Test", "Autor Test");
const libroEPUB = catalogoEPUB.crearLibro("Test", "Autor Test");
console.log("¿libroPDF es instancia de LibroPDF?", libroPDF.constructor.name === "LibroPDF");
console.log("¿libroEPUB es instancia de LibroEPUB?", libroEPUB.constructor.name === "LibroEPUB");
console.log("¿Son de la misma clase?", libroPDF.constructor.name === libroEPUB.constructor.name);

console.log("\n========================================");
console.log(" PRUEBA 6: Intentar instanciar LibroDigital directamente (debe fallar)");
console.log("========================================");
try {
  const LibroDigital = require("./libros/LibroDigital");
  const intentoInvalido = new LibroDigital("X", "Y");
} catch (error) {
  console.log("Error capturado como se esperaba:", error.message);
}
