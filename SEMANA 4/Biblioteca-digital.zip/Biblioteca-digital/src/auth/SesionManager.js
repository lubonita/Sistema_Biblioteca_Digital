

class SesionManager {
  
  static #instancia = null;

  constructor() {
    if (SesionManager.#instancia) {
      throw new Error(
        "No se puede crear otra instancia de SesionManager. Use SesionManager.getInstance()."
      );
    }

    this.usuarioActual = null;
    this.fechaInicioSesion = null;

    this.usuariosRegistrados = [
      { usuario: "vmillan", password: "1234", nombre: "Valentina Millán", rol: "administrador" },
      { usuario: "lzafra", password: "abcd", nombre: "Luz Estela Zafra", rol: "bibliotecario" },
      { usuario: "lector1", password: "lector1", nombre: "Usuario Lector", rol: "lector" },
    ];

    SesionManager.#instancia = this;
    console.log("[SesionManager] Instancia creada por primera vez.");
  }

 
  static getInstance() {
    if (!SesionManager.#instancia) {
      SesionManager.#instancia = new SesionManager();
    } else {
      console.log("[SesionManager] Reutilizando instancia existente.");
    }
    return SesionManager.#instancia;
  }

 
  login(usuario, password) {
    const encontrado = this.usuariosRegistrados.find(
      (u) => u.usuario === usuario && u.password === password
    );

    if (!encontrado) {
      console.log(`[Login] Intento fallido para el usuario "${usuario}".`);
      return false;
    }

    this.usuarioActual = encontrado;
    this.fechaInicioSesion = new Date();
    console.log(
      `[Login] Sesión iniciada correctamente: ${encontrado.nombre} (${encontrado.rol}).`
    );
    return true;
  }

  logout() {
    if (!this.usuarioActual) {
      console.log("[Logout] No hay ninguna sesión activa.");
      return;
    }
    console.log(`[Logout] Cerrando sesión de ${this.usuarioActual.nombre}.`);
    this.usuarioActual = null;
    this.fechaInicioSesion = null;
  }

  estaAutenticado() {
    return this.usuarioActual !== null;
  }

  getUsuarioActual() {
    return this.usuarioActual;
  }
}

module.exports = SesionManager;
